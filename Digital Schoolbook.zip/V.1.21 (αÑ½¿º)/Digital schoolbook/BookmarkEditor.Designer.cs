﻿namespace Digital_schoolbook
{
    partial class BookmarkEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BookmarkEditorPanel = new System.Windows.Forms.Panel();
            this.BookmarkNameAndDescriptionSeparator = new System.Windows.Forms.SplitContainer();
            this.BookmarkNameContainer = new System.Windows.Forms.SplitContainer();
            this.BookmarkNameLabel = new System.Windows.Forms.Label();
            this.BookmarkNameTextBox = new System.Windows.Forms.TextBox();
            this.BookmarkDescriptionContainer = new System.Windows.Forms.SplitContainer();
            this.BookmarkDescriptionLabel = new System.Windows.Forms.Label();
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator = new System.Windows.Forms.SplitContainer();
            this.BookmarkDescriptionRichTextBox = new System.Windows.Forms.RichTextBox();
            this.AddBookmarkOptionsContainer = new System.Windows.Forms.SplitContainer();
            this.AddBookmarkAbortButton = new System.Windows.Forms.Button();
            this.AddBookmarkConfirmButton = new System.Windows.Forms.Button();
            this.BookmarkEditorPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkNameAndDescriptionSeparator)).BeginInit();
            this.BookmarkNameAndDescriptionSeparator.Panel1.SuspendLayout();
            this.BookmarkNameAndDescriptionSeparator.Panel2.SuspendLayout();
            this.BookmarkNameAndDescriptionSeparator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkNameContainer)).BeginInit();
            this.BookmarkNameContainer.Panel1.SuspendLayout();
            this.BookmarkNameContainer.Panel2.SuspendLayout();
            this.BookmarkNameContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkDescriptionContainer)).BeginInit();
            this.BookmarkDescriptionContainer.Panel1.SuspendLayout();
            this.BookmarkDescriptionContainer.Panel2.SuspendLayout();
            this.BookmarkDescriptionContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator)).BeginInit();
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Panel1.SuspendLayout();
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Panel2.SuspendLayout();
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddBookmarkOptionsContainer)).BeginInit();
            this.AddBookmarkOptionsContainer.Panel1.SuspendLayout();
            this.AddBookmarkOptionsContainer.Panel2.SuspendLayout();
            this.AddBookmarkOptionsContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // BookmarkEditorPanel
            // 
            this.BookmarkEditorPanel.Controls.Add(this.BookmarkNameAndDescriptionSeparator);
            this.BookmarkEditorPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkEditorPanel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkEditorPanel.Name = "BookmarkEditorPanel";
            this.BookmarkEditorPanel.Size = new System.Drawing.Size(784, 411);
            this.BookmarkEditorPanel.TabIndex = 0;
            // 
            // BookmarkNameAndDescriptionSeparator
            // 
            this.BookmarkNameAndDescriptionSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkNameAndDescriptionSeparator.IsSplitterFixed = true;
            this.BookmarkNameAndDescriptionSeparator.Location = new System.Drawing.Point(0, 0);
            this.BookmarkNameAndDescriptionSeparator.Name = "BookmarkNameAndDescriptionSeparator";
            this.BookmarkNameAndDescriptionSeparator.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // BookmarkNameAndDescriptionSeparator.Panel1
            // 
            this.BookmarkNameAndDescriptionSeparator.Panel1.Controls.Add(this.BookmarkNameContainer);
            // 
            // BookmarkNameAndDescriptionSeparator.Panel2
            // 
            this.BookmarkNameAndDescriptionSeparator.Panel2.Controls.Add(this.BookmarkDescriptionContainer);
            this.BookmarkNameAndDescriptionSeparator.Size = new System.Drawing.Size(784, 411);
            this.BookmarkNameAndDescriptionSeparator.SplitterDistance = 60;
            this.BookmarkNameAndDescriptionSeparator.SplitterWidth = 1;
            this.BookmarkNameAndDescriptionSeparator.TabIndex = 0;
            // 
            // BookmarkNameContainer
            // 
            this.BookmarkNameContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkNameContainer.IsSplitterFixed = true;
            this.BookmarkNameContainer.Location = new System.Drawing.Point(0, 0);
            this.BookmarkNameContainer.Name = "BookmarkNameContainer";
            this.BookmarkNameContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // BookmarkNameContainer.Panel1
            // 
            this.BookmarkNameContainer.Panel1.Controls.Add(this.BookmarkNameLabel);
            // 
            // BookmarkNameContainer.Panel2
            // 
            this.BookmarkNameContainer.Panel2.Controls.Add(this.BookmarkNameTextBox);
            this.BookmarkNameContainer.Size = new System.Drawing.Size(784, 60);
            this.BookmarkNameContainer.SplitterDistance = 30;
            this.BookmarkNameContainer.SplitterWidth = 1;
            this.BookmarkNameContainer.TabIndex = 0;
            this.BookmarkNameContainer.TabStop = false;
            // 
            // BookmarkNameLabel
            // 
            this.BookmarkNameLabel.Dock = System.Windows.Forms.DockStyle.Left;
            this.BookmarkNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkNameLabel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkNameLabel.Name = "BookmarkNameLabel";
            this.BookmarkNameLabel.Size = new System.Drawing.Size(239, 30);
            this.BookmarkNameLabel.TabIndex = 0;
            this.BookmarkNameLabel.Text = "Название закладки";
            this.BookmarkNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BookmarkNameTextBox
            // 
            this.BookmarkNameTextBox.AllowDrop = true;
            this.BookmarkNameTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkNameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkNameTextBox.Location = new System.Drawing.Point(0, 0);
            this.BookmarkNameTextBox.MaxLength = 75;
            this.BookmarkNameTextBox.Name = "BookmarkNameTextBox";
            this.BookmarkNameTextBox.Size = new System.Drawing.Size(784, 29);
            this.BookmarkNameTextBox.TabIndex = 0;
            this.BookmarkNameTextBox.TextChanged += new System.EventHandler(this.BookmarkNameTextBox_TextChanged);
            this.BookmarkNameTextBox.DragDrop += new System.Windows.Forms.DragEventHandler(this.BookmarkNameTextBox_DragDrop);
            this.BookmarkNameTextBox.DragEnter += new System.Windows.Forms.DragEventHandler(this.BookmarkNameTextBox_DragEnter);
            // 
            // BookmarkDescriptionContainer
            // 
            this.BookmarkDescriptionContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkDescriptionContainer.IsSplitterFixed = true;
            this.BookmarkDescriptionContainer.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescriptionContainer.Name = "BookmarkDescriptionContainer";
            this.BookmarkDescriptionContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // BookmarkDescriptionContainer.Panel1
            // 
            this.BookmarkDescriptionContainer.Panel1.Controls.Add(this.BookmarkDescriptionLabel);
            // 
            // BookmarkDescriptionContainer.Panel2
            // 
            this.BookmarkDescriptionContainer.Panel2.Controls.Add(this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator);
            this.BookmarkDescriptionContainer.Size = new System.Drawing.Size(784, 350);
            this.BookmarkDescriptionContainer.SplitterDistance = 30;
            this.BookmarkDescriptionContainer.SplitterWidth = 1;
            this.BookmarkDescriptionContainer.TabIndex = 0;
            this.BookmarkDescriptionContainer.TabStop = false;
            // 
            // BookmarkDescriptionLabel
            // 
            this.BookmarkDescriptionLabel.Dock = System.Windows.Forms.DockStyle.Left;
            this.BookmarkDescriptionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkDescriptionLabel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescriptionLabel.Name = "BookmarkDescriptionLabel";
            this.BookmarkDescriptionLabel.Size = new System.Drawing.Size(244, 30);
            this.BookmarkDescriptionLabel.TabIndex = 0;
            this.BookmarkDescriptionLabel.Text = "Описание закладки";
            this.BookmarkDescriptionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator
            // 
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.IsSplitterFixed = true;
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Name = "BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator";
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Panel1
            // 
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Panel1.Controls.Add(this.BookmarkDescriptionRichTextBox);
            // 
            // BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Panel2
            // 
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Panel2.Controls.Add(this.AddBookmarkOptionsContainer);
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Size = new System.Drawing.Size(784, 319);
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.SplitterDistance = 272;
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.SplitterWidth = 1;
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.TabIndex = 0;
            // 
            // BookmarkDescriptionRichTextBox
            // 
            this.BookmarkDescriptionRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkDescriptionRichTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkDescriptionRichTextBox.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescriptionRichTextBox.MaxLength = 1000;
            this.BookmarkDescriptionRichTextBox.Name = "BookmarkDescriptionRichTextBox";
            this.BookmarkDescriptionRichTextBox.Size = new System.Drawing.Size(784, 272);
            this.BookmarkDescriptionRichTextBox.TabIndex = 0;
            this.BookmarkDescriptionRichTextBox.Text = "";
            this.BookmarkDescriptionRichTextBox.TextChanged += new System.EventHandler(this.BookmarkDescriptionRichTextBox_TextChanged);
            // 
            // AddBookmarkOptionsContainer
            // 
            this.AddBookmarkOptionsContainer.Dock = System.Windows.Forms.DockStyle.Right;
            this.AddBookmarkOptionsContainer.IsSplitterFixed = true;
            this.AddBookmarkOptionsContainer.Location = new System.Drawing.Point(440, 0);
            this.AddBookmarkOptionsContainer.Name = "AddBookmarkOptionsContainer";
            // 
            // AddBookmarkOptionsContainer.Panel1
            // 
            this.AddBookmarkOptionsContainer.Panel1.Controls.Add(this.AddBookmarkAbortButton);
            // 
            // AddBookmarkOptionsContainer.Panel2
            // 
            this.AddBookmarkOptionsContainer.Panel2.Controls.Add(this.AddBookmarkConfirmButton);
            this.AddBookmarkOptionsContainer.Size = new System.Drawing.Size(344, 46);
            this.AddBookmarkOptionsContainer.SplitterDistance = 170;
            this.AddBookmarkOptionsContainer.TabIndex = 0;
            // 
            // AddBookmarkAbortButton
            // 
            this.AddBookmarkAbortButton.BackColor = System.Drawing.Color.Red;
            this.AddBookmarkAbortButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddBookmarkAbortButton.Location = new System.Drawing.Point(0, 0);
            this.AddBookmarkAbortButton.Name = "AddBookmarkAbortButton";
            this.AddBookmarkAbortButton.Size = new System.Drawing.Size(170, 46);
            this.AddBookmarkAbortButton.TabIndex = 0;
            this.AddBookmarkAbortButton.Text = "Отмена";
            this.AddBookmarkAbortButton.UseVisualStyleBackColor = false;
            this.AddBookmarkAbortButton.Click += new System.EventHandler(this.AddBookmarkAbortButton_Click);
            // 
            // AddBookmarkConfirmButton
            // 
            this.AddBookmarkConfirmButton.BackColor = System.Drawing.Color.Cornsilk;
            this.AddBookmarkConfirmButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddBookmarkConfirmButton.Location = new System.Drawing.Point(0, 0);
            this.AddBookmarkConfirmButton.Name = "AddBookmarkConfirmButton";
            this.AddBookmarkConfirmButton.Size = new System.Drawing.Size(170, 46);
            this.AddBookmarkConfirmButton.TabIndex = 0;
            this.AddBookmarkConfirmButton.Text = "Добавить закладку";
            this.AddBookmarkConfirmButton.UseVisualStyleBackColor = false;
            this.AddBookmarkConfirmButton.Click += new System.EventHandler(this.AddBookmarkConfirmButton_Click);
            // 
            // BookmarkEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 411);
            this.Controls.Add(this.BookmarkEditorPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(800, 450);
            this.Name = "BookmarkEditor";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Создание закладки";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BookmarkEditor_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.BookmarkEditor_FormClosed);
            this.Load += new System.EventHandler(this.BookmarkEditor_Load);
            this.BookmarkEditorPanel.ResumeLayout(false);
            this.BookmarkNameAndDescriptionSeparator.Panel1.ResumeLayout(false);
            this.BookmarkNameAndDescriptionSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkNameAndDescriptionSeparator)).EndInit();
            this.BookmarkNameAndDescriptionSeparator.ResumeLayout(false);
            this.BookmarkNameContainer.Panel1.ResumeLayout(false);
            this.BookmarkNameContainer.Panel2.ResumeLayout(false);
            this.BookmarkNameContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkNameContainer)).EndInit();
            this.BookmarkNameContainer.ResumeLayout(false);
            this.BookmarkDescriptionContainer.Panel1.ResumeLayout(false);
            this.BookmarkDescriptionContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkDescriptionContainer)).EndInit();
            this.BookmarkDescriptionContainer.ResumeLayout(false);
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Panel1.ResumeLayout(false);
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator)).EndInit();
            this.BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator.ResumeLayout(false);
            this.AddBookmarkOptionsContainer.Panel1.ResumeLayout(false);
            this.AddBookmarkOptionsContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AddBookmarkOptionsContainer)).EndInit();
            this.AddBookmarkOptionsContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel BookmarkEditorPanel;
        private System.Windows.Forms.SplitContainer BookmarkNameAndDescriptionSeparator;
        private System.Windows.Forms.SplitContainer BookmarkNameContainer;
        private System.Windows.Forms.SplitContainer BookmarkDescriptionContainer;
        private System.Windows.Forms.SplitContainer BookmarkDescriptionRichTextBoxAndAddBookmarkOptionsSeparator;
        private System.Windows.Forms.SplitContainer AddBookmarkOptionsContainer;
        private System.Windows.Forms.Button AddBookmarkAbortButton;
        private System.Windows.Forms.Button AddBookmarkConfirmButton;
        private System.Windows.Forms.Label BookmarkNameLabel;
        private System.Windows.Forms.TextBox BookmarkNameTextBox;
        private System.Windows.Forms.Label BookmarkDescriptionLabel;
        private System.Windows.Forms.RichTextBox BookmarkDescriptionRichTextBox;
    }
}