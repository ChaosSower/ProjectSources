﻿using System;
using System.Collections.Generic;

namespace DictionariesKeeper
{
    public class DictionariesKeeperClass
    {
        public static Dictionary<Tuple<int, int>, string> ContentsBookmarkListTreeView = new(); // словарь названия закладок "содержимого"
        public static Dictionary<string, Tuple<string, string, string, string>> ContentsBookmarkDictionary = new(); // словарь закладок "содержимого"
    }
}