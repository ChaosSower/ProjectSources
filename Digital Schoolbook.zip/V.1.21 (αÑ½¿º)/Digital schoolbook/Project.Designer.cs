﻿namespace Digital_schoolbook
{
    partial class MainWindow
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.MainWindowPanel = new System.Windows.Forms.Panel();
            this.SaveAllDataButton = new System.Windows.Forms.Button();
            this.TabControl = new System.Windows.Forms.TabControl();
            this.ContentsPage = new System.Windows.Forms.TabPage();
            this.ContentsPagePanel = new System.Windows.Forms.Panel();
            this.ContentsContainer = new System.Windows.Forms.SplitContainer();
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator = new System.Windows.Forms.SplitContainer();
            this.ContentsBookmarkListAndBookmarkContentSeparator = new System.Windows.Forms.SplitContainer();
            this.ContentsBookmarkList = new System.Windows.Forms.TreeView();
            this.CreatorModeCheckBoxAndContentSeparator = new System.Windows.Forms.SplitContainer();
            this.CreatorModeCheckBox = new System.Windows.Forms.CheckBox();
            this.BookmarkContentRichTextBox = new System.Windows.Forms.RichTextBox();
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator = new System.Windows.Forms.SplitContainer();
            this.ContentsBookmarkListEditor = new System.Windows.Forms.SplitContainer();
            this.AddBookmarkIconAndButtonSeparator = new System.Windows.Forms.SplitContainer();
            this.AddBookmarkIcon = new System.Windows.Forms.PictureBox();
            this.AddBookmarkButton = new System.Windows.Forms.Button();
            this.RemoveBookmarkIconAndButtonSeparator = new System.Windows.Forms.SplitContainer();
            this.RemoveBookmarkIcon = new System.Windows.Forms.PictureBox();
            this.RemoveBookmarkButton = new System.Windows.Forms.Button();
            this.BookmarkContentEditorAndRemover = new System.Windows.Forms.SplitContainer();
            this.BookmarkContentEditor = new System.Windows.Forms.SplitContainer();
            this.AddBookmarkContentButton = new System.Windows.Forms.Button();
            this.EditBookmarkContentButton = new System.Windows.Forms.Button();
            this.RemoveBookmarkContentButton = new System.Windows.Forms.Button();
            this.BookmarkDescriptionAndInfoContainer = new System.Windows.Forms.SplitContainer();
            this.BookmarkDescritionAndDescriptionLabelSeparator = new System.Windows.Forms.SplitContainer();
            this.BookmarkDescriptionLabel = new System.Windows.Forms.Label();
            this.BookmarkDescriptionRichTextBoxBorderStylePanel = new System.Windows.Forms.Panel();
            this.BookmarkDescriptionRichTextBox = new System.Windows.Forms.RichTextBox();
            this.BookmarkTimeAndChapterContainer = new System.Windows.Forms.SplitContainer();
            this.BookmarkTimeInfoAndTimeInfoLabel = new System.Windows.Forms.SplitContainer();
            this.BookmarkTimeInfoLabel = new System.Windows.Forms.Label();
            this.BookmarkTimeInfoTextBox = new System.Windows.Forms.TextBox();
            this.BookmarkChapterAndChapterLabel = new System.Windows.Forms.SplitContainer();
            this.BookmarkChapterInfoLabel = new System.Windows.Forms.Label();
            this.BookmarkChapterInfoTextBox = new System.Windows.Forms.TextBox();
            this.GlossaryPage = new System.Windows.Forms.TabPage();
            this.GlossaryPagePanel = new System.Windows.Forms.Panel();
            this.LiteraturePage = new System.Windows.Forms.TabPage();
            this.VideosPage = new System.Windows.Forms.TabPage();
            this.VideosPanel = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.ExamPage = new System.Windows.Forms.TabPage();
            this.HelpPage = new System.Windows.Forms.TabPage();
            this.BookmarkContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.снятьВыделениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.копироватьТекстToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.переименоватьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BookmarkDescriptionContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.копироватьТекстToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.изменитьОписаниеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BookmarkFolderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.MainWindowPanel.SuspendLayout();
            this.TabControl.SuspendLayout();
            this.ContentsPage.SuspendLayout();
            this.ContentsPagePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContentsContainer)).BeginInit();
            this.ContentsContainer.Panel1.SuspendLayout();
            this.ContentsContainer.Panel2.SuspendLayout();
            this.ContentsContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator)).BeginInit();
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel1.SuspendLayout();
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel2.SuspendLayout();
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContentsBookmarkListAndBookmarkContentSeparator)).BeginInit();
            this.ContentsBookmarkListAndBookmarkContentSeparator.Panel1.SuspendLayout();
            this.ContentsBookmarkListAndBookmarkContentSeparator.Panel2.SuspendLayout();
            this.ContentsBookmarkListAndBookmarkContentSeparator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CreatorModeCheckBoxAndContentSeparator)).BeginInit();
            this.CreatorModeCheckBoxAndContentSeparator.Panel1.SuspendLayout();
            this.CreatorModeCheckBoxAndContentSeparator.Panel2.SuspendLayout();
            this.CreatorModeCheckBoxAndContentSeparator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator)).BeginInit();
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Panel1.SuspendLayout();
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Panel2.SuspendLayout();
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContentsBookmarkListEditor)).BeginInit();
            this.ContentsBookmarkListEditor.Panel1.SuspendLayout();
            this.ContentsBookmarkListEditor.Panel2.SuspendLayout();
            this.ContentsBookmarkListEditor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddBookmarkIconAndButtonSeparator)).BeginInit();
            this.AddBookmarkIconAndButtonSeparator.Panel1.SuspendLayout();
            this.AddBookmarkIconAndButtonSeparator.Panel2.SuspendLayout();
            this.AddBookmarkIconAndButtonSeparator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AddBookmarkIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RemoveBookmarkIconAndButtonSeparator)).BeginInit();
            this.RemoveBookmarkIconAndButtonSeparator.Panel1.SuspendLayout();
            this.RemoveBookmarkIconAndButtonSeparator.Panel2.SuspendLayout();
            this.RemoveBookmarkIconAndButtonSeparator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RemoveBookmarkIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkContentEditorAndRemover)).BeginInit();
            this.BookmarkContentEditorAndRemover.Panel1.SuspendLayout();
            this.BookmarkContentEditorAndRemover.Panel2.SuspendLayout();
            this.BookmarkContentEditorAndRemover.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkContentEditor)).BeginInit();
            this.BookmarkContentEditor.Panel1.SuspendLayout();
            this.BookmarkContentEditor.Panel2.SuspendLayout();
            this.BookmarkContentEditor.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkDescriptionAndInfoContainer)).BeginInit();
            this.BookmarkDescriptionAndInfoContainer.Panel1.SuspendLayout();
            this.BookmarkDescriptionAndInfoContainer.Panel2.SuspendLayout();
            this.BookmarkDescriptionAndInfoContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkDescritionAndDescriptionLabelSeparator)).BeginInit();
            this.BookmarkDescritionAndDescriptionLabelSeparator.Panel1.SuspendLayout();
            this.BookmarkDescritionAndDescriptionLabelSeparator.Panel2.SuspendLayout();
            this.BookmarkDescritionAndDescriptionLabelSeparator.SuspendLayout();
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkTimeAndChapterContainer)).BeginInit();
            this.BookmarkTimeAndChapterContainer.Panel1.SuspendLayout();
            this.BookmarkTimeAndChapterContainer.Panel2.SuspendLayout();
            this.BookmarkTimeAndChapterContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkTimeInfoAndTimeInfoLabel)).BeginInit();
            this.BookmarkTimeInfoAndTimeInfoLabel.Panel1.SuspendLayout();
            this.BookmarkTimeInfoAndTimeInfoLabel.Panel2.SuspendLayout();
            this.BookmarkTimeInfoAndTimeInfoLabel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkChapterAndChapterLabel)).BeginInit();
            this.BookmarkChapterAndChapterLabel.Panel1.SuspendLayout();
            this.BookmarkChapterAndChapterLabel.Panel2.SuspendLayout();
            this.BookmarkChapterAndChapterLabel.SuspendLayout();
            this.GlossaryPage.SuspendLayout();
            this.VideosPage.SuspendLayout();
            this.VideosPanel.SuspendLayout();
            this.BookmarkContextMenuStrip.SuspendLayout();
            this.BookmarkDescriptionContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainWindowPanel
            // 
            this.MainWindowPanel.Controls.Add(this.SaveAllDataButton);
            this.MainWindowPanel.Controls.Add(this.TabControl);
            this.MainWindowPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainWindowPanel.Location = new System.Drawing.Point(0, 0);
            this.MainWindowPanel.Name = "MainWindowPanel";
            this.MainWindowPanel.Size = new System.Drawing.Size(1584, 861);
            this.MainWindowPanel.TabIndex = 0;
            // 
            // SaveAllDataButton
            // 
            this.SaveAllDataButton.BackColor = System.Drawing.Color.Gold;
            this.SaveAllDataButton.Location = new System.Drawing.Point(1431, 808);
            this.SaveAllDataButton.Name = "SaveAllDataButton";
            this.SaveAllDataButton.Size = new System.Drawing.Size(150, 50);
            this.SaveAllDataButton.TabIndex = 1;
            this.SaveAllDataButton.Text = "Сохранить данные";
            this.SaveAllDataButton.UseVisualStyleBackColor = false;
            this.SaveAllDataButton.Click += new System.EventHandler(this.SaveAllDataButton_Click);
            // 
            // TabControl
            // 
            this.TabControl.Controls.Add(this.ContentsPage);
            this.TabControl.Controls.Add(this.GlossaryPage);
            this.TabControl.Controls.Add(this.LiteraturePage);
            this.TabControl.Controls.Add(this.VideosPage);
            this.TabControl.Controls.Add(this.ExamPage);
            this.TabControl.Controls.Add(this.HelpPage);
            this.TabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.TabControl.Location = new System.Drawing.Point(24, 36);
            this.TabControl.Name = "TabControl";
            this.TabControl.SelectedIndex = 0;
            this.TabControl.Size = new System.Drawing.Size(1533, 716);
            this.TabControl.TabIndex = 0;
            // 
            // ContentsPage
            // 
            this.ContentsPage.Controls.Add(this.ContentsPagePanel);
            this.ContentsPage.Location = new System.Drawing.Point(4, 40);
            this.ContentsPage.Name = "ContentsPage";
            this.ContentsPage.Padding = new System.Windows.Forms.Padding(3);
            this.ContentsPage.Size = new System.Drawing.Size(1525, 672);
            this.ContentsPage.TabIndex = 0;
            this.ContentsPage.Text = "Оглавление";
            this.ContentsPage.UseVisualStyleBackColor = true;
            // 
            // ContentsPagePanel
            // 
            this.ContentsPagePanel.Controls.Add(this.ContentsContainer);
            this.ContentsPagePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentsPagePanel.Location = new System.Drawing.Point(3, 3);
            this.ContentsPagePanel.Name = "ContentsPagePanel";
            this.ContentsPagePanel.Size = new System.Drawing.Size(1519, 666);
            this.ContentsPagePanel.TabIndex = 0;
            // 
            // ContentsContainer
            // 
            this.ContentsContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentsContainer.Location = new System.Drawing.Point(0, 0);
            this.ContentsContainer.Name = "ContentsContainer";
            this.ContentsContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // ContentsContainer.Panel1
            // 
            this.ContentsContainer.Panel1.Controls.Add(this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator);
            this.ContentsContainer.Panel1MinSize = 100;
            // 
            // ContentsContainer.Panel2
            // 
            this.ContentsContainer.Panel2.Controls.Add(this.BookmarkDescriptionAndInfoContainer);
            this.ContentsContainer.Panel2MinSize = 228;
            this.ContentsContainer.Size = new System.Drawing.Size(1519, 666);
            this.ContentsContainer.SplitterDistance = 296;
            this.ContentsContainer.SplitterWidth = 1;
            this.ContentsContainer.TabIndex = 0;
            // 
            // ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator
            // 
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.IsSplitterFixed = true;
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Location = new System.Drawing.Point(0, 0);
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Name = "ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator";
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel1
            // 
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel1.Controls.Add(this.ContentsBookmarkListAndBookmarkContentSeparator);
            // 
            // ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel2
            // 
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel2.Controls.Add(this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator);
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel2MinSize = 50;
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Size = new System.Drawing.Size(1519, 296);
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.SplitterDistance = 242;
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.TabIndex = 0;
            // 
            // ContentsBookmarkListAndBookmarkContentSeparator
            // 
            this.ContentsBookmarkListAndBookmarkContentSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentsBookmarkListAndBookmarkContentSeparator.Location = new System.Drawing.Point(0, 0);
            this.ContentsBookmarkListAndBookmarkContentSeparator.Name = "ContentsBookmarkListAndBookmarkContentSeparator";
            // 
            // ContentsBookmarkListAndBookmarkContentSeparator.Panel1
            // 
            this.ContentsBookmarkListAndBookmarkContentSeparator.Panel1.Controls.Add(this.ContentsBookmarkList);
            this.ContentsBookmarkListAndBookmarkContentSeparator.Panel1MinSize = 304;
            // 
            // ContentsBookmarkListAndBookmarkContentSeparator.Panel2
            // 
            this.ContentsBookmarkListAndBookmarkContentSeparator.Panel2.Controls.Add(this.CreatorModeCheckBoxAndContentSeparator);
            this.ContentsBookmarkListAndBookmarkContentSeparator.Panel2MinSize = 400;
            this.ContentsBookmarkListAndBookmarkContentSeparator.Size = new System.Drawing.Size(1519, 242);
            this.ContentsBookmarkListAndBookmarkContentSeparator.SplitterDistance = 381;
            this.ContentsBookmarkListAndBookmarkContentSeparator.TabIndex = 0;
            // 
            // ContentsBookmarkList
            // 
            this.ContentsBookmarkList.BackColor = System.Drawing.Color.Gainsboro;
            this.ContentsBookmarkList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentsBookmarkList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ContentsBookmarkList.Location = new System.Drawing.Point(0, 0);
            this.ContentsBookmarkList.Name = "ContentsBookmarkList";
            this.ContentsBookmarkList.Size = new System.Drawing.Size(381, 242);
            this.ContentsBookmarkList.TabIndex = 0;
            this.ContentsBookmarkList.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.ContentsBookmarkList_NodeMouseClick);
            this.ContentsBookmarkList.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ContentsBookmarkList_MouseUp);
            // 
            // CreatorModeCheckBoxAndContentSeparator
            // 
            this.CreatorModeCheckBoxAndContentSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.CreatorModeCheckBoxAndContentSeparator.IsSplitterFixed = true;
            this.CreatorModeCheckBoxAndContentSeparator.Location = new System.Drawing.Point(0, 0);
            this.CreatorModeCheckBoxAndContentSeparator.Name = "CreatorModeCheckBoxAndContentSeparator";
            this.CreatorModeCheckBoxAndContentSeparator.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // CreatorModeCheckBoxAndContentSeparator.Panel1
            // 
            this.CreatorModeCheckBoxAndContentSeparator.Panel1.Controls.Add(this.CreatorModeCheckBox);
            // 
            // CreatorModeCheckBoxAndContentSeparator.Panel2
            // 
            this.CreatorModeCheckBoxAndContentSeparator.Panel2.Controls.Add(this.BookmarkContentRichTextBox);
            this.CreatorModeCheckBoxAndContentSeparator.Size = new System.Drawing.Size(1134, 242);
            this.CreatorModeCheckBoxAndContentSeparator.SplitterDistance = 25;
            this.CreatorModeCheckBoxAndContentSeparator.SplitterWidth = 1;
            this.CreatorModeCheckBoxAndContentSeparator.TabIndex = 0;
            // 
            // CreatorModeCheckBox
            // 
            this.CreatorModeCheckBox.AutoSize = true;
            this.CreatorModeCheckBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.CreatorModeCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CreatorModeCheckBox.ForeColor = System.Drawing.SystemColors.ControlText;
            this.CreatorModeCheckBox.Location = new System.Drawing.Point(0, 0);
            this.CreatorModeCheckBox.Name = "CreatorModeCheckBox";
            this.CreatorModeCheckBox.Size = new System.Drawing.Size(198, 25);
            this.CreatorModeCheckBox.TabIndex = 0;
            this.CreatorModeCheckBox.Text = "Режим редактирования закладки";
            this.CreatorModeCheckBox.UseVisualStyleBackColor = true;
            this.CreatorModeCheckBox.CheckedChanged += new System.EventHandler(this.CreatorModeCheckBox_CheckedChanged);
            // 
            // BookmarkContentRichTextBox
            // 
            this.BookmarkContentRichTextBox.AcceptsTab = true;
            this.BookmarkContentRichTextBox.BackColor = System.Drawing.SystemColors.Control;
            this.BookmarkContentRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkContentRichTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkContentRichTextBox.Location = new System.Drawing.Point(0, 0);
            this.BookmarkContentRichTextBox.MaxLength = 10000;
            this.BookmarkContentRichTextBox.Name = "BookmarkContentRichTextBox";
            this.BookmarkContentRichTextBox.ReadOnly = true;
            this.BookmarkContentRichTextBox.Size = new System.Drawing.Size(1134, 216);
            this.BookmarkContentRichTextBox.TabIndex = 0;
            this.BookmarkContentRichTextBox.Text = "";
            this.BookmarkContentRichTextBox.LinkClicked += new System.Windows.Forms.LinkClickedEventHandler(this.BookmarkContentRichTextBox_LinkClicked);
            // 
            // ContentsBookmarkListEditorAndBookmarkContentEditorSeparator
            // 
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.IsSplitterFixed = true;
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Location = new System.Drawing.Point(0, 0);
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Name = "ContentsBookmarkListEditorAndBookmarkContentEditorSeparator";
            // 
            // ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Panel1
            // 
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Panel1.Controls.Add(this.ContentsBookmarkListEditor);
            // 
            // ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Panel2
            // 
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Panel2.Controls.Add(this.BookmarkContentEditorAndRemover);
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Size = new System.Drawing.Size(1519, 50);
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.SplitterDistance = 381;
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.TabIndex = 0;
            // 
            // ContentsBookmarkListEditor
            // 
            this.ContentsBookmarkListEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ContentsBookmarkListEditor.IsSplitterFixed = true;
            this.ContentsBookmarkListEditor.Location = new System.Drawing.Point(0, 0);
            this.ContentsBookmarkListEditor.Name = "ContentsBookmarkListEditor";
            // 
            // ContentsBookmarkListEditor.Panel1
            // 
            this.ContentsBookmarkListEditor.Panel1.Controls.Add(this.AddBookmarkIconAndButtonSeparator);
            // 
            // ContentsBookmarkListEditor.Panel2
            // 
            this.ContentsBookmarkListEditor.Panel2.Controls.Add(this.RemoveBookmarkIconAndButtonSeparator);
            this.ContentsBookmarkListEditor.Size = new System.Drawing.Size(381, 50);
            this.ContentsBookmarkListEditor.SplitterDistance = 190;
            this.ContentsBookmarkListEditor.SplitterWidth = 1;
            this.ContentsBookmarkListEditor.TabIndex = 0;
            // 
            // AddBookmarkIconAndButtonSeparator
            // 
            this.AddBookmarkIconAndButtonSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddBookmarkIconAndButtonSeparator.IsSplitterFixed = true;
            this.AddBookmarkIconAndButtonSeparator.Location = new System.Drawing.Point(0, 0);
            this.AddBookmarkIconAndButtonSeparator.Name = "AddBookmarkIconAndButtonSeparator";
            // 
            // AddBookmarkIconAndButtonSeparator.Panel1
            // 
            this.AddBookmarkIconAndButtonSeparator.Panel1.Controls.Add(this.AddBookmarkIcon);
            // 
            // AddBookmarkIconAndButtonSeparator.Panel2
            // 
            this.AddBookmarkIconAndButtonSeparator.Panel2.Controls.Add(this.AddBookmarkButton);
            this.AddBookmarkIconAndButtonSeparator.Size = new System.Drawing.Size(190, 50);
            this.AddBookmarkIconAndButtonSeparator.SplitterDistance = 51;
            this.AddBookmarkIconAndButtonSeparator.SplitterWidth = 1;
            this.AddBookmarkIconAndButtonSeparator.TabIndex = 0;
            // 
            // AddBookmarkIcon
            // 
            this.AddBookmarkIcon.BackgroundImage = global::Digital_schoolbook.Properties.Resources.AddBookmarkIcon;
            this.AddBookmarkIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.AddBookmarkIcon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddBookmarkIcon.Location = new System.Drawing.Point(0, 0);
            this.AddBookmarkIcon.Name = "AddBookmarkIcon";
            this.AddBookmarkIcon.Size = new System.Drawing.Size(51, 50);
            this.AddBookmarkIcon.TabIndex = 0;
            this.AddBookmarkIcon.TabStop = false;
            // 
            // AddBookmarkButton
            // 
            this.AddBookmarkButton.BackColor = System.Drawing.Color.LightGreen;
            this.AddBookmarkButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddBookmarkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AddBookmarkButton.Location = new System.Drawing.Point(0, 0);
            this.AddBookmarkButton.Name = "AddBookmarkButton";
            this.AddBookmarkButton.Size = new System.Drawing.Size(138, 50);
            this.AddBookmarkButton.TabIndex = 0;
            this.AddBookmarkButton.Text = "Добавить закладку";
            this.AddBookmarkButton.UseVisualStyleBackColor = false;
            this.AddBookmarkButton.Click += new System.EventHandler(this.AddBookmarkButton_Click);
            // 
            // RemoveBookmarkIconAndButtonSeparator
            // 
            this.RemoveBookmarkIconAndButtonSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RemoveBookmarkIconAndButtonSeparator.IsSplitterFixed = true;
            this.RemoveBookmarkIconAndButtonSeparator.Location = new System.Drawing.Point(0, 0);
            this.RemoveBookmarkIconAndButtonSeparator.Name = "RemoveBookmarkIconAndButtonSeparator";
            // 
            // RemoveBookmarkIconAndButtonSeparator.Panel1
            // 
            this.RemoveBookmarkIconAndButtonSeparator.Panel1.Controls.Add(this.RemoveBookmarkIcon);
            // 
            // RemoveBookmarkIconAndButtonSeparator.Panel2
            // 
            this.RemoveBookmarkIconAndButtonSeparator.Panel2.Controls.Add(this.RemoveBookmarkButton);
            this.RemoveBookmarkIconAndButtonSeparator.Size = new System.Drawing.Size(190, 50);
            this.RemoveBookmarkIconAndButtonSeparator.SplitterDistance = 51;
            this.RemoveBookmarkIconAndButtonSeparator.SplitterWidth = 1;
            this.RemoveBookmarkIconAndButtonSeparator.TabIndex = 0;
            // 
            // RemoveBookmarkIcon
            // 
            this.RemoveBookmarkIcon.BackgroundImage = global::Digital_schoolbook.Properties.Resources.RemoveBookmarkIcon;
            this.RemoveBookmarkIcon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.RemoveBookmarkIcon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RemoveBookmarkIcon.Location = new System.Drawing.Point(0, 0);
            this.RemoveBookmarkIcon.Name = "RemoveBookmarkIcon";
            this.RemoveBookmarkIcon.Size = new System.Drawing.Size(51, 50);
            this.RemoveBookmarkIcon.TabIndex = 0;
            this.RemoveBookmarkIcon.TabStop = false;
            // 
            // RemoveBookmarkButton
            // 
            this.RemoveBookmarkButton.BackColor = System.Drawing.Color.IndianRed;
            this.RemoveBookmarkButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RemoveBookmarkButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RemoveBookmarkButton.Location = new System.Drawing.Point(0, 0);
            this.RemoveBookmarkButton.Name = "RemoveBookmarkButton";
            this.RemoveBookmarkButton.Size = new System.Drawing.Size(138, 50);
            this.RemoveBookmarkButton.TabIndex = 0;
            this.RemoveBookmarkButton.Text = "Удалить закладку";
            this.RemoveBookmarkButton.UseVisualStyleBackColor = false;
            this.RemoveBookmarkButton.Click += new System.EventHandler(this.RemoveBookmarkButton_Click);
            // 
            // BookmarkContentEditorAndRemover
            // 
            this.BookmarkContentEditorAndRemover.BackColor = System.Drawing.Color.Transparent;
            this.BookmarkContentEditorAndRemover.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkContentEditorAndRemover.IsSplitterFixed = true;
            this.BookmarkContentEditorAndRemover.Location = new System.Drawing.Point(0, 0);
            this.BookmarkContentEditorAndRemover.Name = "BookmarkContentEditorAndRemover";
            // 
            // BookmarkContentEditorAndRemover.Panel1
            // 
            this.BookmarkContentEditorAndRemover.Panel1.Controls.Add(this.BookmarkContentEditor);
            // 
            // BookmarkContentEditorAndRemover.Panel2
            // 
            this.BookmarkContentEditorAndRemover.Panel2.Controls.Add(this.RemoveBookmarkContentButton);
            this.BookmarkContentEditorAndRemover.Size = new System.Drawing.Size(1134, 50);
            this.BookmarkContentEditorAndRemover.SplitterDistance = 756;
            this.BookmarkContentEditorAndRemover.SplitterWidth = 1;
            this.BookmarkContentEditorAndRemover.TabIndex = 0;
            // 
            // BookmarkContentEditor
            // 
            this.BookmarkContentEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkContentEditor.IsSplitterFixed = true;
            this.BookmarkContentEditor.Location = new System.Drawing.Point(0, 0);
            this.BookmarkContentEditor.Name = "BookmarkContentEditor";
            // 
            // BookmarkContentEditor.Panel1
            // 
            this.BookmarkContentEditor.Panel1.Controls.Add(this.AddBookmarkContentButton);
            // 
            // BookmarkContentEditor.Panel2
            // 
            this.BookmarkContentEditor.Panel2.Controls.Add(this.EditBookmarkContentButton);
            this.BookmarkContentEditor.Size = new System.Drawing.Size(756, 50);
            this.BookmarkContentEditor.SplitterDistance = 377;
            this.BookmarkContentEditor.SplitterWidth = 1;
            this.BookmarkContentEditor.TabIndex = 0;
            // 
            // AddBookmarkContentButton
            // 
            this.AddBookmarkContentButton.BackColor = System.Drawing.Color.LimeGreen;
            this.AddBookmarkContentButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AddBookmarkContentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AddBookmarkContentButton.Location = new System.Drawing.Point(0, 0);
            this.AddBookmarkContentButton.Name = "AddBookmarkContentButton";
            this.AddBookmarkContentButton.Size = new System.Drawing.Size(377, 50);
            this.AddBookmarkContentButton.TabIndex = 0;
            this.AddBookmarkContentButton.Text = "Добавить содержимое";
            this.AddBookmarkContentButton.UseVisualStyleBackColor = false;
            this.AddBookmarkContentButton.Click += new System.EventHandler(this.AddBookmarkContentButton_Click);
            // 
            // EditBookmarkContentButton
            // 
            this.EditBookmarkContentButton.BackColor = System.Drawing.Color.Cornsilk;
            this.EditBookmarkContentButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.EditBookmarkContentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.EditBookmarkContentButton.Location = new System.Drawing.Point(0, 0);
            this.EditBookmarkContentButton.Name = "EditBookmarkContentButton";
            this.EditBookmarkContentButton.Size = new System.Drawing.Size(378, 50);
            this.EditBookmarkContentButton.TabIndex = 0;
            this.EditBookmarkContentButton.Text = "Редактировать содержимое";
            this.EditBookmarkContentButton.UseVisualStyleBackColor = false;
            this.EditBookmarkContentButton.Click += new System.EventHandler(this.EditBookmarkContentButton_Click);
            // 
            // RemoveBookmarkContentButton
            // 
            this.RemoveBookmarkContentButton.BackColor = System.Drawing.Color.Red;
            this.RemoveBookmarkContentButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RemoveBookmarkContentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.RemoveBookmarkContentButton.Location = new System.Drawing.Point(0, 0);
            this.RemoveBookmarkContentButton.Name = "RemoveBookmarkContentButton";
            this.RemoveBookmarkContentButton.Size = new System.Drawing.Size(377, 50);
            this.RemoveBookmarkContentButton.TabIndex = 0;
            this.RemoveBookmarkContentButton.Text = "Очистить содержимое";
            this.RemoveBookmarkContentButton.UseVisualStyleBackColor = false;
            this.RemoveBookmarkContentButton.Click += new System.EventHandler(this.RemoveBookmarkContentButton_Click);
            // 
            // BookmarkDescriptionAndInfoContainer
            // 
            this.BookmarkDescriptionAndInfoContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkDescriptionAndInfoContainer.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescriptionAndInfoContainer.Name = "BookmarkDescriptionAndInfoContainer";
            // 
            // BookmarkDescriptionAndInfoContainer.Panel1
            // 
            this.BookmarkDescriptionAndInfoContainer.Panel1.Controls.Add(this.BookmarkDescritionAndDescriptionLabelSeparator);
            this.BookmarkDescriptionAndInfoContainer.Panel1MinSize = 304;
            // 
            // BookmarkDescriptionAndInfoContainer.Panel2
            // 
            this.BookmarkDescriptionAndInfoContainer.Panel2.Controls.Add(this.BookmarkTimeAndChapterContainer);
            this.BookmarkDescriptionAndInfoContainer.Panel2MinSize = 455;
            this.BookmarkDescriptionAndInfoContainer.Size = new System.Drawing.Size(1519, 369);
            this.BookmarkDescriptionAndInfoContainer.SplitterDistance = 381;
            this.BookmarkDescriptionAndInfoContainer.SplitterWidth = 1;
            this.BookmarkDescriptionAndInfoContainer.TabIndex = 0;
            // 
            // BookmarkDescritionAndDescriptionLabelSeparator
            // 
            this.BookmarkDescritionAndDescriptionLabelSeparator.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkDescritionAndDescriptionLabelSeparator.IsSplitterFixed = true;
            this.BookmarkDescritionAndDescriptionLabelSeparator.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescritionAndDescriptionLabelSeparator.Name = "BookmarkDescritionAndDescriptionLabelSeparator";
            this.BookmarkDescritionAndDescriptionLabelSeparator.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // BookmarkDescritionAndDescriptionLabelSeparator.Panel1
            // 
            this.BookmarkDescritionAndDescriptionLabelSeparator.Panel1.BackColor = System.Drawing.Color.LightGray;
            this.BookmarkDescritionAndDescriptionLabelSeparator.Panel1.Controls.Add(this.BookmarkDescriptionLabel);
            // 
            // BookmarkDescritionAndDescriptionLabelSeparator.Panel2
            // 
            this.BookmarkDescritionAndDescriptionLabelSeparator.Panel2.Controls.Add(this.BookmarkDescriptionRichTextBoxBorderStylePanel);
            this.BookmarkDescritionAndDescriptionLabelSeparator.Size = new System.Drawing.Size(381, 369);
            this.BookmarkDescritionAndDescriptionLabelSeparator.SplitterDistance = 43;
            this.BookmarkDescritionAndDescriptionLabelSeparator.SplitterWidth = 1;
            this.BookmarkDescritionAndDescriptionLabelSeparator.TabIndex = 0;
            // 
            // BookmarkDescriptionLabel
            // 
            this.BookmarkDescriptionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BookmarkDescriptionLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkDescriptionLabel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescriptionLabel.Name = "BookmarkDescriptionLabel";
            this.BookmarkDescriptionLabel.Size = new System.Drawing.Size(381, 43);
            this.BookmarkDescriptionLabel.TabIndex = 0;
            this.BookmarkDescriptionLabel.Text = "Описание закладки";
            this.BookmarkDescriptionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BookmarkDescriptionRichTextBoxBorderStylePanel
            // 
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.Controls.Add(this.BookmarkDescriptionRichTextBox);
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.Name = "BookmarkDescriptionRichTextBoxBorderStylePanel";
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.Size = new System.Drawing.Size(381, 325);
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.TabIndex = 0;
            // 
            // BookmarkDescriptionRichTextBox
            // 
            this.BookmarkDescriptionRichTextBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BookmarkDescriptionRichTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BookmarkDescriptionRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkDescriptionRichTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkDescriptionRichTextBox.Location = new System.Drawing.Point(0, 0);
            this.BookmarkDescriptionRichTextBox.MaxLength = 1000;
            this.BookmarkDescriptionRichTextBox.Name = "BookmarkDescriptionRichTextBox";
            this.BookmarkDescriptionRichTextBox.ReadOnly = true;
            this.BookmarkDescriptionRichTextBox.Size = new System.Drawing.Size(379, 323);
            this.BookmarkDescriptionRichTextBox.TabIndex = 0;
            this.BookmarkDescriptionRichTextBox.Text = "";
            this.BookmarkDescriptionRichTextBox.LinkClicked += new System.Windows.Forms.LinkClickedEventHandler(this.BookmarkDescriptionRichTextBox_LinkClicked);
            this.BookmarkDescriptionRichTextBox.MouseUp += new System.Windows.Forms.MouseEventHandler(this.BookmarkDescriptionRichTextBox_MouseUp);
            // 
            // BookmarkTimeAndChapterContainer
            // 
            this.BookmarkTimeAndChapterContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkTimeAndChapterContainer.Location = new System.Drawing.Point(0, 0);
            this.BookmarkTimeAndChapterContainer.Name = "BookmarkTimeAndChapterContainer";
            // 
            // BookmarkTimeAndChapterContainer.Panel1
            // 
            this.BookmarkTimeAndChapterContainer.Panel1.Controls.Add(this.BookmarkTimeInfoAndTimeInfoLabel);
            this.BookmarkTimeAndChapterContainer.Panel1MinSize = 100;
            // 
            // BookmarkTimeAndChapterContainer.Panel2
            // 
            this.BookmarkTimeAndChapterContainer.Panel2.Controls.Add(this.BookmarkChapterAndChapterLabel);
            this.BookmarkTimeAndChapterContainer.Panel2MinSize = 350;
            this.BookmarkTimeAndChapterContainer.Size = new System.Drawing.Size(1137, 369);
            this.BookmarkTimeAndChapterContainer.SplitterDistance = 377;
            this.BookmarkTimeAndChapterContainer.SplitterWidth = 1;
            this.BookmarkTimeAndChapterContainer.TabIndex = 0;
            // 
            // BookmarkTimeInfoAndTimeInfoLabel
            // 
            this.BookmarkTimeInfoAndTimeInfoLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkTimeInfoAndTimeInfoLabel.IsSplitterFixed = true;
            this.BookmarkTimeInfoAndTimeInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkTimeInfoAndTimeInfoLabel.Name = "BookmarkTimeInfoAndTimeInfoLabel";
            this.BookmarkTimeInfoAndTimeInfoLabel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // BookmarkTimeInfoAndTimeInfoLabel.Panel1
            // 
            this.BookmarkTimeInfoAndTimeInfoLabel.Panel1.BackColor = System.Drawing.Color.LightGray;
            this.BookmarkTimeInfoAndTimeInfoLabel.Panel1.Controls.Add(this.BookmarkTimeInfoLabel);
            // 
            // BookmarkTimeInfoAndTimeInfoLabel.Panel2
            // 
            this.BookmarkTimeInfoAndTimeInfoLabel.Panel2.Controls.Add(this.BookmarkTimeInfoTextBox);
            this.BookmarkTimeInfoAndTimeInfoLabel.Size = new System.Drawing.Size(377, 369);
            this.BookmarkTimeInfoAndTimeInfoLabel.SplitterDistance = 43;
            this.BookmarkTimeInfoAndTimeInfoLabel.SplitterWidth = 1;
            this.BookmarkTimeInfoAndTimeInfoLabel.TabIndex = 0;
            // 
            // BookmarkTimeInfoLabel
            // 
            this.BookmarkTimeInfoLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BookmarkTimeInfoLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkTimeInfoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkTimeInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkTimeInfoLabel.Name = "BookmarkTimeInfoLabel";
            this.BookmarkTimeInfoLabel.Size = new System.Drawing.Size(377, 43);
            this.BookmarkTimeInfoLabel.TabIndex = 0;
            this.BookmarkTimeInfoLabel.Text = "Время создания (редактирования)";
            this.BookmarkTimeInfoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BookmarkTimeInfoTextBox
            // 
            this.BookmarkTimeInfoTextBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BookmarkTimeInfoTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkTimeInfoTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkTimeInfoTextBox.Location = new System.Drawing.Point(0, 0);
            this.BookmarkTimeInfoTextBox.MaxLength = 75;
            this.BookmarkTimeInfoTextBox.Multiline = true;
            this.BookmarkTimeInfoTextBox.Name = "BookmarkTimeInfoTextBox";
            this.BookmarkTimeInfoTextBox.ReadOnly = true;
            this.BookmarkTimeInfoTextBox.Size = new System.Drawing.Size(377, 325);
            this.BookmarkTimeInfoTextBox.TabIndex = 0;
            this.BookmarkTimeInfoTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BookmarkChapterAndChapterLabel
            // 
            this.BookmarkChapterAndChapterLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkChapterAndChapterLabel.IsSplitterFixed = true;
            this.BookmarkChapterAndChapterLabel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkChapterAndChapterLabel.Name = "BookmarkChapterAndChapterLabel";
            this.BookmarkChapterAndChapterLabel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // BookmarkChapterAndChapterLabel.Panel1
            // 
            this.BookmarkChapterAndChapterLabel.Panel1.BackColor = System.Drawing.Color.LightGray;
            this.BookmarkChapterAndChapterLabel.Panel1.Controls.Add(this.BookmarkChapterInfoLabel);
            // 
            // BookmarkChapterAndChapterLabel.Panel2
            // 
            this.BookmarkChapterAndChapterLabel.Panel2.Controls.Add(this.BookmarkChapterInfoTextBox);
            this.BookmarkChapterAndChapterLabel.Size = new System.Drawing.Size(759, 369);
            this.BookmarkChapterAndChapterLabel.SplitterDistance = 43;
            this.BookmarkChapterAndChapterLabel.SplitterWidth = 1;
            this.BookmarkChapterAndChapterLabel.TabIndex = 0;
            // 
            // BookmarkChapterInfoLabel
            // 
            this.BookmarkChapterInfoLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.BookmarkChapterInfoLabel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkChapterInfoLabel.Location = new System.Drawing.Point(0, 0);
            this.BookmarkChapterInfoLabel.Name = "BookmarkChapterInfoLabel";
            this.BookmarkChapterInfoLabel.Size = new System.Drawing.Size(759, 43);
            this.BookmarkChapterInfoLabel.TabIndex = 0;
            this.BookmarkChapterInfoLabel.Text = "Глава закладки";
            this.BookmarkChapterInfoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BookmarkChapterInfoTextBox
            // 
            this.BookmarkChapterInfoTextBox.BackColor = System.Drawing.Color.WhiteSmoke;
            this.BookmarkChapterInfoTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BookmarkChapterInfoTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.BookmarkChapterInfoTextBox.Location = new System.Drawing.Point(0, 0);
            this.BookmarkChapterInfoTextBox.MaxLength = 75;
            this.BookmarkChapterInfoTextBox.Multiline = true;
            this.BookmarkChapterInfoTextBox.Name = "BookmarkChapterInfoTextBox";
            this.BookmarkChapterInfoTextBox.ReadOnly = true;
            this.BookmarkChapterInfoTextBox.Size = new System.Drawing.Size(759, 325);
            this.BookmarkChapterInfoTextBox.TabIndex = 0;
            this.BookmarkChapterInfoTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // GlossaryPage
            // 
            this.GlossaryPage.Controls.Add(this.GlossaryPagePanel);
            this.GlossaryPage.Location = new System.Drawing.Point(4, 40);
            this.GlossaryPage.Name = "GlossaryPage";
            this.GlossaryPage.Padding = new System.Windows.Forms.Padding(3);
            this.GlossaryPage.Size = new System.Drawing.Size(1525, 672);
            this.GlossaryPage.TabIndex = 1;
            this.GlossaryPage.Text = "Глоссарий";
            this.GlossaryPage.UseVisualStyleBackColor = true;
            // 
            // GlossaryPagePanel
            // 
            this.GlossaryPagePanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GlossaryPagePanel.Location = new System.Drawing.Point(3, 3);
            this.GlossaryPagePanel.Name = "GlossaryPagePanel";
            this.GlossaryPagePanel.Size = new System.Drawing.Size(1519, 666);
            this.GlossaryPagePanel.TabIndex = 0;
            // 
            // LiteraturePage
            // 
            this.LiteraturePage.Location = new System.Drawing.Point(4, 40);
            this.LiteraturePage.Name = "LiteraturePage";
            this.LiteraturePage.Padding = new System.Windows.Forms.Padding(3);
            this.LiteraturePage.Size = new System.Drawing.Size(1525, 672);
            this.LiteraturePage.TabIndex = 2;
            this.LiteraturePage.Text = "Литература";
            this.LiteraturePage.UseVisualStyleBackColor = true;
            // 
            // VideosPage
            // 
            this.VideosPage.Controls.Add(this.VideosPanel);
            this.VideosPage.Location = new System.Drawing.Point(4, 40);
            this.VideosPage.Name = "VideosPage";
            this.VideosPage.Padding = new System.Windows.Forms.Padding(3);
            this.VideosPage.Size = new System.Drawing.Size(1525, 672);
            this.VideosPage.TabIndex = 3;
            this.VideosPage.Text = "Видео";
            this.VideosPage.UseVisualStyleBackColor = true;
            // 
            // VideosPanel
            // 
            this.VideosPanel.Controls.Add(this.button2);
            this.VideosPanel.Controls.Add(this.button1);
            this.VideosPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.VideosPanel.Location = new System.Drawing.Point(3, 3);
            this.VideosPanel.Name = "VideosPanel";
            this.VideosPanel.Size = new System.Drawing.Size(1519, 666);
            this.VideosPanel.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(1236, 604);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 43);
            this.button2.TabIndex = 1;
            this.button2.Text = "Открыть видео";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(1118, 604);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(101, 43);
            this.button1.TabIndex = 0;
            this.button1.Text = "Добавить видео";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // ExamPage
            // 
            this.ExamPage.Location = new System.Drawing.Point(4, 40);
            this.ExamPage.Name = "ExamPage";
            this.ExamPage.Padding = new System.Windows.Forms.Padding(3);
            this.ExamPage.Size = new System.Drawing.Size(1525, 672);
            this.ExamPage.TabIndex = 4;
            this.ExamPage.Text = "Экзамен";
            this.ExamPage.UseVisualStyleBackColor = true;
            // 
            // HelpPage
            // 
            this.HelpPage.Location = new System.Drawing.Point(4, 40);
            this.HelpPage.Name = "HelpPage";
            this.HelpPage.Padding = new System.Windows.Forms.Padding(3);
            this.HelpPage.Size = new System.Drawing.Size(1525, 672);
            this.HelpPage.TabIndex = 5;
            this.HelpPage.Text = "Помощь";
            this.HelpPage.UseVisualStyleBackColor = true;
            // 
            // BookmarkContextMenuStrip
            // 
            this.BookmarkContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.снятьВыделениеToolStripMenuItem,
            this.копироватьТекстToolStripMenuItem,
            this.переименоватьToolStripMenuItem});
            this.BookmarkContextMenuStrip.Name = "BookmarkContextMenuStrip";
            this.BookmarkContextMenuStrip.Size = new System.Drawing.Size(171, 70);
            // 
            // снятьВыделениеToolStripMenuItem
            // 
            this.снятьВыделениеToolStripMenuItem.Name = "снятьВыделениеToolStripMenuItem";
            this.снятьВыделениеToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.снятьВыделениеToolStripMenuItem.Text = "Снять выделение";
            this.снятьВыделениеToolStripMenuItem.Click += new System.EventHandler(this.СнятьВыделениеToolStripMenuItem_Click);
            // 
            // копироватьТекстToolStripMenuItem
            // 
            this.копироватьТекстToolStripMenuItem.Name = "копироватьТекстToolStripMenuItem";
            this.копироватьТекстToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.копироватьТекстToolStripMenuItem.Text = "Копировать текст";
            this.копироватьТекстToolStripMenuItem.Click += new System.EventHandler(this.КопироватьТекстToolStripMenuItem_Click);
            // 
            // переименоватьToolStripMenuItem
            // 
            this.переименоватьToolStripMenuItem.Name = "переименоватьToolStripMenuItem";
            this.переименоватьToolStripMenuItem.Size = new System.Drawing.Size(170, 22);
            this.переименоватьToolStripMenuItem.Text = "Переименовать";
            this.переименоватьToolStripMenuItem.Click += new System.EventHandler(this.ПереименоватьToolStripMenuItem_Click);
            // 
            // BookmarkDescriptionContextMenuStrip
            // 
            this.BookmarkDescriptionContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.копироватьТекстToolStripMenuItem1,
            this.изменитьОписаниеToolStripMenuItem});
            this.BookmarkDescriptionContextMenuStrip.Name = "BookmarkDescriptionContextMenuStrip";
            this.BookmarkDescriptionContextMenuStrip.Size = new System.Drawing.Size(185, 48);
            // 
            // копироватьТекстToolStripMenuItem1
            // 
            this.копироватьТекстToolStripMenuItem1.Name = "копироватьТекстToolStripMenuItem1";
            this.копироватьТекстToolStripMenuItem1.Size = new System.Drawing.Size(184, 22);
            this.копироватьТекстToolStripMenuItem1.Text = "Копировать текст";
            this.копироватьТекстToolStripMenuItem1.Click += new System.EventHandler(this.КопироватьТекстToolStripMenuItem1_Click);
            // 
            // изменитьОписаниеToolStripMenuItem
            // 
            this.изменитьОписаниеToolStripMenuItem.Name = "изменитьОписаниеToolStripMenuItem";
            this.изменитьОписаниеToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.изменитьОписаниеToolStripMenuItem.Text = "Изменить описание";
            this.изменитьОписаниеToolStripMenuItem.Click += new System.EventHandler(this.ИзменитьОписаниеToolStripMenuItem_Click);
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1584, 861);
            this.Controls.Add(this.MainWindowPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MinimumSize = new System.Drawing.Size(1600, 900);
            this.Name = "MainWindow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Электронный учебник";
            this.Load += new System.EventHandler(this.MainWindow_Load);
            this.MainWindowPanel.ResumeLayout(false);
            this.TabControl.ResumeLayout(false);
            this.ContentsPage.ResumeLayout(false);
            this.ContentsPagePanel.ResumeLayout(false);
            this.ContentsContainer.Panel1.ResumeLayout(false);
            this.ContentsContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ContentsContainer)).EndInit();
            this.ContentsContainer.ResumeLayout(false);
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel1.ResumeLayout(false);
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator)).EndInit();
            this.ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator.ResumeLayout(false);
            this.ContentsBookmarkListAndBookmarkContentSeparator.Panel1.ResumeLayout(false);
            this.ContentsBookmarkListAndBookmarkContentSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ContentsBookmarkListAndBookmarkContentSeparator)).EndInit();
            this.ContentsBookmarkListAndBookmarkContentSeparator.ResumeLayout(false);
            this.CreatorModeCheckBoxAndContentSeparator.Panel1.ResumeLayout(false);
            this.CreatorModeCheckBoxAndContentSeparator.Panel1.PerformLayout();
            this.CreatorModeCheckBoxAndContentSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CreatorModeCheckBoxAndContentSeparator)).EndInit();
            this.CreatorModeCheckBoxAndContentSeparator.ResumeLayout(false);
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Panel1.ResumeLayout(false);
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator)).EndInit();
            this.ContentsBookmarkListEditorAndBookmarkContentEditorSeparator.ResumeLayout(false);
            this.ContentsBookmarkListEditor.Panel1.ResumeLayout(false);
            this.ContentsBookmarkListEditor.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ContentsBookmarkListEditor)).EndInit();
            this.ContentsBookmarkListEditor.ResumeLayout(false);
            this.AddBookmarkIconAndButtonSeparator.Panel1.ResumeLayout(false);
            this.AddBookmarkIconAndButtonSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AddBookmarkIconAndButtonSeparator)).EndInit();
            this.AddBookmarkIconAndButtonSeparator.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AddBookmarkIcon)).EndInit();
            this.RemoveBookmarkIconAndButtonSeparator.Panel1.ResumeLayout(false);
            this.RemoveBookmarkIconAndButtonSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.RemoveBookmarkIconAndButtonSeparator)).EndInit();
            this.RemoveBookmarkIconAndButtonSeparator.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.RemoveBookmarkIcon)).EndInit();
            this.BookmarkContentEditorAndRemover.Panel1.ResumeLayout(false);
            this.BookmarkContentEditorAndRemover.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkContentEditorAndRemover)).EndInit();
            this.BookmarkContentEditorAndRemover.ResumeLayout(false);
            this.BookmarkContentEditor.Panel1.ResumeLayout(false);
            this.BookmarkContentEditor.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkContentEditor)).EndInit();
            this.BookmarkContentEditor.ResumeLayout(false);
            this.BookmarkDescriptionAndInfoContainer.Panel1.ResumeLayout(false);
            this.BookmarkDescriptionAndInfoContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkDescriptionAndInfoContainer)).EndInit();
            this.BookmarkDescriptionAndInfoContainer.ResumeLayout(false);
            this.BookmarkDescritionAndDescriptionLabelSeparator.Panel1.ResumeLayout(false);
            this.BookmarkDescritionAndDescriptionLabelSeparator.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkDescritionAndDescriptionLabelSeparator)).EndInit();
            this.BookmarkDescritionAndDescriptionLabelSeparator.ResumeLayout(false);
            this.BookmarkDescriptionRichTextBoxBorderStylePanel.ResumeLayout(false);
            this.BookmarkTimeAndChapterContainer.Panel1.ResumeLayout(false);
            this.BookmarkTimeAndChapterContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkTimeAndChapterContainer)).EndInit();
            this.BookmarkTimeAndChapterContainer.ResumeLayout(false);
            this.BookmarkTimeInfoAndTimeInfoLabel.Panel1.ResumeLayout(false);
            this.BookmarkTimeInfoAndTimeInfoLabel.Panel2.ResumeLayout(false);
            this.BookmarkTimeInfoAndTimeInfoLabel.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkTimeInfoAndTimeInfoLabel)).EndInit();
            this.BookmarkTimeInfoAndTimeInfoLabel.ResumeLayout(false);
            this.BookmarkChapterAndChapterLabel.Panel1.ResumeLayout(false);
            this.BookmarkChapterAndChapterLabel.Panel2.ResumeLayout(false);
            this.BookmarkChapterAndChapterLabel.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BookmarkChapterAndChapterLabel)).EndInit();
            this.BookmarkChapterAndChapterLabel.ResumeLayout(false);
            this.GlossaryPage.ResumeLayout(false);
            this.VideosPage.ResumeLayout(false);
            this.VideosPanel.ResumeLayout(false);
            this.BookmarkContextMenuStrip.ResumeLayout(false);
            this.BookmarkDescriptionContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel MainWindowPanel;
        private System.Windows.Forms.TabControl TabControl;
        private System.Windows.Forms.TabPage ContentsPage;
        private System.Windows.Forms.Panel ContentsPagePanel;
        private System.Windows.Forms.SplitContainer ContentsContainer;
        private System.Windows.Forms.TabPage GlossaryPage;
        private System.Windows.Forms.Panel GlossaryPagePanel;
        private System.Windows.Forms.TabPage LiteraturePage;
        private System.Windows.Forms.TabPage VideosPage;
        private System.Windows.Forms.TabPage ExamPage;
        private System.Windows.Forms.TabPage HelpPage;
        private System.Windows.Forms.SplitContainer ContentsContentAndBookmarkListAndBookmarkContentEditorSeparator;
        private System.Windows.Forms.SplitContainer ContentsBookmarkListAndBookmarkContentSeparator;
        private System.Windows.Forms.TreeView ContentsBookmarkList;
        private System.Windows.Forms.RichTextBox BookmarkContentRichTextBox;
        private System.Windows.Forms.SplitContainer ContentsBookmarkListEditorAndBookmarkContentEditorSeparator;
        private System.Windows.Forms.SplitContainer ContentsBookmarkListEditor;
        private System.Windows.Forms.SplitContainer AddBookmarkIconAndButtonSeparator;
        private System.Windows.Forms.PictureBox AddBookmarkIcon;
        private System.Windows.Forms.Button AddBookmarkButton;
        private System.Windows.Forms.SplitContainer RemoveBookmarkIconAndButtonSeparator;
        private System.Windows.Forms.PictureBox RemoveBookmarkIcon;
        private System.Windows.Forms.Button RemoveBookmarkButton;
        private System.Windows.Forms.SplitContainer BookmarkContentEditorAndRemover;
        private System.Windows.Forms.SplitContainer BookmarkContentEditor;
        private System.Windows.Forms.Button AddBookmarkContentButton;
        private System.Windows.Forms.Button EditBookmarkContentButton;
        private System.Windows.Forms.Button RemoveBookmarkContentButton;
        private System.Windows.Forms.SplitContainer BookmarkDescriptionAndInfoContainer;
        private System.Windows.Forms.SplitContainer BookmarkTimeAndChapterContainer;
        private System.Windows.Forms.SplitContainer BookmarkDescritionAndDescriptionLabelSeparator;
        private System.Windows.Forms.Label BookmarkDescriptionLabel;
        private System.Windows.Forms.SplitContainer BookmarkTimeInfoAndTimeInfoLabel;
        private System.Windows.Forms.Label BookmarkTimeInfoLabel;
        private System.Windows.Forms.SplitContainer BookmarkChapterAndChapterLabel;
        private System.Windows.Forms.Label BookmarkChapterInfoLabel;
        private System.Windows.Forms.Panel BookmarkDescriptionRichTextBoxBorderStylePanel;
        private System.Windows.Forms.RichTextBox BookmarkDescriptionRichTextBox;
        private System.Windows.Forms.TextBox BookmarkTimeInfoTextBox;
        private System.Windows.Forms.TextBox BookmarkChapterInfoTextBox;
        private System.Windows.Forms.Button SaveAllDataButton;
        private System.Windows.Forms.Panel VideosPanel;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ContextMenuStrip BookmarkContextMenuStrip;
        private System.Windows.Forms.ContextMenuStrip BookmarkDescriptionContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem снятьВыделениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem копироватьТекстToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem переименоватьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem копироватьТекстToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem изменитьОписаниеToolStripMenuItem;
        private System.Windows.Forms.SplitContainer CreatorModeCheckBoxAndContentSeparator;
        private System.Windows.Forms.CheckBox CreatorModeCheckBox;
        private System.Windows.Forms.FolderBrowserDialog BookmarkFolderBrowserDialog;
    }
}

