﻿using Microsoft.Office.Interop.Word;
using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using DataManipulator;
using DictionariesKeeper;

namespace Digital_schoolbook
{
    public partial class MainWindow : Form
    {
        private readonly DataManipulatorClass CurrentData = null; // переменная хранимых данных проекта

        public MainWindow()
        {
            InitializeComponent();

            CurrentData = DataManipulatorClass.LoadData(); // переменная загруженных данных проекта

            ProjectMethods = new() // создание экземпляра класса методов главной формы
            {
                _CurrentData = CurrentData, // передача ссылки на переменную хранимых данных проекта экземпляру класса
                _ContentsBookmarkList = ContentsBookmarkList, // передача ссылки на дерево закладок экземпляру класса
                _BookmarkDescriptionRichTextBox = BookmarkDescriptionRichTextBox, // передача ссылки на текстовое поле описания закладки экземпляру класса
                _BookmarkTimeInfoTextBox = BookmarkTimeInfoTextBox, // передача ссылки на текстовое поле времени создания / редактирования закладки экземпляру класса
                _BookmarkChapterInfoTextBox = BookmarkChapterInfoTextBox, // передача ссылки на текстовое поле главы закладки экземпляру класса
                _BookmarkContentRichTextBox = BookmarkContentRichTextBox, // передача ссылки на текстовое поле содержимого закладки экземпляру класса
                _CreatorModeCheckBox = CreatorModeCheckBox // передача ссылки на чек-бокс смены режима редактирования содержимого закладки экземпляру класса
            };

            ProjectMethods.LoadSavedData(); // осуществление загрузки сохранённых данных
        }

        // Инициализация экземпляров классов и элементов //
        public readonly ProjectMethodsClass ProjectMethods; // инициализация экземпляра класса методов главной формы
        public MainWindow MainWindowForm; // инициализация экземпляра главной формы
        private Label MissingBookmarkMessageLabel; // инициализация экземпляра ярлыка отсутствия закладок
        private WebBrowser LinkWebBrowser; // инициализация экземпляра веб-браузера
        private Form WebBrowserForm; // инициализация экземпляра формы веб-браузера

        // События //

        // Событие загрузки главной формы
        private void MainWindow_Load(object sender, EventArgs e)
        {
            MissingBookmarkMessageLabel = new()
            {
                Parent = CreatorModeCheckBoxAndContentSeparator.Panel2,
                BorderStyle = BorderStyle.None,
                Font = new("Microsoft Sans Serif", 25f, FontStyle.Regular),
                Text = "Вы пока не создали ни одной закладки!",
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill
            };

            MissingBookmarkMessageLabel.Paint += MissingBookmarkMessageLabel_Paint; // подписка на событие отрисовки ярлыка отсутствия закладок

            if (ContentsBookmarkList.Nodes.Count == 0)
            {
                MissingBookmarkMessageLabel.Show();
                BookmarkContentRichTextBox.Hide();
                BookmarkContentEditorAndRemover.Hide();
            }

            else
            {
                CreatorModeCheckBox.Checked = true;
                MissingBookmarkMessageLabel.Hide();
            }
        }

        // Событие отрисовки ярлыка отсутствия закладок
        private void MissingBookmarkMessageLabel_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new(Color.Black, 2)
            {
                DashPattern = new float[] { 2, 2 }
            };

            e.Graphics.DrawRectangle(pen, 1, 1, MissingBookmarkMessageLabel.Width - 2, MissingBookmarkMessageLabel.Height - 2);

            MissingBookmarkMessageLabel.Paint -= MissingBookmarkMessageLabel_Paint; // отподписка от события отрисовки ярлыка отсутствия закладок
        }

        // Событие нажатия на чек-бокс для смены режима редактирования содержимого закладки [!]
        private void CreatorModeCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            switch (CreatorModeCheckBox.Checked)
            {
                case true: // режим редактирования содержимого закладки

                    CreatorModeCheckBox.ForeColor = Color.Red;

                    if (ContentsBookmarkList.Nodes.Count != 0)
                    {
                        BookmarkContentRichTextBox.Show();
                        BookmarkContentEditorAndRemover.Show();
                        MissingBookmarkMessageLabel.Hide();
                    }

                    else
                    {
                        MissingBookmarkMessageLabel.Show();
                        BookmarkContentRichTextBox.Hide();
                        BookmarkContentEditorAndRemover.Hide();
                    }

                    break;

                case false: // режим работы с файлами

                    CreatorModeCheckBox.ForeColor = Color.Black;
                    BookmarkContentRichTextBox.Hide();
                    BookmarkContentEditorAndRemover.Hide();

                    if (ContentsBookmarkList.Nodes.Count != 0)
                    {
                        using (new FolderBrowserDialogSize(this)
                        {
                            DialogSize = new(700, 500)
                        })

                        {
                            FolderBrowserDialog CurrentFolderBrowserDialog = BookmarkFolderBrowserDialog;

                            if (ContentsBookmarkList.SelectedNode != null)
                            {
                                CurrentFolderBrowserDialog.SelectedPath = Path.Combine(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое электронного учебника]"), ContentsBookmarkList.SelectedNode.FullPath);
                            }

                            else
                            {
                                CurrentFolderBrowserDialog.SelectedPath = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое электронного учебника]");
                            }

                            DialogResult CurrentFolderBrowserDialogResult = CurrentFolderBrowserDialog.ShowDialog();

                            if (CurrentFolderBrowserDialogResult == DialogResult.Cancel || CurrentFolderBrowserDialogResult == DialogResult.OK /* <- временная мера*/)
                            {
                                ProjectMethods.FlipCreatorModeCheckBox();
                            }
                        }
                    }

                    else
                    {
                        MissingBookmarkMessageLabel.Show();
                    }

                    break;

                default:

                    throw new("Неизвестное значение чек-бокса режима редактирования содержимого закладки! \n(Возможно, данные приложения были повреждены)");
            }
        }

        // Событие создания новой закладки
        private void AddBookmarkButton_Click(object sender, EventArgs e)
        {
            ProjectMethods.CreateBookmark();

            ICreateForm BookmarkEditorForm = new CreateBookmarkEditorFormClass();
            BookmarkEditorForm.GetParameters(ContentsBookmarkList, BookmarkDescriptionRichTextBox, BookmarkTimeInfoTextBox, BookmarkChapterInfoTextBox, BookmarkContentRichTextBox, CreatorModeCheckBox, MissingBookmarkMessageLabel, BookmarkContentEditorAndRemover);
            BookmarkEditorForm.CreateForm(BookmarkEditorForm, MainWindowForm = this);
        }

        // Событие нажатия на выбранную закладку [!]
        private async void ContentsBookmarkList_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            string SelectedNode = e.Node.Text;

            if (DictionariesKeeperClass.ContentsBookmarkDictionary[SelectedNode].Item1 != null)
            {
                BookmarkDescriptionRichTextBox.Text = DictionariesKeeperClass.ContentsBookmarkDictionary[SelectedNode].Item1;
            }

            else
            {
                BookmarkDescriptionRichTextBox.Text = "[Описание отсутствует]";
            }

            if (BookmarkDescriptionRichTextBox.Lines.Length > 10 || BookmarkDescriptionRichTextBox.TextLength > 770 || (BookmarkDescriptionRichTextBox.Lines.Length > 0 && BookmarkDescriptionRichTextBox.TextLength > 55))
            {
                BookmarkDescriptionRichTextBox.ScrollBars = RichTextBoxScrollBars.Vertical;
            }

            else
            {
                BookmarkDescriptionRichTextBox.ScrollBars = RichTextBoxScrollBars.None;
            }

            string BookmarkTimestamp = DictionariesKeeperClass.ContentsBookmarkDictionary[SelectedNode].Item2;
            BookmarkTimeInfoTextBox.Text = BookmarkTimestamp;

            if (DictionariesKeeperClass.ContentsBookmarkDictionary[SelectedNode].Item3 != null)
            {
                BookmarkChapterInfoTextBox.Text = DictionariesKeeperClass.ContentsBookmarkDictionary[SelectedNode].Item3;
            }

            else
            {
                BookmarkChapterInfoTextBox.Text = "[Глава отсутствует]";
            }

            if (DictionariesKeeperClass.ContentsBookmarkDictionary[SelectedNode].Item4 != null)
            {
                string BookmarkContentFilePath = Path.Combine(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое закладок]"), "[" + SelectedNode + "]" + " (содержимое)"); // путь к файлу содержимого закладки
                string BookmarkContentRTFFile = BookmarkContentFilePath + ".rtf"; // файл содержимого закладки в формате RTF
                string BookmarkContentDOCXFile = BookmarkContentFilePath + ".docx"; // файл содержимого закладки в формате DOCX

                if (File.Exists(BookmarkContentRTFFile))
                {
                    BookmarkContentRichTextBox.ReadOnly = false;
                    BookmarkContentRichTextBox.LoadFile(BookmarkContentRTFFile);
                    BookmarkContentRichTextBox.ReadOnly = true;
                }

                else if (File.Exists(BookmarkContentDOCXFile))
                {
                    await System.Threading.Tasks.Task.Run(() =>
                    {
                        Invoke((MethodInvoker)delegate
                        {
                            Microsoft.Office.Interop.Word.Application WordApplication = new()
                            {
                                Visible = false
                            };

                            string BookmarkContentFile = Path.GetFileNameWithoutExtension(BookmarkContentFilePath); // название файла содержимого закладки

                            Document NewWordDocument = WordApplication.Documents.Open(BookmarkContentFilePath + ".docx");

                            NewWordDocument.SaveAs2(BookmarkContentRTFFile, WdSaveFormat.wdFormatRTF); // временный rtf-файл
                            NewWordDocument.Close();

                            WordApplication.Quit();

                            GC.Collect(); // вызов "сборщика" мусора для высвобождения памяти
                            GC.WaitForPendingFinalizers(); // высвобождение памяти
                        });
                    });

                    BookmarkContentRichTextBox.ReadOnly = false;
                    BookmarkContentRichTextBox.LoadFile(BookmarkContentRTFFile);
                    BookmarkContentRichTextBox.ReadOnly = true;
                    File.Delete(BookmarkContentRTFFile);
                }

                else
                {
                    BookmarkContentRichTextBox.Text = DictionariesKeeperClass.ContentsBookmarkDictionary[SelectedNode].Item4;
                }
            }

            else
            {
                BookmarkContentRichTextBox.Text = "[Содержимое закладки отсутствует]";
            }
        }

        // Событие удаления выбранной закладки
        private void RemoveBookmarkButton_Click(object sender, EventArgs e)
        {
            ProjectMethods.DeleteCurrentBookmark(ContentsBookmarkList.SelectedNode);

            if (ContentsBookmarkList.Nodes.Count == 0)
            {
                MissingBookmarkMessageLabel.Show();
                BookmarkContentRichTextBox.Hide();
                BookmarkContentEditorAndRemover.Hide();
            }
        }

        // Событие создания содержимого выбранной закладки
        private void AddBookmarkContentButton_Click(object sender, EventArgs e)
        {
            if (ContentsBookmarkList.SelectedNode == null)
            {
                MessageBox.Show("Вы не выбрали закладку для добавления содержимого!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            else if (DictionariesKeeperClass.ContentsBookmarkDictionary[ContentsBookmarkList.SelectedNode.Text].Item4 != null)
            {
                MessageBox.Show("Содержимое закладки уже существует!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ICreateForm BookmarkContentEditorForm = new CreateBookmarkContentEditorForm();
            BookmarkContentEditorForm.GetParameters(ContentsBookmarkList, BookmarkDescriptionRichTextBox, BookmarkTimeInfoTextBox, BookmarkChapterInfoTextBox, BookmarkContentRichTextBox, CreatorModeCheckBox, MissingBookmarkMessageLabel, BookmarkContentEditorAndRemover);
            BookmarkContentEditorForm.CreateForm(BookmarkContentEditorForm, MainWindowForm = this);
        }

        public static bool EditBookmarkContentButton_Clicked = false; // переменная события нажатия кнопки редактирования содержимого закладки

        // Событие редактирования содержимого выбранной закладки
        private void EditBookmarkContentButton_Click(object sender, EventArgs e)
        {
            if (ContentsBookmarkList.SelectedNode == null)
            {
                MessageBox.Show("Вы не выбрали закладку для редактирования содержимого!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            else if (DictionariesKeeperClass.ContentsBookmarkDictionary[ContentsBookmarkList.SelectedNode.Text].Item4 == null)
            {
                MessageBox.Show("Содержимое закладки для редактирования отсутствует!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            EditBookmarkContentButton_Clicked = true;

            ICreateForm BookmarkContentEditorForm = new CreateBookmarkContentEditorForm();
            BookmarkContentEditorForm.GetParameters(ContentsBookmarkList, BookmarkDescriptionRichTextBox, BookmarkTimeInfoTextBox, BookmarkChapterInfoTextBox, BookmarkContentRichTextBox, CreatorModeCheckBox, MissingBookmarkMessageLabel, BookmarkContentEditorAndRemover);
            BookmarkContentEditorForm.CreateForm(BookmarkContentEditorForm, MainWindowForm = this);

            EditBookmarkContentButton_Clicked = false;
        }

        // Событие удаления содержимого выбранной закладки
        private void RemoveBookmarkContentButton_Click(object sender, EventArgs e)
        {
            if (ContentsBookmarkList.SelectedNode == null)
            {
                MessageBox.Show("Вы не выбрали закладку для удаления содержимого!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            else if (DictionariesKeeperClass.ContentsBookmarkDictionary[ContentsBookmarkList.SelectedNode.Text].Item4 == null)
            {
                MessageBox.Show("Содержимое закладки для удаления отсутствует!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult RemoveBookmarkContentDialogResult = MessageBox.Show("Вы действительно хотите очистить содержимое данной закладки?", "Удаление содержимого", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (RemoveBookmarkContentDialogResult == DialogResult.Yes)
            {
                DictionariesKeeperClass.ContentsBookmarkDictionary[ContentsBookmarkList.SelectedNode.Text] = new Tuple<string, string, string, string>(DictionariesKeeperClass.ContentsBookmarkDictionary[ContentsBookmarkList.SelectedNode.Text].Item1, DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss"), DictionariesKeeperClass.ContentsBookmarkDictionary[ContentsBookmarkList.SelectedNode.Text].Item3, null);

                BookmarkTimeInfoTextBox.Text = DictionariesKeeperClass.ContentsBookmarkDictionary[ContentsBookmarkList.SelectedNode.Text].Item2;
                BookmarkContentRichTextBox.Text = "[Содержимое закладки отсутствует]";
            }
        }

        // Событие нажатия на ссылку в описании закладки
        private void BookmarkDescriptionRichTextBox_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            OpenLinkInWebBrowser(e.LinkText);
        }

        // Событие нажатия на ссылку в содержимом закладки
        private void BookmarkContentRichTextBox_LinkClicked(object sender, LinkClickedEventArgs e)
        {
            OpenLinkInWebBrowser(e.LinkText);
        }

        // Событие перехода веб-браузера по ссылке
        private void LinkWebBrowser_Navigated(object sender, WebBrowserNavigatedEventArgs e)
        {
            ProjectMethods.SetWebBrowserCompatibilityLevel();
            LinkWebBrowser.Navigated -= LinkWebBrowser_Navigated;
        }

        // Событие закрытия формы веб-браузера
        private void WebBrowserForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            WebBrowserForm.FormClosed -= WebBrowserForm_FormClosed;
            WebBrowserForm.Close();
            LinkWebBrowser.Dispose();
            WebBrowserForm.Dispose();
            GC.Collect(); // вызов "сборщика" мусора для высвобождения памяти
            GC.WaitForPendingFinalizers(); // высвобождение памяти
        }

        // Событие нажатия ПКМ по закладке
        private void ContentsBookmarkList_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && ContentsBookmarkList.SelectedNode != null)
            {
                BookmarkContextMenuStrip.Show(Cursor.Position, ToolStripDropDownDirection.Right);
            }
        }

        // Событие снятия выделения с закладки
        private void СнятьВыделениеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ContentsBookmarkList.SelectedNode = null;
        }

        // Событие копирования текста закладки в буфер обмена
        private void КопироватьТекстToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(ContentsBookmarkList.SelectedNode.Text);
        }

        public static bool EditBookmarkContextMenu_Clicked = false; // переменная события нажатия кнопки редактирования названия закладки

        // Событие изменения названия закладки
        private void ПереименоватьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditBookmarkContextMenu_Clicked = true;

            ICreateForm BookmarkEditorForm = new CreateBookmarkEditorFormClass();
            BookmarkEditorForm.GetParameters(ContentsBookmarkList, BookmarkDescriptionRichTextBox, BookmarkTimeInfoTextBox, BookmarkChapterInfoTextBox, BookmarkContentRichTextBox, CreatorModeCheckBox, MissingBookmarkMessageLabel, BookmarkContentEditorAndRemover);
            BookmarkEditorForm.CreateForm(BookmarkEditorForm, MainWindowForm = this);

            EditBookmarkContextMenu_Clicked = false;
        }

        // Событие нажатие ПКМ по описанию закладки
        private void BookmarkDescriptionRichTextBox_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right && BookmarkDescriptionRichTextBox.Text != "")
            {
                BookmarkDescriptionContextMenuStrip.Show(Cursor.Position, ToolStripDropDownDirection.Right);
            }
        }

        // Событие копирования текста описания закладки в буфер обмена
        private void КопироватьТекстToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(BookmarkDescriptionRichTextBox.Text);
        }

        public static bool EditBookmarkDescriptionContextMenu_Clicked = false; // переменная события нажатия кнопки редактирования описания закладки

        // Событие изменения описания закладки
        private void ИзменитьОписаниеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditBookmarkDescriptionContextMenu_Clicked = true;

            ICreateForm BookmarkEditorForm = new CreateBookmarkEditorFormClass();
            BookmarkEditorForm.GetParameters(ContentsBookmarkList, BookmarkDescriptionRichTextBox, BookmarkTimeInfoTextBox, BookmarkChapterInfoTextBox, BookmarkContentRichTextBox, CreatorModeCheckBox, MissingBookmarkMessageLabel, BookmarkContentEditorAndRemover);
            BookmarkEditorForm.CreateForm(BookmarkEditorForm, MainWindowForm = this);

            EditBookmarkDescriptionContextMenu_Clicked = false;

            ActiveControl = null; // снятие фокуса с текстового окна описания закладки
        }

        // Событие сохранения всех данных по нажатию на кнопку
        private void SaveAllDataButton_Click(object sender, EventArgs e)
        {
            ProjectMethods.TreeViewDividerAndSaver();
            ProjectMethods.ContentsBookmarkListDividerAndSaver();
            CurrentData.SaveData();
        }

        // Методы //

        // Метод открытия ссылки в веб-браузере
        public void OpenLinkInWebBrowser(string CurrentLink)
        {
            WebBrowserForm = new() // создание экземпляра формы веб-браузера
            {
                Size = new(1200, 800),
                StartPosition = FormStartPosition.CenterScreen,
                ShowIcon = false
            };

            LinkWebBrowser = new() // создание экземпляра веб-браузера
            {
                Parent = WebBrowserForm,
                Dock = DockStyle.Fill,
                ScriptErrorsSuppressed = true,
                AllowNavigation = true,
                AllowWebBrowserDrop = true,
                IsWebBrowserContextMenuEnabled = true,
                ScrollBarsEnabled = true,
                WebBrowserShortcutsEnabled = true,
                Url = new("http://google.com")
            };

            LinkWebBrowser.Navigated += LinkWebBrowser_Navigated; // подписка на событие перехода веб-браузера по ссылке
            WebBrowserForm.FormClosed += WebBrowserForm_FormClosed; // подписка на событие закрытия формы веб-браузера

            LinkWebBrowser.Navigate(CurrentLink);

            WebBrowserForm.Show();

            ContentsBookmarkList.SelectedNode = null; // снятие выделения с закладки
        }
    }
}