﻿using Microsoft.Office.Interop.Word;
using System;
using System.IO;
using System.Windows.Forms;
using DictionariesKeeper;
//using System.Windows.Documents;

namespace Digital_schoolbook
{
    public partial class BookmarkContentEditor : Form
    {
        public BookmarkContentEditor()
        {
            InitializeComponent();

            BookmarkContentOpenFileDialog.Filter = "Текстовые документы (*.txt)|*.txt|Документ Word (*.docx)|*.docx|Текст в формате RTF (*.rtf)|*.rtf|Файлы закладок 'Электронного учебника' (*.bkm)|*.bkm|Все файлы (*.*)|*.*";
            BookmarkContentSaveFileDialog.Filter = "Текстовые документы (*.txt)|*.txt|Документ Word (*.docx)|*.docx|Текст в формате RTF (*.rtf)|*.rtf|Файлы закладок 'Электронного учебника' (*.bkm)|*.bkm|Все файлы (*.*)|*.*";
        }

        // Инициализация экземпляров классов и форм //
        private BookmarkContentEditorMethodsClass BookmarkContentEditorMethods; // инициализация экземпляра класса методов формы оформления содержимого закладки

        // Получение ссылок //
        public TreeView _ContentsBookmarkList;
        public RichTextBox _BookmarkContentRichTextBox;
        public RichTextBox _BookmarkDescriptionRichTextBox;
        public TextBox _BookmarkTimeInfoTextBox;
        public TextBox _BookmarkChapterInfoTextBox;

        // Создание событий //
        private event EventHandler SaveButton_Clicked; // создание события проверки нажатия кнопки сохранения содержимого главы
        private event EventHandler SaveAsButton_Clicked; // создание события проверки нажатия кнопки "сохранить как" содержимого главы

        // События //

        private string FileExtension; // переменная расширения файла

        // Событие открытия файла содержимого закладки
        private void ОткрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (BookmarkContentOpenFileDialog.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }

            FileExtension = Path.GetExtension(BookmarkContentOpenFileDialog.FileName);

            switch (FileExtension)
            {
                case ".txt":
                    {
                        File.ReadAllText(BookmarkContentOpenFileDialog.FileName);

                        break;
                    }

                case ".docx":
                    {
                        /*Microsoft.Office.Interop.Word.Application wordApp = new();
                        Object docxFileName = BookmarkContentOpenFileDialog.FileName;
                        Object missing = Type.Missing;

                        wordApp.Documents.Open(ref docxFileName, ref missing,
                            ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing, ref missing, ref missing,
                            ref missing, ref missing);
                        
                        //путь к папке с временными файлами
                        string temp = Path.GetTempPath();
                        
                        //для передачи параметров при пересохранении
                        Object lookComments = false;
                        Object password = String.Empty;
                        Object AddToRecentFiles = true;
                        Object WritePassword = String.Empty;
                        Object ReadOnlyRecommended = false;
                        Object EmbedTrueTypeFonts = false;
                        Object SaveFormsData = false;
                        Object SaveAsAOCELetter = false;
                        
                        //имя файла без расширения
                        Object rtfFileName = BookmarkContentOpenFileDialog.SafeFileName.Substring(0, BookmarkContentOpenFileDialog.SafeFileName.Length - ".docx".Length);
                        //создали рандом
                        Random random = new();
                        
                        //проверяем есть ли файл с таким именем
                        while (System.IO.File.Exists(rtfFileName + ".rtf"))
                        {
                            //генерируем случайное имя файла
                            rtfFileName += random.Next(0, 9).ToString();
                        }
                        
                        //формат RTF
                        Object wdFormatRTF = WdSaveFormat.wdFormatRTF;
                        //приписали расширение
                        rtfFileName += ".rtf";
                        //приписали путь к временным файлам
                        rtfFileName = temp + rtfFileName;
                        //пересохранили
                        wordApp.ActiveDocument.SaveAs(ref rtfFileName,
                            ref wdFormatRTF, ref lookComments, ref password, ref AddToRecentFiles, ref WritePassword, ref ReadOnlyRecommended,
                            ref EmbedTrueTypeFonts, ref missing, ref SaveFormsData, ref SaveAsAOCELetter, ref missing,
                            ref missing, ref missing, ref missing, ref missing);

                        Object @false = false;
                        //закрыли текущий документ
                        wordApp.ActiveDocument.Close(ref @false, ref missing, ref missing);
                        //вышли из ворда
                        wordApp.Quit(ref @false, ref missing, ref missing);

                        TextRange tr = new(RichSource.Document.ContentStart, RichSource.Document.ContentEnd);
                        
                        using (FileStream fs = File.Open((String)rtfFileName, FileMode.Open))
                        {
                            tr.Load(fs, DataFormats.Rtf);
                        }*/

                        break;
                    }

                /*case ".pdf":
                    {
                        // Открытие файла PDF с помощью приложения Adobe Acrobat
                        var acrobatApp = new AcroApp();
                        var acrobatDoc = new AcroAVDoc();
                        acrobatDoc.Open(BookmarkContentOpenFileDialog.FileName, "");
                        acrobatApp.Show();
                        break;
                    }*/

                case ".pdf":
                    {
                        // Открытие файла PDF с помощью приложения по умолчанию
                        System.Diagnostics.Process.Start(BookmarkContentOpenFileDialog.FileName);
                        break;
                    }

                case ".pptx":
                    {
                        // Открытие файла .pptx с помощью приложения Microsoft PowerPoint
                        var powerPointApp = new Microsoft.Office.Interop.PowerPoint.Application();
                        var powerPointPresentation = powerPointApp.Presentations.Open(BookmarkContentOpenFileDialog.FileName);
                        powerPointApp.Visible = Microsoft.Office.Core.MsoTriState.msoTrue;
                        break;
                    }

                default:
                    {
                        BookmarkContentRichTextBox.LoadFile(BookmarkContentOpenFileDialog.FileName, RichTextBoxStreamType.RichText);

                        break;
                    }
            }
        }

        private string BookmarkName; // название закладки
        private string BookmarkDescription; // описание закладки
        private string BookmarkTimestamp; // время создания / редактирования закладки
        private string BookmarkParent; // родитель закладки

        // Событие сохранения содержимого закладки [!]
        private void СохранитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookmarkName = _ContentsBookmarkList.SelectedNode.Text;
            BookmarkDescription = DictionariesKeeperClass.ContentsBookmarkDictionary[BookmarkName].Item1;
            BookmarkTimestamp = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");
            BookmarkParent = DictionariesKeeperClass.ContentsBookmarkDictionary[BookmarkName].Item3;

            DictionariesKeeperClass.ContentsBookmarkDictionary[BookmarkName] = new Tuple<string, string, string, string>(BookmarkDescription, BookmarkTimestamp, BookmarkParent, BookmarkContentRichTextBox.Text); // создание / замена содержимого закладки в словаре

            BookmarkContentEditorMethods = new()
            {
                _BookmarkContentRichTextBox = BookmarkContentRichTextBox
            };

            BookmarkContentEditorMethods.CreateBookmarkContentTextFileCopy(_ContentsBookmarkList.SelectedNode);

            SaveButton_Clicked += СохранитьToolStripMenuItem_Click;

            _BookmarkContentRichTextBox.Text = DictionariesKeeperClass.ContentsBookmarkDictionary[BookmarkName].Item4; // добавление в текстовое поле главной формы содержимого закладки
            _ContentsBookmarkList.SelectedNode = null;

            Close();
            Dispose(true);
        }

        // Событие сохранения содержимого закладки в файл ("сохранить как") [!]
        private async void СохранитьКакToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BookmarkName = _ContentsBookmarkList.SelectedNode.Text;
            BookmarkDescription = DictionariesKeeperClass.ContentsBookmarkDictionary[BookmarkName].Item1;
            BookmarkParent = DictionariesKeeperClass.ContentsBookmarkDictionary[BookmarkName].Item3;

            if (!Directory.Exists(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое закладок]"))) // проверка наличия папки с текстовыми файлами содержимого закладок
            {
                Directory.CreateDirectory(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое закладок]")); // создание папки c текстовыми файлами содержимого закладок
            }

            BookmarkContentSaveFileDialog.InitialDirectory = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое закладок]");
            BookmarkContentSaveFileDialog.FileName = $"[{_ContentsBookmarkList.SelectedNode.Text}] (содержимое)";

            if (BookmarkContentSaveFileDialog.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }

            BookmarkTimestamp = DateTime.Now.ToString("dd.MM.yyyy HH:mm:ss");

            FileExtension = Path.GetExtension(BookmarkContentSaveFileDialog.FileName);

            switch (FileExtension)
            {
                case ".txt":
                    {
                        File.WriteAllText(BookmarkContentSaveFileDialog.FileName, BookmarkContentRichTextBox.Text);

                        break;
                    }

                case ".docx": // сохранение файла в формате Word
                    {
                        await System.Threading.Tasks.Task.Run(() =>
                        {
                            Invoke((MethodInvoker)delegate
                            {
                                Microsoft.Office.Interop.Word.Application WordApplication = new()
                                {
                                    Visible = false
                                };

                                if (BookmarkContentRichTextBox.Rtf.Contains("{\\sv Image}")) // проверка наличия изображений в тексте
                                {
                                    string BookmarkContentFile = Path.GetFileNameWithoutExtension(BookmarkContentSaveFileDialog.FileName); // название файла содержимого закладки
                                    string BookmarkContentFilePath = Path.Combine(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое закладок]"), BookmarkContentFile); // путь к файлу содержимого закладки

                                    BookmarkContentRichTextBox.SaveFile(BookmarkContentFilePath + ".rtf", RichTextBoxStreamType.RichText); // временный rtf-файл
                                    Document NewWordDocument = WordApplication.Documents.Open(BookmarkContentFilePath + ".rtf");

                                    NewWordDocument.SaveAs2(BookmarkContentSaveFileDialog.FileName, WdSaveFormat.wdFormatXMLDocument);
                                    //NewWordDocument.SaveAs2(BookmarkContentSaveFileDialog.FileName, WdSaveFormat.wdFormatDocumentDefault); // сохранение файла в формате Word (больший размер)
                                    File.Delete(BookmarkContentFilePath + ".rtf");
                                    NewWordDocument.Close();
                                }

                                else
                                {
                                    Document WordDocument = WordApplication.Application.Documents.Add();
                                    WordDocument.Content.Text = BookmarkContentRichTextBox.Text;
                                    WordDocument.SaveAs2(BookmarkContentSaveFileDialog.FileName);
                                    WordDocument.Close();
                                }

                                WordApplication.Quit();

                                GC.Collect(); // вызов "сборщика" мусора для высвобождения памяти
                                GC.WaitForPendingFinalizers(); // высвобождение памяти
                            });
                        });

                        break;
                    }

                case ".pdf":
                    {
                        // Создание нового документа Word
                        var wordApp = new Microsoft.Office.Interop.Word.Application();
                        var wordDoc = wordApp.Documents.Add();

                        // Копирование текста из RichTextBox в документ Word
                        Clipboard.SetText(BookmarkContentRichTextBox.Text);
                        wordDoc.Content.Paste();

                        // Сохранение документа Word в формате PDF
                        var pdfFileName = BookmarkContentSaveFileDialog.FileName;
                        wordDoc.ExportAsFixedFormat(pdfFileName, Microsoft.Office.Interop.Word.WdExportFormat.wdExportFormatPDF);

                        // Закрытие документа Word и выход из приложения
                        wordDoc.Close(false);
                        wordApp.Quit();

                        break;
                    }

                case ".pptx":
                    {
                        // Создание новой презентации PowerPoint
                        var powerPointApp = new Microsoft.Office.Interop.PowerPoint.Application();
                        var powerPointPresentation = powerPointApp.Presentations.Add();

                        // Добавление нового слайда в презентацию
                        var slide = powerPointPresentation.Slides.Add(1, Microsoft.Office.Interop.PowerPoint.PpSlideLayout.ppLayoutText);
                        var textBox = slide.Shapes[1].TextFrame.TextRange;
                        textBox.Text = BookmarkContentRichTextBox.Text;

                        // Сохранение презентации в формате .pptx
                        powerPointPresentation.SaveAs(BookmarkContentSaveFileDialog.FileName);

                        // Закрытие презентации и выход из приложения PowerPoint
                        powerPointPresentation.Close();
                        powerPointApp.Quit();

                        break;
                    }

                default: // сохранение файла в формате Rich Text Format
                    {
                        BookmarkContentRichTextBox.SaveFile(BookmarkContentSaveFileDialog.FileName, RichTextBoxStreamType.RichText);

                        break;
                    }
            }

            DictionariesKeeperClass.ContentsBookmarkDictionary[BookmarkName] = new Tuple<string, string, string, string>(BookmarkDescription, BookmarkTimestamp, BookmarkParent, BookmarkContentRichTextBox.Text);

            BookmarkContentEditorMethods = new()
            {
                _BookmarkContentRichTextBox = BookmarkContentRichTextBox
            };

            BookmarkContentEditorMethods.CreateBookmarkContentTextFileCopy(_ContentsBookmarkList.SelectedNode);

            SaveAsButton_Clicked += СохранитьКакToolStripMenuItem_Click;

            _BookmarkContentRichTextBox.Text = DictionariesKeeperClass.ContentsBookmarkDictionary[BookmarkName].Item4;
            _ContentsBookmarkList.SelectedNode = null;

            Close();
            Dispose(true);
        }

        bool EditingExistingBookmarkContent = false; // переменная сигнала на редактирование уже существующего содержимого закладки

        // Событие проверки данных перед открытием формы
        private void BookmarkContentEditor_Load(object sender, EventArgs e)
        {
            if (MainWindow.EditBookmarkContentButton_Clicked)
            {
                EditingExistingBookmarkContent = true; // подача сигнала на редактирование уже существующего содержимого закладки
                BookmarkContentRichTextBox.Text = DictionariesKeeperClass.ContentsBookmarkDictionary[_ContentsBookmarkList.SelectedNode.Text].Item4;
            }
        }

        // Событие проверки данных перед закрытием формы
        private void BookmarkContentEditor_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (SaveButton_Clicked != null)
            {
                e.Cancel = false;
            }

            else if (SaveAsButton_Clicked != null)
            {
                e.Cancel = false;
            }

            else if (EditingExistingBookmarkContent)
            {
                if (BookmarkContentRichTextBox.Text == _BookmarkContentRichTextBox.Text) // проверка на изменение содержимого закладки
                {
                    e.Cancel = false;
                }

                else
                {
                    DialogResult SaveEditedBookmarkContentDialogResult = MessageBox.Show("Вы действительно хотите закрыть окно редакции содержимого закладки без сохранения содержимого?", "Выход из окна редактирования содержимого", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (SaveEditedBookmarkContentDialogResult == DialogResult.Yes)
                    {
                        e.Cancel = false;
                    }

                    else
                    {
                        e.Cancel = true;
                    }
                }
            }

            else if (BookmarkContentRichTextBox.Text != "")
            {
                DialogResult SaveBookmarkContentDialogResult = MessageBox.Show("Вы действительно хотите закрыть окно редакции содержимого закладки без сохранения содержимого?", "Выход из окна редактирования содержимого", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (SaveBookmarkContentDialogResult == DialogResult.Yes)
                {
                    e.Cancel = false;
                }

                else
                {
                    e.Cancel = true;
                }
            }

            else
            {
                e.Cancel = false;
            }

            SaveButton_Clicked -= СохранитьToolStripMenuItem_Click;
            SaveAsButton_Clicked -= СохранитьКакToolStripMenuItem_Click;
        }

        // Событие очистки данных главной формы после закрытия формы
        private void BookmarkContentEditor_FormClosed(object sender, FormClosedEventArgs e)
        {
            _BookmarkDescriptionRichTextBox.Text = null;
            _BookmarkTimeInfoTextBox.Text = null;
            _BookmarkChapterInfoTextBox.Text = null;
            _BookmarkContentRichTextBox.Text = null;
        }
    }
}