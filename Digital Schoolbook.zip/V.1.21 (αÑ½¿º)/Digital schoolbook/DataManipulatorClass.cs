﻿using System.IO;
using System.Xml.Serialization;

namespace DataManipulator
{
    public class DataManipulatorClass
    {
        // Метод сохранения данных в XML-файл (сериализация)
        public void SaveData()
        {
            string FileName = SavedDataFileName.SavedDataFileNameClass.SavedUserDataFileName;

            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }

            using FileStream CurrentFileStream = new(FileName, FileMode.Create);
            XmlSerializer FileXmlSerializer = new(typeof(DataManipulatorClass));
            FileXmlSerializer.Serialize(CurrentFileStream, this);
            CurrentFileStream.Close();
        }

        // Метод выгрузки данных из XML-файла (десериализация)
        public static DataManipulatorClass LoadData()
        {
            DataManipulatorClass CurrentData = null;
            string FileName = SavedDataFileName.SavedDataFileNameClass.SavedUserDataFileName;

            if (File.Exists(FileName))
            {
                using FileStream CurrentFileStream = new(FileName, FileMode.Open);
                XmlSerializer FileXmlSerializer = new(typeof(DataManipulatorClass));
                CurrentData = (DataManipulatorClass)FileXmlSerializer.Deserialize(CurrentFileStream);
                CurrentFileStream.Close();
            }

            else
            {
                CurrentData = new();
            }

            return CurrentData;
        }

        public int[] TreeViewNodeKey { get; set; }
        public int[] TreeViewParentKey { get; set; }
        public string[] TreeViewNodeText { get; set; }

        public string[] ContentsBookmarkDictionaryKeys { get; set; }
        public string[] ContentsBookmarkDictionaryDescriptions { get; set; }
        public string[] ContentsBookmarkDictionaryTimestamps { get; set; }
        public string[] ContentsBookmarkDictionaryParents { get; set; }
        public string[] ContentsBookmarkDictionaryContents { get; set; }
    }
}