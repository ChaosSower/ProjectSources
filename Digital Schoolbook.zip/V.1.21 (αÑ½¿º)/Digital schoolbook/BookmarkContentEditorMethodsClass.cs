﻿using System;
using System.IO;
using System.Windows.Forms;

namespace Digital_schoolbook
{
    public class BookmarkContentEditorMethodsClass
    {
        // Получение ссылок //
        public RichTextBox _BookmarkContentRichTextBox; // получение ссылки на текстовое поле главной формы содержания закладки

        // Методы //

        // Метод создания копии текстового файла содержимого закладки [!]
        public void CreateBookmarkContentTextFileCopy(TreeNode CurrentNode)
        {
            string BookmarkContentFileName = $"[{CurrentNode.Text}] (содержимое).txt"; // название текстового файла содержимого закладки
            string BookmarkContentFolderPath = Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое закладок]"); // путь папки с текстовыми файлами содержимого закладок

            if (!Directory.Exists(BookmarkContentFolderPath))
            {
                Directory.CreateDirectory(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое закладок]"));
            }

            string FullBookmarkContentPath = Path.Combine(Path.GetFullPath(AppDomain.CurrentDomain.BaseDirectory + @"\..\..\[Содержимое закладок]"), BookmarkContentFileName); // полный путь текстового файла содержимого закладки
            File.WriteAllText(FullBookmarkContentPath, _BookmarkContentRichTextBox.Text); // сохранение содержимого закладки в текстовый файл
        }
    }
}