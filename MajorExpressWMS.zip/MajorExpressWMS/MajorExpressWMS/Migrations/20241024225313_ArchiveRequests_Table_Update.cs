﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MajorExpressWMS.Migrations
{
    /// <inheritdoc />
    public partial class ArchiveRequests_Table_Update : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ArchiveRequests_RequestArchivers_ArchiverID",
                table: "ArchiveRequests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_Companies_CompanyID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_RequestCreators_CreatorID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_RequestExecutors_ExecutorID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_RequestStatuses_RequestStatusID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_RequestTypes_RequestTypeID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_UserRoles_UserRoleID",
                table: "Users");

            migrationBuilder.DropTable(name: "ArchiveRequests");

            migrationBuilder.CreateTable(
                name: "ArchiveRequests",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RequestNumber = table.Column<string>(nullable: false),
                    CreatorID = table.Column<int>(nullable: false),
                    RequestTypeID = table.Column<int>(nullable: false),
                    CreationDate = table.Column<DateTime>(nullable: false),
                    ArchiverID = table.Column<int>(nullable: false),
                    ArchiveDate = table.Column<DateTime>(nullable: false),
                    Description = table.Column<string>(nullable: true)
                });

            migrationBuilder.CreateIndex(
                name: "IX_ArchiveRequests_RequestTypeID",
                table: "ArchiveRequests",
                column: "RequestTypeID");

            migrationBuilder.AddForeignKey(
                name: "FK_ArchiveRequests_RequestArchivers_ArchiverID",
                table: "ArchiveRequests",
                column: "ArchiverID",
                principalTable: "RequestArchivers",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict); // изменено

            migrationBuilder.AddForeignKey(
                name: "FK_ArchiveRequests_RequestTypes_RequestTypeID",
                table: "ArchiveRequests",
                column: "RequestTypeID",
                principalTable: "RequestTypes",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_Companies_CompanyID",
                table: "Requests",
                column: "CompanyID",
                principalTable: "Companies",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_RequestCreators_CreatorID",
                table: "Requests",
                column: "CreatorID",
                principalTable: "RequestCreators",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_RequestExecutors_ExecutorID",
                table: "Requests",
                column: "ExecutorID",
                principalTable: "RequestExecutors",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict); // изменено

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_RequestStatuses_RequestStatusID",
                table: "Requests",
                column: "RequestStatusID",
                principalTable: "RequestStatuses",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_RequestTypes_RequestTypeID",
                table: "Requests",
                column: "RequestTypeID",
                principalTable: "RequestTypes",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_UserRoles_UserRoleID",
                table: "Users",
                column: "UserRoleID",
                principalTable: "UserRoles",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ArchiveRequests_RequestArchivers_ArchiverID",
                table: "ArchiveRequests");

            migrationBuilder.DropForeignKey(
                name: "FK_ArchiveRequests_RequestTypes_RequestTypeID",
                table: "ArchiveRequests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_Companies_CompanyID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_RequestCreators_CreatorID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_RequestExecutors_ExecutorID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_RequestStatuses_RequestStatusID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Requests_RequestTypes_RequestTypeID",
                table: "Requests");

            migrationBuilder.DropForeignKey(
                name: "FK_Users_UserRoles_UserRoleID",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_ArchiveRequests_RequestTypeID",
                table: "ArchiveRequests");

            migrationBuilder.DropColumn(
                name: "RequestTypeID",
                table: "ArchiveRequests");

            migrationBuilder.AddForeignKey(
                name: "FK_ArchiveRequests_RequestArchivers_ArchiverID",
                table: "ArchiveRequests",
                column: "ArchiverID",
                principalTable: "RequestArchivers",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_Companies_CompanyID",
                table: "Requests",
                column: "CompanyID",
                principalTable: "Companies",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_RequestCreators_CreatorID",
                table: "Requests",
                column: "CreatorID",
                principalTable: "RequestCreators",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_RequestExecutors_ExecutorID",
                table: "Requests",
                column: "ExecutorID",
                principalTable: "RequestExecutors",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_RequestStatuses_RequestStatusID",
                table: "Requests",
                column: "RequestStatusID",
                principalTable: "RequestStatuses",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Requests_RequestTypes_RequestTypeID",
                table: "Requests",
                column: "RequestTypeID",
                principalTable: "RequestTypes",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_UserRoles_UserRoleID",
                table: "Users",
                column: "UserRoleID",
                principalTable: "UserRoles",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
