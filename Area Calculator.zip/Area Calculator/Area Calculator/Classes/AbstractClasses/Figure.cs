﻿using Area_Calculator.Interfaces;

namespace Area_Calculator.Classes.AbstractClasses
{
    /// <summary>
    /// Абстрактный класс геометрической фигуры
    /// </summary>
    internal abstract class Figure : IFigure
    {
        public abstract string Name { get; }
        public abstract double Area { get; }

        /// <summary>
        /// Возникшая ошибка при создании фигуры
        /// </summary>
        public abstract string? Error { get; set; }

        /// <summary>
        /// Метод проверки возможности существования фигуры
        /// </summary>
        /// <returns><see cref="bool"/> флаг существования фигуры</returns>
        public abstract bool FigureChecker();

        /// <summary>
        /// Метод вывода площади фигуры
        /// </summary>
        public void PrintArea() => Console.WriteLine($"Площадь {Name.ToLower()}а равна {Area}");
        public bool Compare(IFigure figure) => Name == figure.Name && Area == figure.Area;
    }
}