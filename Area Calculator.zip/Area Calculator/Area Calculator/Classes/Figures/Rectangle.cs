﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Area_Calculator.Classes.Figures
{
    internal class Rectangle
    {
    }
}
