﻿using Area_Calculator.Classes.AbstractClasses;

using CircleStruct = Area_Calculator.Structures.Figures.Circle;

namespace Area_Calculator.Classes.Figures
{
    /// <summary>
    /// Класс фигуры "Круг"
    /// </summary>
    internal class Circle : Figure
    {
        private const double PI = 3.14;

        private double _radius;

        /// <summary>
        /// Радиус круга
        /// </summary>
        public double Radius
        {
            get => _radius;

            set
            {
                if (value <= 0)
                {
                    Error = "Радиус круга должен быть больше 0!";

                    throw new ArgumentException($"Значение {nameof(Radius)} должно быть положительным.");
                }

                _radius = value;
            }
        }

        /// <summary>
        /// Базовый конструктор круга
        /// </summary>
        /// <param name="radius">Радиус</param>
        public Circle(double radius)
        {
            Radius = radius;
        }

        /// <summary>
        /// Конструктор, принимающий структуру <see cref="CircleStruct"/>
        /// </summary>
        /// <param name="circle">Структура круга</param>
        public Circle(CircleStruct circle)
        {
            Radius = circle.Radius;
        }

        public override string Name => "Круг";
        public override double Area => Math.Round(PI * Math.Pow(Radius, 2), 3);
        public override string? Error { get; set; }

        public override bool FigureChecker() => Radius > 0;

        /// <summary>
        /// Приведение к структуре "Круг"
        /// </summary>
        /// <param name="circle">Класс круга</param>
        public static implicit operator CircleStruct(Circle circle) => new(circle.Radius);
    }
}