﻿using Area_Calculator.Classes.AbstractClasses;

using TriangleStruct = Area_Calculator.Structures.Figures.Triangle;

namespace Area_Calculator.Classes.Figures
{
    /// <summary>
    /// Класс фигуры "Треугольник"
    /// </summary>
    internal class Triangle : Figure
    {
        public double _side1;

        /// <summary>
        /// Первая сторона треугольника
        /// </summary>
        public double Side1
        {
            get => _side1;

            set
            {
                if (value <= 0)
                {
                    Error = "Первая сторона треугольника должна быть больше 0!";

                    throw new ArgumentException($"Значение {nameof(Side1)} должно быть положительным.");
                }

                _side1 = value;
            }
        }

        public double _side2;

        /// <summary>
        /// Вторая сторона треугольника
        /// </summary>
        public double Side2
        {
            get => _side2;

            set
            {
                if (value <= 0)
                {
                    Error = "Вторая сторона треугольника должна быть больше 0!";

                    throw new ArgumentException($"Значение {nameof(Side2)} должно быть положительным.");
                }

                _side2 = value;
            }
        }

        public double _side3;

        /// <summary>
        /// Третья сторона треугольника
        /// </summary>
        public double Side3
        {
            get => _side3;

            set
            {
                if (value <= 0)
                {
                    Error = "Третья сторона треугольника должна быть больше 0!";

                    throw new ArgumentException($"Значение {nameof(Side3)} должно быть положительным.");
                }

                _side3 = value;
            }
        }

        /// <summary>
        /// Базовый конструктор треугольника
        /// </summary>
        /// <param name="side1">Первая сторона</param>
        /// <param name="side2">Вторая сторона</param>
        /// <param name="side3">Третья сторона</param>
        public Triangle(double side1, double side2, double side3)
        {
            Side1 = side1;
            Side2 = side2;
            Side3 = side3;
        }

        /// <summary>
        /// Конструктор, принимающий структуру <see cref="TriangleStruct"/>
        /// </summary>
        /// <param name="triangle">Структура треугольника</param>
        public Triangle(TriangleStruct triangle)
        {
            Side1 = triangle.Side1;
            Side2 = triangle.Side2;
            Side3 = triangle.Side3;
        }

        public override string Name => "Треугольник";
        public override double Area
        {
            get
            {
                double semiperimeter = (Side1 + Side2 + Side3) / 2; // полупериметр
                return Math.Round(Math.Sqrt(semiperimeter * (semiperimeter - Side1) * (semiperimeter - Side2) * (semiperimeter - Side3)), 3);
            }
        }

        public override string? Error { get; set; }

        public override bool FigureChecker()
        {
            if (!(((Side1 + Side2) > Side3) && ((Side1 + Side3) > Side2) && ((Side2 + Side3) > Side1)))
            {
                Error = $"Такого {Name}а не может существовать!";
            }

            return string.IsNullOrEmpty(Error);
        }

        /// <summary>
        /// Приведение к структуре "Треугольник"
        /// </summary>
        /// <param name="triangle">Структура треугольника</param>
        public static implicit operator TriangleStruct(Triangle triangle) => new(triangle.Side1, triangle.Side2, triangle.Side3);
    }
}