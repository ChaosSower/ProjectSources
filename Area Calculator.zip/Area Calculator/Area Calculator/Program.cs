﻿using Area_Calculator.Enums;
using Area_Calculator.Extensions;
using Area_Calculator.Classes.Figures;

// Словарь фигур
Dictionary<Figure, (string FigureName, string FigureArgument)> figures = new()
{
    [Figure.Circle] = ($"{(int)Figure.Circle + 1}. {Figure.Circle.GetDescription()}", "радиус"),
    [Figure.Rectangle] = ($"{(int)Figure.Rectangle + 1}. {Figure.Rectangle.GetDescription()}", "две стороны"),
    [Figure.Square] = ($"{(int)Figure.Square + 1}. {Figure.Square.GetDescription()}", "сторону"),
    [Figure.Triangle] = ($"{(int)Figure.Triangle + 1}. {Figure.Triangle.GetDescription()}", "три стороны")
};

string[] example = figures[0].FigureName.Split([' ']);

string initializeString =
    $"""
    Пожалуйста, введите в поле ввода одно из выражений для вычисления площади данной фигуры:

    {figures[(Figure)0].FigureName}
    {figures[(Figure)1].FigureName}
    {figures[(Figure)2].FigureName}
    {figures[(Figure)3].FigureName}

    Допустимым является ввод одного из вариантов примера:
    {figures[0].FigureName}
    {example[0]}
    {example[1]}

    """;

Console.WriteLine(initializeString);

Figure? creatingFigure = null;

bool userFigureCreated = false;

while (!userFigureCreated)
{
    string userFigure = Console.ReadLine()?.Trim().ToLower() ?? string.Empty;

    if (userFigure == string.Empty)
    {
        Console.WriteLine("Фигура не распознана! Введите желаемый вариант ещё раз!");
        Console.WriteLine();
    }

    else
    {
        KeyValuePair<Figure, (string FigureName, string FigureArgument)> matchFound = figures.FirstOrDefault(figure =>
        {
            string figureValue = figure.Value.FigureName.ToLower();

            List<string> allowedVariants = [figureValue];

            string[] parts = figureValue.Split(' ', StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < parts.Length; i++)
            {
                allowedVariants.Add(parts[i]);
            }

            return allowedVariants.Any(variant => variant.Equals(userFigure, StringComparison.OrdinalIgnoreCase));
        });

        Console.WriteLine();

        if (!matchFound.Equals(default(KeyValuePair<Figure, (string FigureName, string FigureArgument)>)))
        {
            creatingFigure = matchFound.Key;
            Console.WriteLine($"Совпадение найдено! Это фигура: {matchFound.Key.GetDescription()}");

            userFigureCreated = true;
        }

        else
        {
            Console.WriteLine("Фигура не распознана! Введите желаемый вариант ещё раз!");
        }
    }
}

Console.WriteLine();

if (creatingFigure != null)
{
    CreateFigure((Figure)creatingFigure);
}

void CreateFigure(Figure figure)
{
    Console.WriteLine($"Пожалуйста, введите {figures[figure].FigureArgument} для фигуры \"{figure.GetDescription()}\":");
    
    bool figureCreated = figure switch
    {
        Figure.Circle => CreateCircle(),
        Figure.Rectangle => CreateRectangle(),
        Figure.Square => CreateSquare(),
        Figure.Triangle => CreateTriangle(),
        _ => false
    };
}

bool CreateCircle()
{
    double radius = Convert.ToDouble(Console.ReadLine());

    Console.WriteLine();

    Circle circle = new(radius);
    bool created = circle.FigureChecker();

    if (created)
    {
        circle.PrintArea();

        return true;
    }

    else
    {
        Console.WriteLine(circle.Error);

        circle.PrintArea();

        return false;
    }
}

bool CreateRectangle()
{
    return true;
}

bool CreateSquare()
{
    return true;
}

bool CreateTriangle()
{
    double side1 = Convert.ToDouble(Console.ReadLine());
    double side2 = Convert.ToDouble(Console.ReadLine());
    double side3 = Convert.ToDouble(Console.ReadLine());

    Console.WriteLine();

    Triangle triangle = new(side1, side2, side3);
    bool created = triangle.FigureChecker();

    if (created)
    {
        triangle.PrintArea();

        return true;
    }

    else
    {
        Console.WriteLine(triangle.Error);

        triangle.PrintArea();

        return false;
    }
}