﻿namespace Area_Calculator.Interfaces
{
    /// <summary>
    /// Интерфейс объекта, у которого можно вычислить площадь
    /// </summary>
    internal interface IAreaMeasurable
    {
        /// <summary>
        /// Площадь объекта
        /// </summary>
        internal double Area { get; }
    }
}