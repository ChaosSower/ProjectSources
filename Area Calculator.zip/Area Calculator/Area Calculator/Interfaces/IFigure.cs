﻿namespace Area_Calculator.Interfaces
{
    /// <summary>
    /// Интерфейс фигуры
    /// </summary>
    internal interface IFigure : IAreaMeasurable
    {
        /// <summary>
        /// Название фигуры
        /// </summary>
        internal string Name { get; }
    }
}