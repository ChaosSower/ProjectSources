﻿using System.ComponentModel;

namespace Area_Calculator.Enums
{
    /// <summary>
    /// Перечисление геометрических фигур
    /// </summary>
    internal enum Figure
    {
        /// <summary>
        /// Круг
        /// </summary>
        [Description("Круг")]
        Circle,

        /// <summary>
        /// Прямоугольник
        /// </summary>
        [Description("Прямоугольник")]
        Rectangle,

        /// <summary>
        /// Квадрат
        /// </summary>
        [Description("Квадрат")]
        Square,

        /// <summary>
        /// Треугольник
        /// </summary>
        [Description("Треугольник")]
        Triangle
    }
}