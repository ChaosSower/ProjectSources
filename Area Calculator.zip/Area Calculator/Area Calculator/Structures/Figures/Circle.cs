﻿using Area_Calculator.Interfaces;

using CircleClass = Area_Calculator.Classes.Figures.Circle;

namespace Area_Calculator.Structures.Figures
{
    /// <summary>
    /// Структура фигуры "Круг"
    /// </summary>
    internal readonly struct Circle : IFigure
    {
        private const double PI = 3.14;

        /// <summary>
        /// Радиус круга
        /// </summary>
        public readonly double Radius;

        /// <summary>
        /// Базовый конструктор круга
        /// </summary>
        /// <param name="radius">Радиус</param>
        public Circle(double radius)
        {
            Radius = radius;
        }

        /// <summary>
        /// Конструктор, принимающий класс <see cref="CircleClass"/>
        /// </summary>
        /// <param name="circle">Класс круга</param>
        public Circle(CircleClass circle)
        {
            Radius = circle.Radius;
        }

        public readonly string Name => "Круг";
        public readonly double Area => Math.Round(PI * Math.Pow(Radius, 2), 3);

        /// <summary>
        /// Приведение к классу "Круг"
        /// </summary>
        /// <param name="circle">Структура круга</param>
        public static implicit operator CircleClass(Circle circle) => new(circle.Radius);
    }
}