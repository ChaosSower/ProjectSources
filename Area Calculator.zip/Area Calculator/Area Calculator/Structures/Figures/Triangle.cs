﻿using Area_Calculator.Interfaces;

using TriangleClass = Area_Calculator.Classes.Figures.Triangle;

namespace Area_Calculator.Structures.Figures
{
    /// <summary>
    /// Структура фигуры "Треугольник"
    /// </summary>
    internal readonly struct Triangle : IFigure
    {
        /// <summary>
        /// Первая сторона треугольника
        /// </summary>
        public readonly double Side1;

        /// <summary>
        /// Вторая сторона треугольника
        /// </summary>
        public readonly double Side2;

        /// <summary>
        /// Третья сторона треугольника
        /// </summary>
        public readonly double Side3;

        /// <summary>
        /// Базовый конструктор треугольника
        /// </summary>
        /// <param name="side1">Первая сторона</param>
        /// <param name="side2">Вторая сторона</param>
        /// <param name="side3">Третья сторона</param>
        public Triangle(double side1, double side2, double side3)
        {
            Side1 = side1;
            Side2 = side2;
            Side3 = side3;
        }

        /// <summary>
        /// Конструктор, принимающий класс <see cref="TriangleClass"/>
        /// </summary>
        /// <param name="triangle">Класс треугольника</param>
        public Triangle(TriangleClass triangle)
        {
            Side1 = triangle.Side1;
            Side2 = triangle.Side2;
            Side3 = triangle.Side3;
        }

        public readonly string Name => "Треугольник";
        public readonly double Area
        {
            get
            {
                double semiperimeter = (Side1 + Side2 + Side3) / 2; // полупериметр
                return Math.Round(Math.Sqrt(semiperimeter * (semiperimeter - Side1) * (semiperimeter - Side2) * (semiperimeter - Side3)), 3);
            }
        }

        /// <summary>
        /// Приведение к классу "Треугольник"
        /// </summary>
        /// <param name="triangle">Структура треугольника</param>
        public static implicit operator TriangleClass(Triangle triangle) => new(triangle.Side1, triangle.Side2, triangle.Side3);
    }
}