﻿using System.Reflection;
using System.ComponentModel;

namespace Area_Calculator.Extensions
{
    internal static class EnumExtensions
    {
        public static string? GetDescription<T>(this T enumValue) where T : /*struct*/ Enum//, IConvertible
        {
            //if (!typeof(T).IsEnum)
            //{
            //    return null;
            //}

            string? description = enumValue.ToString();
            FieldInfo? fieldInfo = enumValue.GetType().GetField(enumValue.ToString() ?? string.Empty);

            if (fieldInfo != null)
            {
                object[] attributes = fieldInfo.GetCustomAttributes(typeof(DescriptionAttribute), true);

                if (attributes != null && attributes.Length > 0)
                {
                    description = ((DescriptionAttribute)attributes[0]).Description;
                }
            }

            return description;
        }
    }
}