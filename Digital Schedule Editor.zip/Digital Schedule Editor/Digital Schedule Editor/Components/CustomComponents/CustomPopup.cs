﻿// V. 1.3.2.5.

// Описание: позволяет проигрывать анимацию "убирания" в кнопку [обратная анимация при закрытии],
// когда установлено свойство StaysOpen = false. Это нужно потому,
// что у Popup есть событие Closed, но не Closing

// Пояснение: работает корректно только с одним Popup. Не работает в связке с двумя, т. к. есть приоритетность отображения
// Popup (разный уровень, не на одинаковом уровне), кликнуть можно только на последний загруженный

using System.Windows.Controls.Primitives;
using System.Windows.Media.Animation;
using System.Windows;
using System.Windows.Controls;

namespace Digital_Schedule_Editor.Components.CustomComponents
{
    /// <summary>
    /// Класс пользовательского элемента <see cref="Popup"/>, поддерживающий обратные анимации
    /// </summary>
    internal class CustomPopup : Popup
    {
        /// <summary>
        /// Popup-пустышка, замещающий изначальный <see cref="Popup"/> при его закрытии
        /// </summary>
        private readonly Popup DummyPopup;
        private readonly DoubleAnimation PopupVerticalAnimation;
        private readonly DoubleAnimation PopupHorizontalAnimation;
        private readonly DoubleAnimation PopupReverseVerticalAnimation;
        private readonly DoubleAnimation PopupReverseHorizontalAnimation;

        private bool _IsOpen;
        public new bool IsOpen
        {
            get => _IsOpen;

            set
            {
                _IsOpen = value;

                if (value)
                {
                    //_IsOpen = value;
                    DummyPopup.Child.Visibility = Visibility.Hidden;
                    DummyPopup.IsOpen = true;
                    //base.IsOpen = value;
                    BeginAnimation(VerticalOffsetProperty, PopupVerticalAnimation);
                    BeginAnimation(HorizontalOffsetProperty, PopupHorizontalAnimation);
                }

                else
                {
                    //_IsOpen = value;
                    DummyPopup.Child.Visibility = Visibility.Visible;
                    //base.IsOpen = value;
                    BeginAnimation(VerticalOffsetProperty, null);
                    BeginAnimation(HorizontalOffsetProperty, null);
                    DummyPopup.BeginAnimation(VerticalOffsetProperty, PopupReverseVerticalAnimation);
                    DummyPopup.BeginAnimation(HorizontalOffsetProperty, PopupReverseHorizontalAnimation);
                    
                    //throw new InvalidOperationException("Не предусмотрена ситуация, когда явно устанавливается значение false свойству");
                    // Пояснение: заместо обработки свойства обрабатывается событие Closed
                    // Пояснение (новое): обрабатываем IsOpen = false, т. к. у нас есть очередь закрытия
                }

                base.IsOpen = value;
            }
        }

        /// <summary>
        /// Конструктор <see cref="CustomPopup"/>, принимающего в качестве аргументов:
        /// <list type="bullet">
        /// <item>
        /// <description><paramref name="TargetButton"/> — родительская кнопка</description>
        /// </item>
        /// <item>
        /// <description><paramref name="ChildButton"/> — кнопка, вложенная в <see cref="Popup"/></description>
        /// </item>
        /// <item>
        /// <description><paramref name="PopupHorizontalAnimationToPosition"/> — финальная горизонтальная <br/>позиция <see cref="Popup"/></description>
        /// </item>
        /// <item>
        /// <description><paramref name="PopupVerticalAnimationToPosition"/> — финальная вертикальная позиция <see cref="Popup"/></description>
        /// </item>
        /// </list>
        /// </summary>
        /// <param name="TargetButton">Передаваемая родительская кнопка, вызывающая <see cref="CustomPopup"/></param>
        /// <param name="ChildButton">Передаваемая кнопка, вложенная в оригинальный <see cref="Popup"/></param>
        /// <param name="PopupHorizontalAnimationToPosition">Горизонтальное значение, куда должен переместиться <see cref="Popup"/></param>
        /// <param name="PopupVerticalAnimationToPosition">Вертикальное значение, куда должен переместиться <see cref="Popup"/></param>
        public CustomPopup(Button TargetButton, Button ChildButton, double PopupHorizontalAnimationToPosition, double PopupVerticalAnimationToPosition)
        {
            Button CloneChildButton = new()
            {
                Content = ChildButton.Content,
                Width = ChildButton.Width,
                Height = ChildButton.Height,
                Style = ChildButton.Style,
                Effect = ChildButton.Effect,
                Margin = ChildButton.Margin
            };

            PopupHorizontalAnimation = new()
            {
                To = PopupHorizontalAnimationToPosition,
                Duration = new(TimeSpan.FromSeconds(0.1))
            };

            PopupVerticalAnimation = new()
            {
                To = PopupVerticalAnimationToPosition,
                Duration = new(TimeSpan.FromSeconds(0.1))
            };

            DummyPopup = new()
            {
                PlacementTarget = TargetButton,
                Placement = PlacementMode.Center,
                StaysOpen = false,
                AllowsTransparency = true,
                Child = CloneChildButton,
                HorizontalOffset = PopupHorizontalAnimationToPosition + 1, // необходимое смещение
                VerticalOffset = PopupVerticalAnimationToPosition - 1 // необходимое смещение
            };

            PopupReverseHorizontalAnimation = new()
            {
                To = 0,
                Duration = new(TimeSpan.FromSeconds(0.1))
            };

            PopupReverseVerticalAnimation = new()
            {
                To = 0,
                Duration = new(TimeSpan.FromSeconds(0.1))
            };

            PopupHorizontalAnimation.Completed += (sender, e) => DummyPopup.Child.Visibility = Visibility.Visible;

            Closed += (sender, e) =>
            {
                BeginAnimation(VerticalOffsetProperty, null);
                BeginAnimation(HorizontalOffsetProperty, null);
                DummyPopup.BeginAnimation(VerticalOffsetProperty, PopupReverseVerticalAnimation);
                DummyPopup.BeginAnimation(HorizontalOffsetProperty, PopupReverseHorizontalAnimation);
            };

            PopupReverseHorizontalAnimation.Completed += (sender, e) =>
            {
                DummyPopup.IsOpen = false;
                DummyPopup.BeginAnimation(VerticalOffsetProperty, null);
                DummyPopup.BeginAnimation(HorizontalOffsetProperty, null);
            };
        }
    }
}