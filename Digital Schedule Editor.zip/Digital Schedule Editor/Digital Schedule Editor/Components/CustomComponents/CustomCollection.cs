﻿using System.Windows.Controls;

using Digital_Schedule_Editor.Interfaces;

namespace Digital_Schedule_Editor.Components.CustomComponents
{
    // Класс элемента, который может быть как списком, так и комбо-боксом, для работы с его списком
    public class CustomCollection : IList
    {
        private readonly List<string>? List;
        private readonly ItemCollection? ComboBoxItems;

        public CustomCollection(List<string> List)
        {
            this.List = List;
        }

        public CustomCollection(ComboBox ComboBox)
        {
            ComboBoxItems = ComboBox.Items;
        }

        public int Count
        {
            get
            {
                if (List != null)
                {
                    return List.Count;
                }

                else if (ComboBoxItems != null)
                {
                    return ComboBoxItems.Count;
                }

                else
                {
                    throw new InvalidOperationException("No collection was provided.");
                }
            }
        }

        public string this[int Index]
        {
            get
            {
                if (List != null)
                {
                    return List[Index];
                }

                // TODO: закомментированный код идентичен нижнему, но почему-то высвечивается предупреждение
                // нужно преодолеть данную проблему (проблема обработка компилятором)

                /*else if (Collection[Index]?.ToString() == null)
                {
                    return "";
                }

                else
                {
                    return Collection[Index]?.ToString();
                }*/

                else if (ComboBoxItems != null)
                {
                    return ComboBoxItems[Index].ToString() ?? "";
                }

                else
                {
                    throw new InvalidOperationException("No collection was provided.");
                }
            }
        }

        public void Add(string Item)
        {
            List?.Add(Item);
            ComboBoxItems?.Add(Item);
        }

        public void Clear()
        {
            List?.Clear();
            ComboBoxItems?.Clear();
        }
    }
}