﻿using System.Windows.Controls;

namespace Digital_Schedule_Editor.Methods
{
    internal static class CommonMethodsClass
    {
        // Статический метод проверки того, является ли строка числом
        public static bool IsNumeric(string String)
        {
            return int.TryParse(String, out _);
        }

        [Obsolete("Проверка через исключения занимает больше времени", true)]
        public static bool IsNumeric(string String, bool DeleteMe = true)
        {
            try
            {
                int.Parse(String);

                return true;
            }

            catch
            {
                return false;
            }
        }

        // Статический метод удаления последнего указанного символа из текста
        public static void RemoveACertainLastCharacterInControlText(ContentControl Control, char LastCharacter)
        {
            if (Control.Content.ToString().Length > 0 && Control.Content.ToString()[^1] == LastCharacter)
            {
                Control.Content = Control.Content.ToString()[..^1];
            }
        }

        // Статический метод удаления последнего указанного символа из текста
        public static string ReplaceACertainLastCharacterInText(string Text, char ReplaceableCharacter)
        {
            if (Text.Length > 0)
            {
                return Text = Text[..^1] + ReplaceableCharacter;
            }

            else
            {
                return Text;
            }
        }
    }
}