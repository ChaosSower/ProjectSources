﻿// V. 1.7.5.

using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Controls.Primitives;

using Digital_Schedule_Editor.Interfaces;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    /// <summary>
    /// Класс пользовательского элемента <see cref="ComboBox"/> с текстом-подсказкой
    /// </summary>
    public partial class PlaceholderComboBox : ComboBox, IPlaceholderControl
    {
        private string? _PlaceholderText;
        public string? PlaceholderText
        {
            get => _PlaceholderText;

            set
            {
                _PlaceholderText = Text = value;
            }
        }

        private TextChangedEventHandler? TextChangedHandler;

        public PlaceholderComboBox()
        {
            Initialized += (sender, e) =>
            {
                TextChangedHandler = new((sender, e) =>
                {
                    if (Text != $"{PlaceholderText}" && Foreground == Brushes.Gray)
                    {
                        Foreground = Brushes.Black;
                    }
                });

                AddHandler(TextBoxBase.TextChangedEvent, TextChangedHandler);
            };

            InitializeComponent();

            Loaded += (sender, e) =>
            {
                RemoveHandler(TextBoxBase.TextChangedEvent, TextChangedHandler);
                TextChangedHandler = null;
            };

            bool ComboBoxLeaved = false;
            bool ComboBoxEntered = false;

            GotFocus += (sender, e) =>
            {
                ComboBoxEntered = true;
                ComboBoxLeaved = false;

                if (Text == $"{PlaceholderText}" && Foreground == Brushes.Gray)
                {
                    Text = string.Empty;
                }

                Foreground = Brushes.Black;
            };

            LostFocus += (sender, e) =>
            {
                ComboBoxEntered = false;
                ComboBoxLeaved = true;

                if (string.IsNullOrWhiteSpace(Text))
                {
                    Foreground = Brushes.Gray;
                    Text = $"{PlaceholderText}";
                }
            };

            DropDownOpened += (sender, e) =>
            {
                if (Text == $"{PlaceholderText}" && Foreground == Brushes.Gray)
                {
                    Foreground = Brushes.Black;
                    Text = string.Empty;
                }
            };

            DropDownClosed += (sender, e) =>
            {
                if (string.IsNullOrWhiteSpace(Text) && ComboBoxLeaved && !ComboBoxEntered)
                {
                    Foreground = Brushes.Gray;
                    Text = $"{PlaceholderText}";
                }
            };
        }
    }
}