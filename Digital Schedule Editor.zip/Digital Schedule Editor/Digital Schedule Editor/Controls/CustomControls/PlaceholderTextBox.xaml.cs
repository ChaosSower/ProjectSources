﻿// V. 1.7.5.

using System.Windows.Controls;
using System.Windows.Media;

using Digital_Schedule_Editor.Interfaces;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    /// <summary>
    /// Класс пользовательского элемента <see cref="TextBox"/> с текстом-подсказкой
    /// </summary>
    public partial class PlaceholderTextBox : TextBox, IPlaceholderControl
    {
        private string? _PlaceholderText;
        public string? PlaceholderText { get => _PlaceholderText; set => _PlaceholderText = Text = value; }

        private TextChangedEventHandler? TextChangedHandler;

        public PlaceholderTextBox()
        {
            Initialized += (sender, e) =>
            {
                TextChanged += TextChangedHandler = (sender, e) =>
                {
                    if (Text != $"{PlaceholderText}" && Foreground == Brushes.Gray)
                    {
                        Foreground = Brushes.Black;
                    }
                };
            };

            InitializeComponent();

            Loaded += (sender, e) =>
            {
                TextChanged -= TextChangedHandler;
            };

            GotFocus += (sender, e) =>
            {
                if (Text == $"{PlaceholderText}" && Foreground == Brushes.Gray)
                {
                    Text = string.Empty;
                }

                Foreground = Brushes.Black;
            };

            LostFocus += (sender, e) =>
            {
                if (string.IsNullOrWhiteSpace(Text))
                {
                    Foreground = Brushes.Gray;
                    Text = $"{PlaceholderText}";
                }
            };
        }
    }
}