﻿// V.2.2

// TODO: внести в отдельный проект, скомпилировать в .dll
// TODO: добавить unit-тесты экземпляров с разным количеством кнопок и разной высотой контейнера
// (1, 2, 3)
// TODO: переместить родственный класс SeparateLabelsWithButtons сюда?

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    internal class LabelWithButtons : Grid
    {
        private readonly StackPanel LabelWithButtonsStackPanel = new()
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Bottom
        };

        private TextBlock? ButtonTextBlock;
        private Image? ButtonImage;

        private object? _Content;

        public object? Content
        {
            get => _Content;

            set
            {
                if (value is string Value)
                {
                    _Content = ButtonTextBlock = new()
                    {
                        Text = Value
                    };

                    Children.Add(ButtonTextBlock);
                }

                else if (value is Image Image)
                {
                    _Content = ButtonImage = Image;

                    Children.Add(ButtonImage);
                }
            }
        }

        private readonly HorizontalAlignment _HorizontalContentAlignment;

        public HorizontalAlignment HorizontalContentAlignment
        {
            get => _HorizontalContentAlignment;

            set
            {
                if (_Content is TextBlock TextBlock)
                {
                    TextBlock.HorizontalAlignment = value;
                }

                else if (_Content is Image Image)
                {
                    Image.HorizontalAlignment = value;
                }
            }
        }

        private readonly VerticalAlignment _VerticalContentAlignment;

        public VerticalAlignment VerticalContentAlignment
        {
            get => _VerticalContentAlignment;

            set
            {
                if (_Content is TextBlock TextBlock)
                {
                    TextBlock.VerticalAlignment = value;
                }

                else if (_Content is Image Image)
                {
                    Image.VerticalAlignment = value;
                }
            }
        }

        public Button? CustomButton;

        // Объявите делегат
        public delegate void ClickHandler(object sender, RoutedEventArgs e);

        // Создайте событие с этим делегатом
        public event ClickHandler? AddButtonClick;
        public event ClickHandler? DeleteButtonClick;
        public event ClickHandler? CustomButtonClick;

        private int _NumberOfButtons = 1;

        public int NumberOfButtons
        {
            get => _NumberOfButtons;

            set
            {
                if (value > 1 && value <= 3)
                {
                    _NumberOfButtons = value;
                }
            }
        }

        private Image? _CustomButtonImage;

        public Image? CustomButtonImage
        {
            get => _CustomButtonImage;

            set
            {
                _CustomButtonImage = value;
            }
        }

        private int[] _ButtonsIndexArray = { 1 };

        public int[] ButtonsOrderIndexArray
        {
            get => _ButtonsIndexArray;

            set
            {
                foreach (int ButtonIndex in value)
                {
                    if (value.Length > 3 || ButtonIndex > 3 || ButtonIndex < 1 /*???*/)
                    {
                        return;
                    }
                }

                _ButtonsIndexArray = value;
            }
        }

        public LabelWithButtons(int NumberOfButtons = 1, Image? CustomButtonImage = null)
        {
            Children.Add(LabelWithButtonsStackPanel);

            this.NumberOfButtons = NumberOfButtons;
            this.CustomButtonImage = CustomButtonImage;

            CreateButton(1);

            if (this.NumberOfButtons == 2)
            {
                CreateButton(2);
            }

            else if (this.NumberOfButtons == 3)
            {
                CreateButton(2);
                CreateButton(3);
            }
        }

        public LabelWithButtons(int[] ButtonsOrderIndexArray, Image? CustomButtonImage = null)
        {
            Children.Add(LabelWithButtonsStackPanel);

            this.ButtonsOrderIndexArray = ButtonsOrderIndexArray;
            this.CustomButtonImage = CustomButtonImage;

            for (int i = 0; i < ButtonsOrderIndexArray.Length; i++)
            {
                CreateButton(ButtonsOrderIndexArray[i], i);
            }
        }

        private void CreateButton(int TypeOfButton)
        {
            switch (TypeOfButton)
            {
                case 1:

                    // Кнопка "добавить"
                    Button AddButton = new()
                    {
                        Background = Brushes.YellowGreen,
                        Width = 20,
                        Height = 20,
                        Content = new TextBlock()
                        {
                            Text = "+",
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        },
                        Margin = new(0, 0, 3, 0),
                        Cursor = Cursors.Hand
                    };

                    AddButton.Click += (sender, e) =>
                    {
                        AddButtonClick?.Invoke(sender, e);
                    };

                    LabelWithButtonsStackPanel.Children.Add(AddButton);

                    break;

                case 2:

                    // Кнопка "удалить"
                    Button DeleteButton = new()
                    {
                        Background = Brushes.Salmon,
                        Width = 20,
                        Height = 20,
                        Content = new TextBlock()
                        {
                            Text = "-",
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        },
                        Margin = new(0, 0, 3, 0),
                        Cursor = Cursors.Hand
                    };

                    DeleteButton.Click += (sender, e) =>
                    {
                        DeleteButtonClick?.Invoke(sender, e);
                    };

                    LabelWithButtonsStackPanel.Children.Add(DeleteButton);

                    break;

                case 3:

                    // Пользовательская кнопка
                    CustomButton = new()
                    {
                        Content = new Image()
                        {
                            Source = CustomButtonImage?.Source,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        },
                        Width = 20,
                        Height = 20,
                        Cursor = Cursors.Hand
                    };

                    CustomButton.Click += (sender, e) =>
                    {
                        CustomButtonClick?.Invoke(sender, e);
                    };

                    LabelWithButtonsStackPanel.Children.Add(CustomButton);

                    break;
            }
        }

        private void CreateButton(int TypeOfButton, int IndexOfButton)
        {
            switch (TypeOfButton)
            {
                case 1:

                    // Кнопка "добавить"
                    Button AddButton = new()
                    {
                        Background = Brushes.YellowGreen,
                        Width = 20,
                        Height = 20,
                        Content = new TextBlock()
                        {
                            Text = "+",
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        },
                        Margin = new(0, 0, 3, 0),
                        Cursor = Cursors.Hand
                    };

                    AddButton.Click += (sender, e) =>
                    {
                        AddButtonClick?.Invoke(sender, e);
                    };

                    LabelWithButtonsStackPanel.Children.Insert(IndexOfButton, AddButton);

                    break;

                case 2:

                    // Кнопка "удалить"
                    Button DeleteButton = new()
                    {
                        Background = Brushes.Salmon,
                        Width = 20,
                        Height = 20,
                        Content = new TextBlock()
                        {
                            Text = "-",
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        },
                        Margin = new(0, 0, 3, 0),
                        Cursor = Cursors.Hand
                    };

                    DeleteButton.Click += (sender, e) =>
                    {
                        DeleteButtonClick?.Invoke(sender, e);
                    };

                    LabelWithButtonsStackPanel.Children.Insert(IndexOfButton, DeleteButton);

                    break;

                case 3:

                    // Пользовательская кнопка
                    CustomButton = new()
                    {
                        Content = new Image()
                        {
                            Source = CustomButtonImage?.Source,
                            HorizontalAlignment = HorizontalAlignment.Center,
                            VerticalAlignment = VerticalAlignment.Center
                        },
                        Width = 20,
                        Height = 20,
                        Margin = new(0, 0, 3, 0),
                        Cursor = Cursors.Hand
                    };

                    CustomButton.Click += (sender, e) =>
                    {
                        CustomButtonClick?.Invoke(sender, e);
                    };

                    LabelWithButtonsStackPanel.Children.Insert(IndexOfButton, CustomButton);

                    break;
            }
        }
    }
}