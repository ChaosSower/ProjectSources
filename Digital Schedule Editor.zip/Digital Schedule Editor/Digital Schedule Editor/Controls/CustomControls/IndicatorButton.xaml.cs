﻿using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    /// <summary>
    /// Пользовательский элемент <see cref="Button"/> с индикатором
    /// </summary>
    public partial class IndicatorButton : StackPanel
    {
        private bool? _IsIndicatorActive;
        public bool? IsIndicatorActive
        {
            get => _IsIndicatorActive;

            set
            {
                IndicatorRectangle.Fill = value switch
                {
                    true => Brushes.LightGreen,
                    false => Brushes.Black,
                    _ => Brushes.Red,
                };

                _IsIndicatorActive = value;
            }
        }

        private ImageSource? _IndicatorButtonImageSource;
        public ImageSource? IndicatorButtonImageSource
        {
            get => _IndicatorButtonImageSource;

            set
            {
                if (value != null)
                {
                    IndicatorButtonImage.Source = value;
                }

                _IndicatorButtonImageSource = value;
            }
        }

        public IndicatorButton()
        {
            InitializeComponent();

            IndicatorRectangle.Fill = IsIndicatorActive switch
            {
                true => Brushes.LightGreen,
                false => Brushes.Black,
                _ => Brushes.Red,
            };
        }

        private void IndicatorButton_Click(object sender, RoutedEventArgs e)
        {
            IsIndicatorActive = !IsIndicatorActive;

            IndicatorRectangle.Fill = IsIndicatorActive switch
            {
                true => Brushes.LightGreen,
                false => Brushes.Black,
                _ => Brushes.Red,
            };
        }
    }
}