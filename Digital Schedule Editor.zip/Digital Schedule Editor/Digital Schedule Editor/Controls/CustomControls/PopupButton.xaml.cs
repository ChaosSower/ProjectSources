﻿// V. 3.5.

using System.Windows.Controls;
using System.Windows.Media;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Animation;

using Digital_Schedule_Editor.Classes;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    /// <summary>
    /// Закруглённая кнопка с тенью, вызывающая несколько Popup-кнопок,
    /// а также получающая логику интерактивной подсветки
    /// и динамического изменения размера через класс <see cref="FocusableButtonClass"/>
    /// </summary>
    public partial class PopupButton : Grid
    {
        public PopupButton()
        {
            InitializeComponent();

            _ = new FocusableButtonClass(CallPopupsButton);

            FocusableButton MakeRateButton = new()
            {
                Content = "Оценить",
                RenderTransform = new TranslateTransform()
            };

            FocusableButton MakeContactButton = new()
            {
                Content = "Связяться",
                RenderTransform = new TranslateTransform()
            };

            FocusableButton[] PopupButtons = new FocusableButton[2]
            {
                MakeRateButton, MakeContactButton
            };

            int i = 0;
            foreach (FocusableButton FocusableButton in PopupButtons)
            {
                FocusableButton.Visibility = Visibility.Collapsed;
                FocusableButton.Cursor = Cursors.Hand;
                FocusableButton.Width = FocusableButton.Height = 60;

                Children.Add(FocusableButton);

                FocusableButton.Click += (sender, e) => MessageBox.Show(i.ToString());
                i++;
            }

            DoubleAnimation? ButtonHorizontalAnimation = null;

            Loaded += (sender, e) =>
            {
                ButtonHorizontalAnimation = new()
                {
                    To = -CallPopupsButton.Width / 2,
                    Duration = new(TimeSpan.FromSeconds(0.1))
                };
            };

            DoubleAnimation ButtonVerticalUpAnimation = new()
            {
                To = -PopupButtons[0].Height / 2 - 10,
                Duration = new(TimeSpan.FromSeconds(0.1))
            };

            DoubleAnimation ButtonVerticalDownAnimation = new()
            {
                To = PopupButtons[1].Height / 2 + 10,
                Duration = new(TimeSpan.FromSeconds(0.1))
            };

            DoubleAnimation ButtonReverseHorizontalAnimation = new()
            {
                To = 0,
                Duration = new(TimeSpan.FromSeconds(0.1))
            };

            DoubleAnimation ButtonReverseVerticalAnimation = new()
            {
                To = 0,
                Duration = new(TimeSpan.FromSeconds(0.1))
            };

            RoutedEventHandler? FeedbackButtonClickHandler = null;

            FeedbackButtonClickHandler = async (sender, e) =>
            {
                CallPopupsButton.Click -= FeedbackButtonClickHandler;

                //await Task.Delay(100);

                foreach (FocusableButton FocusableButton in PopupButtons)
                {
                    FocusableButton.IsEnabled = false;
                }

                if (PopupButtons[0].Visibility == Visibility.Collapsed)
                {
                    PopupButtons[0].Visibility = Visibility.Visible;

                    PopupButtons[0].RenderTransform.BeginAnimation(TranslateTransform.YProperty, ButtonVerticalUpAnimation);
                    PopupButtons[0].RenderTransform.BeginAnimation(TranslateTransform.XProperty, ButtonHorizontalAnimation);

                    ButtonHorizontalAnimation.Completed += (sender, e) => PopupButtons[0].IsEnabled = true;
                }

                else if (PopupButtons[0].Visibility == Visibility.Visible)
                {
                    PopupButtons[0].RenderTransform.BeginAnimation(TranslateTransform.YProperty, ButtonReverseVerticalAnimation);
                    PopupButtons[0].RenderTransform.BeginAnimation(TranslateTransform.XProperty, ButtonReverseHorizontalAnimation);

                    ButtonReverseHorizontalAnimation.Completed += (sender, e) => PopupButtons[0].Visibility = Visibility.Collapsed;
                }

                if (PopupButtons[1].Visibility == Visibility.Collapsed)
                {
                    PopupButtons[1].Visibility = Visibility.Visible;

                    PopupButtons[1].RenderTransform.BeginAnimation(TranslateTransform.YProperty, ButtonVerticalDownAnimation);
                    PopupButtons[1].RenderTransform.BeginAnimation(TranslateTransform.XProperty, ButtonHorizontalAnimation);

                    ButtonHorizontalAnimation.Completed += (sender, e) => PopupButtons[1].IsEnabled = true;
                }

                else if (PopupButtons[1].Visibility == Visibility.Visible)
                {
                    PopupButtons[1].RenderTransform.BeginAnimation(TranslateTransform.YProperty, ButtonReverseVerticalAnimation);
                    PopupButtons[1].RenderTransform.BeginAnimation(TranslateTransform.XProperty, ButtonReverseHorizontalAnimation);

                    ButtonReverseHorizontalAnimation.Completed += (sender, e) => PopupButtons[1].Visibility = Visibility.Collapsed;
                }

                await Task.Delay(125);

                CallPopupsButton.Click += FeedbackButtonClickHandler;
            };

            CallPopupsButton.Click += FeedbackButtonClickHandler;
        }
    }
}