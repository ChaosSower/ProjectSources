﻿// V. 1.3.0.

using System.Windows.Controls;

using Digital_Schedule_Editor.Classes;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    /// <summary>
    /// Закруглённая кнопка с тенью, получающая логику интерактивной подсветки
    /// и динамического изменения размера через класс <see cref="FocusableButtonClass"/>
    /// </summary>
    public partial class FocusableButton : Button
    {
        private readonly bool _IsButtonGrows;
        public bool IsButtonGrows { get => _IsButtonGrows; set => _ = new FocusableButtonClass(this, value); }

        public FocusableButton()
        {
            InitializeComponent();

            _ = new FocusableButtonClass(this);
        }
    }
}