﻿// V. 0.9.7.

using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Controls.Primitives;

using Digital_Schedule_Editor.Interfaces;

namespace Digital_Schedule_Editor.Controls.CustomControls.EditGroupScheduleWindowControls
{
    /// <summary>
    /// Модульный элемент пары без/с делением на НЧ и Ч неделю
    /// </summary>
    public partial class LessonsControl : UserControl, ILessonsControl
    {
        public string? DayOfWeek { get; set; }
        public int? NumberOfLesson { get; set; }

        private bool? _DivideLessonIntoOddAndEvenWeek;
        public bool? DivideLessonIntoOddAndEvenWeek
        {
            get => _DivideLessonIntoOddAndEvenWeek;

            set
            {
                if (value == true)
                {
                    CreateDoubleLesson();
                    DivideLessonIntoOddAndEvenWeekCheckBox.IsChecked = true;
                }

                else
                {
                    CreateSingleLesson();
                    DivideLessonIntoOddAndEvenWeekCheckBox.IsChecked = false;
                }

                _DivideLessonIntoOddAndEvenWeek = value;
            }
        }

        public string? Subject { get; set; }
        public string? Teacher { get; set; }
        public string? Classroom { get; set; }
        public bool? IsTeacherReplacementModeActivated { get; set; }
        public bool? IsLectureModeActivated { get; set; }

        public string? EvenWeekSubject { get; set; }
        public string? EvenWeekTeacher { get; set; }
        public string? EvenWeekClassroom { get; set; }
        public bool? IsEvenWeekTeacherReplacementModeActivated { get; set; }
        public bool? IsEvenWeekLectureModeActivated { get; set; }

        //private readonly Dictionary<string, (List<(string OddWeekSubject, int OddWeekSubjectHours)>, List<(string EvenWeekSubject, int EvenWeekSubjectHours)>?)> GroupSubjectsDictionary;
        //private readonly Run SubjectsPerDayTextLine;

        //private readonly bool IsHomeroomPeriod;

        private LessonControl? LessonControl;
        private OddAndEvenWeekLessonControl? OddAndEvenWeekLessonControl;

        public LessonsControl(string? DayOfWeek = null, int? NumberOfLesson = null, bool? DivideLessonIntoOddAndEvenWeek = null, string? Subject = null, string? Teacher = null, string? Classroom = null, bool? IsTeacherReplacementModeActivated = null, bool? IsLectureModeActivated = null, string? EvenWeekSubject = null, string? EvenWeekTeacher = null, string? EvenWeekClassroom = null, bool? IsEvenWeekTeacherReplacementModeActivated = null, bool? IsEvenWeekLectureModeActivated = null)
        {
            InitializeComponent();

            DivideLessonIntoOddAndEvenWeekCheckBox.Click += (sender, e) => this.DivideLessonIntoOddAndEvenWeek = !this.DivideLessonIntoOddAndEvenWeek;

            DivideLessonIntoOddAndEvenWeekCheckBox.KeyDown += (sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    if (sender is CheckBox CheckBox)
                    {
                        CheckBox.IsChecked = !CheckBox.IsChecked;
                        DivideLessonIntoOddAndEvenWeekCheckBox.RaiseEvent(new(ButtonBase.ClickEvent));

                        e.Handled = true;
                    }
                }
            };

            this.DayOfWeek = DayOfWeek;
            this.NumberOfLesson = NumberOfLesson;
            this.Subject = Subject;
            this.Teacher = Teacher;
            this.Classroom = Classroom;
            this.IsTeacherReplacementModeActivated = IsTeacherReplacementModeActivated;
            this.IsLectureModeActivated = IsLectureModeActivated;
            this.DivideLessonIntoOddAndEvenWeek = DivideLessonIntoOddAndEvenWeek;
            this.EvenWeekSubject = EvenWeekSubject;
            this.EvenWeekTeacher = EvenWeekTeacher;
            this.EvenWeekClassroom = EvenWeekClassroom;
            this.IsEvenWeekTeacherReplacementModeActivated = IsEvenWeekTeacherReplacementModeActivated;
            this.IsEvenWeekLectureModeActivated = IsEvenWeekLectureModeActivated;
        }

        // Метод создания пары без деления
        private void CreateSingleLesson()
        {
            LessonControlGrid.Children.Remove(OddAndEvenWeekLessonControl);
            OddAndEvenWeekLessonControl = null;

            LessonControl = new()
            {
                IsWeekLessonRegular = true,
                Subject = Subject,
                Teacher = Teacher,
                Classroom = Classroom,
                IsTeacherReplacementModeActivated = IsTeacherReplacementModeActivated,
                IsLectureModeActivated = IsLectureModeActivated
            };

            LessonControl.SetValue(Grid.RowProperty, 1);
            LessonControlGrid.Children.Add(LessonControl);
        }

        // Метод создания пары с делением на НЧ и Ч недели
        private void CreateDoubleLesson()
        {
            LessonControlGrid.Children.Remove(LessonControl);
            LessonControl = null;
            OddAndEvenWeekLessonControl = new();

            OddAndEvenWeekLessonControl.OddWeekLessonControl.Subject = Subject;
            OddAndEvenWeekLessonControl.EvenWeekLessonControl.Subject = EvenWeekSubject;
            OddAndEvenWeekLessonControl.OddWeekLessonControl.Teacher = Teacher;
            OddAndEvenWeekLessonControl.EvenWeekLessonControl.Teacher= EvenWeekTeacher;
            OddAndEvenWeekLessonControl.OddWeekLessonControl.Classroom = Classroom;
            OddAndEvenWeekLessonControl.EvenWeekLessonControl.Classroom = EvenWeekClassroom;

            OddAndEvenWeekLessonControl.SetValue(Grid.RowProperty, 1);
            LessonControlGrid.Children.Add(OddAndEvenWeekLessonControl);
        }
    }
}