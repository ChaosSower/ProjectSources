﻿using Digital_Schedule_Editor.Classes.SerializingClasses;
using Digital_Schedule_Editor.Extensions.CommonComponents;
using Digital_Schedule_Editor.Interfaces;
using Digital_Schedule_Editor.Modules.Windows.College;
using Digital_Schedule_Editor.Modules.Windows.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Digital_Schedule_Editor.Controls.CustomControls.EditGroupScheduleWindowControls
{
    /// <summary>
    /// Модуль пары для НЧ / Ч / обычной недели
    /// </summary>
    public partial class LessonControl : UserControl, ILesson, IEditGroupScheduleWindowControl
    {
        private string? _Subject;
        public required string? Subject
        {
            get => _Subject;

            set
            {
                if (value != null)
                {
                    _Subject = SubjectComboBox.Text = value;
                }
            }
        }

        private string? _Teacher;
        public required string? Teacher
        {
            get => _Teacher;

            set
            {
                if (value != null)
                {
                    _Teacher = TeacherComboBox.Text = value;
                }
            }
        }

        private string? _Classroom;
        public required string? Classroom
        {
            get => _Classroom;

            set
            {
                if (value != null)
                {
                    _Classroom = ClassroomComboBox.Text = value;
                }
            }
        }

        public required bool? IsTeacherReplacementModeActivated { get; set; }
        public required bool? IsLectureModeActivated { get; set; }

        public MainDataClass MainData => EditGroupScheduleWindow.LoadData<MainDataClass>();

        public ObservableCollection<string> SubjectList => new(MainData.SubjectList ?? new());
        public ObservableCollection<string> TeacherList => new(MainData.TeacherList ?? new());
        public ObservableCollection<string> ClassroomList => new(MainData.ClassroomList ?? new());

        private bool _IsWeekLessonRegular;
        public bool IsWeekLessonRegular
        {
            get => _IsWeekLessonRegular;

            set
            {
                if (value)
                {
                    LessonControlGrid.Children.Remove(WeekLabel);
                }

                else
                {
                    if (!LessonControlGrid.Children.Contains(WeekLabel))
                    {
                        LessonControlGrid.Children.Add(WeekLabel);
                    }
                }

                _IsWeekLessonRegular = value;
            }
        }

        private bool _IsOddWeekLesson;
        public bool IsOddWeekLesson
        {
            get => _IsOddWeekLesson;

            set
            {
                if (value)
                {
                    WeekLabel.Content = "НЧ";
                }

                else
                {
                    WeekLabel.Content = "Ч";
                }

                _IsOddWeekLesson = value;
            }
        }

        public LessonControl()
        {
            InitializeComponent();

            //SubjectList = new(MainData.SubjectList);
            //TeacherList = new(MainData.TeacherList);
            //ClassroomList = new(MainData.ClassroomList);

            SubjectComboBox.ItemsSource = SubjectList;
            TeacherComboBox.ItemsSource = TeacherList;
            ClassroomComboBox.ItemsSource = ClassroomList;

            EditMainDataWindow.OnDataChanged += () =>
            {
                SubjectComboBox.ItemsSource = SubjectList;
                TeacherComboBox.ItemsSource = TeacherList;
                ClassroomComboBox.ItemsSource = ClassroomList;
            };

            LessonControlGrid.ProcessAllChildVisualControls(Control =>
            {
                if (Control is ComboBox ComboBox)
                {
                    ComboBox.Loaded += (sender, e) =>
                    {
                        if (ComboBox.Template.FindName("PART_EditableTextBox", ComboBox) is TextBox ComboBoxEditableTextBox)
                        {
                            ComboBoxEditableTextBox.TextAlignment = TextAlignment.Center;
                        }
                    };
                }
            });

            ToolTip ConfirmTeacherReplacementModeButtonToolTip = new()
            {
                Content = new StackPanel()
                {
                    Children =
                    {
                        new TextBlock()
                        {
                            Text = "Режим \"Замена\"",
                            FontWeight = FontWeights.Bold,
                            TextAlignment = TextAlignment.Center,
                            Margin = new(0, 0, 0 , 5)
                        },
                        new TextBlock()
                        {
                            Text = "Нажмите, чтобы назначить преподавателя на замену",
                            TextAlignment = TextAlignment.Center
                        }
                    }
                },
                Foreground = Brushes.Black,
                Padding = new(10),
                Placement = PlacementMode.Mouse
            };

            ToolTipService.SetInitialShowDelay(ConfirmTeacherReplacementModeButton.ButtonWithIndicator, 0);

            ConfirmTeacherReplacementModeButton.ButtonWithIndicator.MouseEnter += (sender, e) =>
            {
                ToolTipService.SetToolTip(ConfirmTeacherReplacementModeButton.ButtonWithIndicator, ConfirmTeacherReplacementModeButtonToolTip);
            };

            ToolTip LectureModeImageToolTip = new()
            {
                Content = new StackPanel()
                {
                    Children =
                    {
                        new TextBlock()
                        {
                            Text = "Режим \"Лекция\"",
                            FontWeight = FontWeights.Bold,
                            TextAlignment = TextAlignment.Center,
                            Margin = new(0, 0, 0 , 5)
                        },
                        new TextBlock()
                        {
                            Text = "Нажмите, чтобы назначить смежную с текущей пару",
                            TextAlignment = TextAlignment.Center
                        }
                    }
                },
                Foreground = Brushes.Black,
                Padding = new(10),
                Placement = PlacementMode.Mouse
            };

            ToolTipService.SetInitialShowDelay(ConfirmLectureModeButton.ButtonWithIndicator, 0);

            ConfirmLectureModeButton.ButtonWithIndicator.MouseEnter += (sender, e) =>
            {
                ToolTipService.SetToolTip(ConfirmLectureModeButton.ButtonWithIndicator, LectureModeImageToolTip);
            };
        }

        // Метод загрузки состояний индикаторов LessonIndicatorsGrid
        private void LoadLessonControlData() // TODO: заменить на управление через свойства
        {
            //if (IsTeacherReplacementModeActivated)
            //{
            //    TeacherReplacementModeIndicator.Fill = Brushes.LightGreen;
            //}

            //else
            //{
            //    TeacherReplacementModeIndicator.Fill = Brushes.Black;
            //}

            //if (IsLectureModeActivated)
            //{
            //    LectureModeIndicator.Fill = Brushes.LightGreen;
            //}

            //else
            //{
            //    LectureModeIndicator.Fill = Brushes.Black;
            //}
        }

        // Событие нажатия на кнопку "Режим замены [преподавателя]"
        private void ConfirmTeacherReplacementModeButton_Click(object sender, RoutedEventArgs e)
        {
            IsTeacherReplacementModeActivated = !IsTeacherReplacementModeActivated;
        }

        // Событие нажатия на кнопку "Режим лекции"
        private void ConfirmLectureModeButton_Click(object sender, RoutedEventArgs e)
        {
            IsLectureModeActivated = !IsLectureModeActivated;
        }
    }
}