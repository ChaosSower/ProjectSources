﻿using System.Windows.Controls;

namespace Digital_Schedule_Editor.Controls.CustomControls.EditGroupScheduleWindowControls
{
    /// <summary>
    /// Модуль пар НЧ и Ч недели
    /// </summary>
    public partial class OddAndEvenWeekLessonControl : UserControl
    {
        public OddAndEvenWeekLessonControl()
        {
            InitializeComponent();
        }
    }
}