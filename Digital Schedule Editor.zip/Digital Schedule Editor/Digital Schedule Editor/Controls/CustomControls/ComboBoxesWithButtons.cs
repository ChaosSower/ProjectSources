﻿// TODO: внести в отдельный проект, скомпилировать в .dll

using Digital_Schedule_Editor.Components.CustomComponents;
using Digital_Schedule_Editor.Extensions.CustomComponents;
using System.Windows.Controls;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    internal abstract class ComboBoxesWithButtons
    {
        private ComboBox? _FirstComboBox;

        public ComboBox? FirstComboBox
        {
            get
            {
                return _FirstComboBox;
            }

            set
            {
                if (value != null)
                {
                    _FirstComboBox = value;
                }
            }
        }

        private List<string>? _FirstComboBoxList;

        public List<string>? FirstComboBoxList
        {
            get
            {
                return _FirstComboBoxList;
            }

            set
            {
                if (value != null)
                {
                    _FirstComboBoxList = value;
                }
            }
        }

        private ComboBox? _SecondComboBox;

        public ComboBox? SecondComboBox
        {
            get
            {
                return _SecondComboBox;
            }

            set
            {
                if (value != null)
                {
                    _SecondComboBox = value;
                }
            }
        }

        private List<string>? _SecondComboBoxList;

        public List<string>? SecondComboBoxList
        {
            get
            {
                return _SecondComboBoxList;
            }

            set
            {
                if (value != null)
                {
                    _SecondComboBoxList = value;
                }
            }
        }

        private ComboBox? _ThirdComboBox;

        public ComboBox? ThirdComboBox
        {
            get
            {
                return _ThirdComboBox;
            }

            set
            {
                if (value != null)
                {
                    _ThirdComboBox = value;
                }
            }
        }

        // Список для хранения пар ComboBox
        private List<(string FirstComboBoxText, string SecondComboBoxText)>? _ComboBoxesPairsList;

        public List<(string FirstComboBoxText, string SecondComboBoxText)>? ComboBoxesPairsList
        {
            get
            {
                return _ComboBoxesPairsList;
            }

            set
            {
                if (value != null)
                {
                    _ComboBoxesPairsList = value;
                }
            }
        }

        //private AutoCompleteStringCollection? AutoCompleteStringCollection;

        // Делегат с параметрами, который будет указывать на метод, который нужно вызвать
        /*protected*/
        public delegate bool ButtonClickDelegate(bool IsAdd, bool BothUniqueComboBoxesPairsListItems = false, int UniqueComboBoxesPairsListItemIndex = -1);
        // первый bool - входной (в экземпляре класса), который передаётся методу,
        // а второй bool - выходной, который принимает возвращаемое значение из "целевого" метода делегата и передаёт его экземпляру
        // при этом второй bool в экземпляре не инициализируется и не указывается.
        // Он нужен для того, чтобы связать различные методы с определёнными экземплярами класса
        public ButtonClickDelegate ButtonClickDelegateVariable;

        /// <summary>
        /// Конструктор, принимающий ComboBox и список, связанный с его элементами
        /// </summary>
        /// <param name="ComboBox">Обрабатываемый ComboBox</param>
        /// <param name="ComboBoxList">Список, связанный с элементами обрабатываемого ComboBox</param>
        public ComboBoxesWithButtons(ComboBox ComboBox, List<string> ComboBoxList)
        {
            FirstComboBox = ComboBox;
            FirstComboBoxList = ComboBoxList;

            // Устанавливаем делегат на метод Button_Click
            ButtonClickDelegateVariable = (IsAdd, _, _) => Button_Click(IsAdd);
        }

        /// <summary>
        /// Конструктор, принимающий два ComboBox, списки, связанные с их элементами, и связующий список
        /// </summary>
        /// <param name="FirstComboBox">Первый обрабатываемый ComboBox</param>
        /// <param name="FirstComboBoxList">Список, связанный с элементами первого обрабатываемого ComboBox</param>
        /// <param name="SecondComboBox">Второй обрабатываемый ComboBox</param>
        /// <param name="SecondComboBoxList">Список, связанный с элементами второго обрабатываемого ComboBox</param>
        /// <param name="ComboBoxesPairsList">Связующий список пар элементов первого и второго обрабатываемого ComboBox</param>
        [Obsolete("Этот конструктор является устаревшим, т.к. в нём отсутствует принимаемый аргумент ThirdComboBox", false)]
        public ComboBoxesWithButtons(ComboBox FirstComboBox, List<string> FirstComboBoxList, ComboBox SecondComboBox, List<string> SecondComboBoxList, List<(string FirstComboBoxText, string SecondComboBoxText)> ComboBoxesPairsList)
        {
            this.FirstComboBox = FirstComboBox;
            this.FirstComboBoxList = FirstComboBoxList;
            this.SecondComboBox = SecondComboBox;
            this.SecondComboBoxList = SecondComboBoxList;
            this.ComboBoxesPairsList = ComboBoxesPairsList;

            // Устанавливаем делегат на метод Button_Click_2
            ButtonClickDelegateVariable = Button_Click;
        }

        /// <summary>
        /// Конструктор, принимающий три ComboBox, и списки, связанные с их элементами (включая связующий список)
        /// </summary>
        /// <param name="FirstComboBox">Первый обрабатываемый ComboBox</param>
        /// <param name="FirstComboBoxList">Список, связанный с элементами первого обрабатываемого ComboBox</param>
        /// <param name="SecondComboBox">Второй обрабатываемый ComboBox</param>
        /// <param name="SecondComboBoxList">Список, связанный с элементами второго обрабатываемого ComboBox</param>
        /// <param name="ThirdComboBox">Связующий третий ComboBox со связанными элементами первого и второго ComboBox</param>
        /// <param name="ComboBoxesPairsList">Связующий список пар элементов первого и второго обрабатываемого ComboBox</param>
        public ComboBoxesWithButtons(ComboBox FirstComboBox, List<string> FirstComboBoxList, ComboBox SecondComboBox, List<string> SecondComboBoxList, ComboBox ThirdComboBox, List<(string FirstComboBoxText, string SecondComboBoxText)> ComboBoxesPairsList) : this(FirstComboBox, FirstComboBoxList, SecondComboBox, SecondComboBoxList, ComboBoxesPairsList)
        {
            this.ThirdComboBox = ThirdComboBox;

            //this.FirstComboBox = FirstComboBox;
            //this.FirstComboBoxList = FirstComboBoxList;
            //this.SecondComboBox = SecondComboBox;
            //this.SecondComboBoxList = SecondComboBoxList;
            
            //this.ComboBoxesPairsList = ComboBoxesPairsList;

            //// Устанавливаем делегат на метод Button_Click_2
            //ButtonClickDelegateVariable = Button_Click;
        }

        // Общий обработчик событий для кнопок
        public bool Button_Click(bool IsAdd)
        {
            return ModifyComboBoxItemsAndItsList(IsAdd);
        }

        private bool ModifyComboBoxItemsAndItsList(bool IsAdd)
        {
            if (FirstComboBox != null && FirstComboBoxList != null)
            {
                // Проверяем, что введено хоть что-то
                if (string.IsNullOrWhiteSpace(FirstComboBox.Text))
                {
                    return false;
                }

                // Проверяем, есть ли такой элемент в списке
                else if (IsAdd && FirstComboBoxList.Contains(FirstComboBox.Text) || !IsAdd && !FirstComboBoxList.Contains(FirstComboBox.Text))
                {
                    return false;
                }

                else
                {
                    // Модифицируем список
                    ModifyList(FirstComboBoxList, FirstComboBox.Text, IsAdd);

                    // Модифицируем ComboBox
                    ModifyComboBoxItems(FirstComboBox, IsAdd);

                    //AutoCompleteStringCollection = new();
                    //AutoCompleteStringCollection.AddRange(FirstComboBoxList.ToArray());
                    //FirstComboBox.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    //FirstComboBox.AutoCompleteCustomSource = AutoCompleteStringCollection;
                    //FirstComboBox.AutoCompleteMode = AutoCompleteMode.Suggest;

                    FirstComboBox.Text = string.Empty;
                    //FirstComboBox.ForeColor = Color.Gray; // т.к. это надо делать на главной форме (проверка
                    // осуществляется тоже там)

                    return true;
                }
            }

            else
            {
                return false;
            }
        }

        // Общий метод для добавления и удаления элементов из списка
        public virtual void ModifyList(List<string> List, string Item, bool IsAdd)
        {
            if (IsAdd)
            {
                List.Add(Item);
            }

            else
            {
                List.Remove(Item);
            }

            // Сортировка списка
            //CustomCollection myList = new(List);
            /*my*/List.SortCollection();
        }

        private void ModifyComboBoxItems(ComboBox ComboBox, bool IsAdd)
        {
            if (IsAdd)
            {
                ComboBox.Items.Add(ComboBox.Text.Replace('-', '—')); // Костыль!!! Будет срабатывать и в ComboBox без связей!
            }

            else
            {
                ComboBox.Items.Remove(ComboBox.Text.Replace('-', '—'));
            }

            // Сортировка элементов ComboBox
            //CustomCollection MyComboBox = new(ComboBox);
            ///*My*/ComboBox.SortCollection();
        }

        public bool Button_Click(bool IsAdd, bool BothUniqueComboBoxesPairsListItems = false, int UniqueComboBoxesPairsListItemIndex = -1)
        {
            return ModifyComboBoxesList(IsAdd, BothUniqueComboBoxesPairsListItems, UniqueComboBoxesPairsListItemIndex);
        }

        private bool ModifyComboBoxesList(bool IsAdd, bool BothUniqueComboBoxesPairsListItems, int UniqueComboBoxesPairsListItemIndex)
        {
            if (FirstComboBox != null && FirstComboBoxList != null && SecondComboBox != null && SecondComboBoxList != null && _ComboBoxesPairsList != null)
            {
                string FirstComboBoxText = string.Empty;
                string SecondComboBoxText = string.Empty;

                if (ThirdComboBox != null)
                {
                    // Проверяем, есть ли такие элементы в списках (должны быть, если нет - идём вглубь по условиям проверки)
                    if (IsAdd && !FirstComboBoxList.Contains(FirstComboBox.Text) || !IsAdd && !FirstComboBoxList.Contains(FirstComboBox.Text) || IsAdd && !SecondComboBoxList.Contains(SecondComboBox.Text) || !IsAdd && !SecondComboBoxList.Contains(SecondComboBox.Text))
                    {
                        // Проверяем, что введено хоть что-то
                        if (/*ThirdComboBox.ForeColor == Color.Gray || */string.IsNullOrWhiteSpace(ThirdComboBox.Text))
                        {
                            return false;
                        }

                        else
                        {
                            string ThirdComboBoxText = ThirdComboBox.Text.Replace('-', '—'); // если пользователь ввёл дефис, а не тире
                            string[] ComboBoxesAndTheirText = ThirdComboBoxText.Split(new[] { " — " }, StringSplitOptions.None);

                            if (ComboBoxesAndTheirText.Length == 2)
                            {
                                FirstComboBoxText = ComboBoxesAndTheirText[0];
                                SecondComboBoxText = ComboBoxesAndTheirText[1];

                                if (!FirstComboBox.Items.Contains(FirstComboBoxText) || !SecondComboBox.Items.Contains(SecondComboBoxText))
                                {
                                    //MessageBox.Show("Введённая доступная связь не найдена!\n\nПожалуйста, убедитесь, что вы ввели существующие данные", "Не удалось создать связь", MessageBoxButtons.OK, MessageBoxIcon.Error);

                                    if (IsAdd)
                                    {
                                        return false;
                                    }
                                }
                            }

                            else
                            {
                                return false;
                            }
                        }
                    }
                }

                else
                {
                    // Проверяем, что введено хоть что-то
                    if (/*FirstComboBox.ForeColor == Color.Gray || SecondComboBox.ForeColor == Color.Gray || */string.IsNullOrWhiteSpace(FirstComboBox.Text) || string.IsNullOrWhiteSpace(SecondComboBox.Text))
                    {
                        return false;
                    }

                    // Проверяем, есть ли такие элементы в списках (должны быть)
                    else if (IsAdd && !FirstComboBoxList.Contains(FirstComboBox.Text) || !IsAdd && !FirstComboBoxList.Contains(FirstComboBox.Text) || IsAdd && !SecondComboBoxList.Contains(SecondComboBox.Text) || !IsAdd && !SecondComboBoxList.Contains(SecondComboBox.Text))
                    {
                        //MessageBox.Show("Введённые данные отсутствуют в списке(ах)!\n\nПожалуйста, убедитесь, что вы ввели существующие данные", "Не удалось создать связь", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        //TODO: сделать ободок ComboBox красным после вывода сообщения
                        //(можно вообще сделать в виде плавного покраснения ободка с помощью асинхронности)

                        return false;
                    }
                }

                if (IsAdd)
                {
                    (string FirstComboBoxText, string SecondComboBoxText) PairToAdd;

                    if (ThirdComboBox != null)
                    {
                        if (FirstComboBoxText != string.Empty && SecondComboBoxText != string.Empty)
                        {
                            if (ThirdComboBox.Items.Contains(FirstComboBoxText + " — " + SecondComboBoxText))
                            {
                                return false;
                            }

                            else
                            {
                                PairToAdd = (FirstComboBoxText, SecondComboBoxText);
                            }
                        }

                        else
                        {
                            PairToAdd = (FirstComboBox.Text, SecondComboBox.Text);
                        }
                    }

                    else
                    {
                        PairToAdd = (FirstComboBox.Text, SecondComboBox.Text);
                    }

                    // Проверяем, существует ли уже такая пара в списке
                    if (!_ComboBoxesPairsList.Contains(PairToAdd))
                    {
                        // Критерии фильтрации //

                        // Проверяем, уникальны ли элементы пары
                        if (BothUniqueComboBoxesPairsListItems && _ComboBoxesPairsList.Any(Pair => Pair.FirstComboBoxText == PairToAdd.FirstComboBoxText || Pair.SecondComboBoxText == PairToAdd.SecondComboBoxText))
                        {
                            //MessageBox.Show("Введённые данные не соответствуют заданным параметрам фильтрации!\n\nПожалуйста, убедитесь, что ваши данные удовлетворяют следующему условию:\n\nДанных первого и второго поля со списком нет в уже имеющихся данных", "Не удалось создать связь", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            return false;
                        }

                        if (UniqueComboBoxesPairsListItemIndex == 0 && _ComboBoxesPairsList.Any(Pair => Pair.FirstComboBoxText == PairToAdd.FirstComboBoxText))
                        {
                            //MessageBox.Show("Введённые данные не соответствуют заданным параметрам фильтрации!\n\nПожалуйста, убедитесь, что ваши данные удовлетворяют следующему условию:\n\nДанных первого поля со списком нет в уже имеющихся данных", "Не удалось создать связь", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            return false;
                        }

                        if (UniqueComboBoxesPairsListItemIndex == 1 && _ComboBoxesPairsList.Any(Pair => Pair.SecondComboBoxText == PairToAdd.SecondComboBoxText))
                        {
                            //MessageBox.Show("Введённые данные не соответствуют заданным параметрам фильтрации!\n\nПожалуйста, убедитесь, что ваши данные удовлетворяют следующему условию:\n\nДанных второго поля со списком нет в уже имеющихся данных", "Не удалось создать связь", MessageBoxButtons.OK, MessageBoxIcon.Error);

                            return false;
                        }

                        else
                        {
                            _ComboBoxesPairsList.Add(PairToAdd);

                            if (ThirdComboBox != null)
                            {
                                if (FirstComboBoxText != string.Empty && SecondComboBoxText != string.Empty)
                                {
                                    ModifyComboBoxItems(ThirdComboBox, true);
                                }

                                else
                                {
                                    ThirdComboBox.Items.Add(PairToAdd.FirstComboBoxText + " — " + PairToAdd.SecondComboBoxText);
                                }
                            }
                        }
                    }

                    else // пара уже существует в списке
                    {
                        return false;
                    }
                }

                else
                {
                    (string FirstComboBoxText, string SecondComboBoxText) PairToRemove;

                    if (ThirdComboBox != null)
                    {
                        if (FirstComboBoxText != string.Empty && SecondComboBoxText != string.Empty)
                        {
                            if (!ThirdComboBox.Items.Contains(FirstComboBoxText + " — " + SecondComboBoxText))
                            {
                                return false;
                            }

                            else
                            {
                                PairToRemove = (FirstComboBoxText, SecondComboBoxText);
                            }
                        }

                        else
                        {
                            PairToRemove = (FirstComboBox.Text, SecondComboBox.Text);
                        }
                    }

                    else
                    {
                        PairToRemove = (FirstComboBox.Text, SecondComboBox.Text);
                    }

                    // TODO: переделать, чтобы было без индексов
                    int PairIndexToRemove = _ComboBoxesPairsList.IndexOf(PairToRemove);

                    if (PairIndexToRemove != -1)
                    {
                        _ComboBoxesPairsList.RemoveAt(PairIndexToRemove);

                        if (ThirdComboBox != null)
                        {
                            if (FirstComboBoxText != string.Empty && SecondComboBoxText != string.Empty)
                            {
                                ModifyComboBoxItems(ThirdComboBox, false);
                            }

                            else
                            {
                                ThirdComboBox.Items.Remove(PairToRemove.FirstComboBoxText + " — " + PairToRemove.SecondComboBoxText);
                            }
                        }
                    }

                    else
                    {
                        return false;
                    }
                }

                _ComboBoxesPairsList.Sort();

                FirstComboBox.Text = string.Empty;
                //FirstComboBox.ForeColor = Color.Gray;
                SecondComboBox.Text = string.Empty;
                //SecondComboBox.ForeColor = Color.Gray;

                if (ThirdComboBox != null)
                {
                    //AutoCompleteStringCollection = new();
                    //AutoCompleteStringCollection.AddRange(ThirdComboBox.Items.Cast<string>().ToArray());
                    //ThirdComboBox.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    //ThirdComboBox.AutoCompleteCustomSource = AutoCompleteStringCollection;
                    //ThirdComboBox.AutoCompleteMode = AutoCompleteMode.Suggest;

                    ThirdComboBox.Text = string.Empty;
                    //ThirdComboBox.ForeColor = Color.Gray;
                }

                return true;
            }

            else
            {
                return false;
            }
        }
    }
}