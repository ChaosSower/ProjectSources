﻿// На удаление!

//https://stackoverflow.com/questions/9768938/change-the-bordercolor-of-the-textbox

using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Controls;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    public class CustomTextBox : TextBox
    {
        //??
        public CustomTextBox()
        {
            BorderThickness = 1;
            BorderColor = SystemColors.WindowFrame;
            LeftBorderThickness = TopBorderThickness = RightBorderThickness = BottomBorderThickness = BorderThickness;
            LeftBorderColor = TopBorderColor = RightBorderColor = BottomBorderColor = BorderColor;
        }

        const int PaintMessage = 0x85;
        const uint InvalidateFlag = 0x1;
        const uint UpdateNowFlag = 0x100;
        const uint FrameFlag = 0x400;

        //GetWindowDeviceContext
        [DllImport("user32.dll")]
        static extern IntPtr GetWindowDC(IntPtr WindowHandle);

        //ReleaseDeviceContext
        [DllImport("user32.dll")]
        static extern int ReleaseDC(IntPtr WindowHandle, IntPtr DeviceContextHandle);

        [DllImport("user32.dll")]
        static extern bool RedrawWindow(IntPtr WindowHandle, IntPtr RectanglePointer, IntPtr RegionHandle, uint Flags);

        private int _BorderThickness = 1;
        private Color _BorderColor = SystemColors.WindowFrame;

        private int _LeftBorderThickness;
        private int _TopBorderThickness;
        private int _RightBorderThickness;
        private int _BottomBorderThickness;

        private Color _LeftBorderColor;
        private Color _TopBorderColor;
        private Color _RightBorderColor;
        private Color _BottomBorderColor;

        public int BorderThickness
        {
            get => _BorderThickness;

            set
            {
                if (value < Height / 2 && value < Width / 2)
                {
                    _BorderThickness = value;
                }

                //???
                else
                {
                    _BorderThickness = (int)(Height * Width / 2);
                }

                _LeftBorderThickness = _TopBorderThickness = _RightBorderThickness = _BottomBorderThickness = value;
                InvalidateVisual(); //нужна перерисовка?
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public int LeftBorderThickness
        {
            get => _LeftBorderThickness;

            set
            {
                if (value < Width / 2)
                {
                    _LeftBorderThickness = value;
                }

                else
                {
                    _LeftBorderThickness = (int)(Width / 2);
                }

                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public int TopBorderThickness
        {
            get => _TopBorderThickness;

            set
            {
                if (value < Height / 2)
                {
                    _TopBorderThickness = value;
                }

                else
                {
                    _TopBorderThickness = (int)(Height / 2);
                }

                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public int RightBorderThickness
        {
            get => _RightBorderThickness;

            set
            {
                if (value < Width / 2)
                {
                    _RightBorderThickness = value;
                }

                else
                {
                    _RightBorderThickness = (int)(Width / 2);
                }

                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public int BottomBorderThickness
        {
            get => _BottomBorderThickness;

            set
            {
                if (value < Height / 2)
                {
                    _BottomBorderThickness = value;
                }

                else
                {
                    _BottomBorderThickness = (int)(Height / 2);
                }

                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public Color BorderColor
        {
            get => _BorderColor;

            set
            {
                _BorderColor = value;
                _LeftBorderColor = _TopBorderColor = _RightBorderColor = _BottomBorderColor = value;
                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public Color LeftBorderColor
        {
            get => _LeftBorderColor;

            set
            {
                _LeftBorderColor = value;
                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public Color TopBorderColor
        {
            get => _TopBorderColor;

            set
            {
                _TopBorderColor = value;
                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public Color RightBorderColor
        {
            get => _RightBorderColor;

            set
            {
                _RightBorderColor = value;
                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        public Color BottomBorderColor
        {
            get => _BottomBorderColor;

            set
            {
                _BottomBorderColor = value;
                InvalidateVisual();
                //RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
            }
        }

        //protected override void OnGotFocus(EventArgs e)
        //{

        //}

        //protected override void OnLostFocus(EventArgs e)
        //{

        //}

        //WindowProcedure
        //protected override void WndProc(ref Message WindowMessage)
        //{
        //    if (WindowMessage.Msg == PaintMessage && MouseIsOver())
        //    {
        //        // Не вызываем базовый метод, чтобы предотвратить отрисовку границы
        //        return;
        //    }

        //    base.WndProc(ref WindowMessage);

        //    //if (WindowMessage.Msg == PaintMessage)
        //    {
        //        nint DeviceContextHandle = GetWindowDC(Handle);

        //        using (Graphics Graphics = Graphics.FromHdcInternal(DeviceContextHandle))
        //        {
        //            Pen[] pens = new Pen[4]
        //            {
        //                new(_LeftBorderColor, _LeftBorderThickness),
        //                new(_TopBorderColor, _TopBorderThickness),
        //                new(_RightBorderColor, _RightBorderThickness),
        //                new(_BottomBorderColor, _BottomBorderThickness)
        //            };

        //            Point[][] points = new Point[4][]
        //            {
        //                new[] { new(0, 0), new Point(0, (int)Height) },
        //                new[] { new(Convert.ToInt16(LeftBorderThickness / 1.85f), 0), new Point((int)(Width - Convert.ToInt16(RightBorderThickness / 1.75f)), 0) },
        //                new[] { new((int)(Width - 1), 0), new Point((int)(Width - 1), (int)Height) },
        //                new[] { new(Convert.ToInt16(LeftBorderThickness / 1.85f), (int)Height - 1), new Point((int)(Width - Convert.ToInt16(RightBorderThickness / 1.75f)), (int)Height - 1) }
                        
        //                // TODO: другая вариация наслаивания рамок
        //                //new[] { new(0, Convert.ToInt16(TopBorderThickness / 1.85f)), new Point(0, Height - Convert.ToInt16(BottomBorderThickness / 1.75f)) },
        //                //new[] { new(0, 0), new Point(Width, 0) },
        //                //new[] { new(Width - 1, Convert.ToInt16(TopBorderThickness / 1.85f)), new Point(Width - 1, Height - Convert.ToInt16(BottomBorderThickness / 1.75f)) },
        //                //new[] { new(0, Height - 1), new Point(Width, Height - 1) }
        //            };

        //            for (int i = 0; i < pens.Length; i++)
        //            {
        //                Graphics.DrawLine(pens[i], points[i][0], points[i][1]);
        //                pens[i].Dispose();
        //            }
        //        }

        //        ReleaseDC(Handle, DeviceContextHandle);
        //    }
        //}

        ////?
        //private bool MouseIsOver()
        //{
        //    Point ClientPoint = PointToClient(Cursor.Position);
        //    return ClientRectangle.Contains(ClientPoint);
        //}

        //protected override void OnSizeChanged(EventArgs e)
        //{
        //    base.OnSizeChanged(e);

        //    RedrawWindow(Handle, IntPtr.Zero, IntPtr.Zero, FrameFlag | UpdateNowFlag | InvalidateFlag);
        //}
    }
}