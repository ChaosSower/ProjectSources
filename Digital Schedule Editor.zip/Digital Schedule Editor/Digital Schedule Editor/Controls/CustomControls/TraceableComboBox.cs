﻿// TODO: внести в отдельный проект, скомпилировать в .dll
// TODO: продумать, как можно добавить связь, если используется LinkComboBox
// TODO: объединить все имеющиеся ComboBox в 1 пользовательский элемент
// TODO: (опционально) добавить TollTip для элементов + ограничить время его отображения 3-мя секундами

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    public class TraceableComboBox : ComboBox
    {
        // Список для отслеживания добавленных элементов
        private List<(object Item, bool IsAdded)> ComboBoxItemList = new();

        private Button _AddItemButton = new();
        public Button AddItemButton
        {
            get => _AddItemButton;

            set
            {
                _AddItemButton = value;

                _AddItemButton.Click += (sender, e) =>
                {
                    AddItem(Text);
                    Text = string.Empty;
                };
            }
        }

        private Button _SaveItemsButton = new();
        public Button SaveItemsButton
        {
            get => _SaveItemsButton;

            set
            {
                _SaveItemsButton = value;

                _SaveItemsButton.Click += (sender, e) =>
                {
                    ComboBoxItemList = ComboBoxItemList.Select(ComboBoxItem => (ComboBoxItem.Item, false)).ToList();
                    Items.Refresh();
                };
            }
        }

        public TraceableComboBox()
        {
            Initialized += (sender, e) =>
            {
                foreach (object Item in Items)
                {
                    ComboBoxItemList.Add((Item, false));
                }
            };

            ItemContainerStyleSelector = new TraceableComboBoxStyleSelector(this);
        }

        public TraceableComboBox(Button AddItemButton, Button SaveItemsButton) : this()
        {
            this.AddItemButton = AddItemButton;
            this.SaveItemsButton = SaveItemsButton;
        }

        // Метод для добавления элемента по нажатию кнопки
        private void AddItem(object item)
        {
            ComboBoxItemList.Add((item, true));
            Items.Add(item);
        }

        private class TraceableComboBoxStyleSelector : StyleSelector
        {
            private readonly TraceableComboBox TraceableComboBox;

            public TraceableComboBoxStyleSelector(TraceableComboBox TraceableComboBox)
            {
                this.TraceableComboBox = TraceableComboBox;
            }

            public override Style SelectStyle(object TraceableComboBoxItem, DependencyObject? _ = null)
            {
                Style Style = new(typeof(ComboBoxItem));

                foreach ((object Item, bool IsAdded) in TraceableComboBox.ComboBoxItemList)
                {
                    if (TraceableComboBoxItem.Equals(Item))
                    {
                        if (IsAdded)
                        {
                            Style.Setters.Add(new Setter(BackgroundProperty, Brushes.Black));
                            Style.Setters.Add(new Setter(ForegroundProperty, Brushes.White));

                            // Создаём триггеры для событий MouseEnter и MouseLeave
                            Trigger MouseEnterTrigger = new()
                            {
                                Property = IsMouseOverProperty,
                                Value = true
                            };

                            MouseEnterTrigger.Setters.Add(new Setter(ForegroundProperty, Brushes.Red));
                            Style.Triggers.Add(MouseEnterTrigger);

                            Trigger MouseLeaveTrigger = new()
                            {
                                Property = IsMouseOverProperty,
                                Value = false
                            };

                            MouseLeaveTrigger.Setters.Add(new Setter(ForegroundProperty, Brushes.White));
                            Style.Triggers.Add(MouseLeaveTrigger);
                        }

                        else
                        {
                            Style.Setters.Add(new Setter(BackgroundProperty, Brushes.White));
                            Style.Setters.Add(new Setter(ForegroundProperty, Brushes.Black));
                        }
                    }
                }

                return Style;
            }
        }
    }
}