﻿// V.2.5

// TODO: внести в отдельный проект, скомпилировать в .dll
// TODO: добавить unit-тесты экземпляров с разным количеством кнопок и разной высотой контейнера
// (1, 2, 3)
// TODO: проверить корректность центрирования каждого из текстов
// TODO: добавить unit-тесты экземпляров с разными шрифтами и их размерами
// (null, шрифт 1 и null, null и шрифт 2, шрифт 1 и шрифт 2 с разными размерами и т.д.)
// проверить в нём, что позиция текста (не?) фиксирована, а динамична (зависит от шрифта)

using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    internal class SeparateLabelClass
    {
        internal class SeparateLabel : Grid
        {
            protected bool _DiagonalFromTopLeftToBottomRight = true;

            public bool? DiagonalFromTopLeftToBottomRight
            {
                get => _DiagonalFromTopLeftToBottomRight;

                set
                {
                    if (value != null)
                    {
                        _DiagonalFromTopLeftToBottomRight = (bool)value;
                    }
                }
            }

            private Brush _LeftTriangleBrush = Brushes.White;

            public Brush? LeftTriangleBrush
            {
                get => _LeftTriangleBrush;

                set
                {
                    if (value != null)
                    {
                        _LeftTriangleBrush = value;
                    }
                }
            }

            private Brush _RightTriangleBrush = Brushes.Black;

            public Brush? RightTriangleBrush
            {
                get => _RightTriangleBrush;

                set
                {
                    if (value != null)
                    {
                        _RightTriangleBrush = value;
                    }
                }
            }

            private Brush _LeftLabelTextBrush = Brushes.Black;

            public Brush? LeftLabelTextBrush
            {
                get => _LeftLabelTextBrush;

                set
                {
                    if (value != null)
                    {
                        _LeftLabelTextBrush = value;
                    }
                }
            }

            private Brush _RightLabelTextBrush = Brushes.White;

            public Brush? RightLabelTextBrush
            {
                get => _RightLabelTextBrush;

                set
                {
                    if (value != null)
                    {
                        _RightLabelTextBrush = value;
                    }
                }
            }

            private string _LeftLabelText = string.Empty;

            public string LeftLabelText
            {
                get => _LeftLabelText;

                set
                {
                    if (value != null)
                    {
                        _LeftLabelText = value;
                        LeftLabelTextBlock.Text = value;
                    }
                }
            }

            private string _RightLabelText = string.Empty;

            public string RightLabelText
            {
                get => _RightLabelText;

                set
                {
                    if (value != null)
                    {
                        _RightLabelText = value;
                        RightLabelTextBlock.Text = value;
                    }
                }
            }

            private FontFamily _LeftLabelFontFamily = new("Segoe UI");

            public FontFamily? LeftLabelFontFamily
            {
                get => _LeftLabelFontFamily;

                set
                {
                    if (value != null)
                    {
                        _LeftLabelFontFamily = value;
                        LeftLabelTextBlock.FontFamily = _LeftLabelFontFamily;
                    }
                }
            }

            private double _LeftLabelFontSize;

            public double? LeftLabelFontSize
            {
                get => _LeftLabelFontSize;

                set
                {
                    if (value > 0)
                    {
                        _LeftLabelFontSize = (double)value;
                        LeftLabelTextBlock.FontSize = _LeftLabelFontSize;
                    }
                }
            }

            private FontFamily _RightLabelFontFamily = new("Segoe UI");

            public FontFamily? RightLabelFontFamily
            {
                get => _RightLabelFontFamily;

                set
                {
                    if (value != null)
                    {
                        _RightLabelFontFamily = value;
                        RightLabelTextBlock.FontFamily = _RightLabelFontFamily;
                    }
                }
            }

            private double _RightLabelFontSize;

            public double? RightLabelFontSize
            {
                get => _RightLabelFontSize;

                set
                {
                    if (value > 0)
                    {
                        _RightLabelFontSize = (double)value;
                        RightLabelTextBlock.FontSize = _RightLabelFontSize;
                    }
                }
            }

            protected TextBlock LeftLabelTextBlock = new();
            protected TextBlock RightLabelTextBlock = new();

            // Конструктор с параметрами цветов и размером шрифта текста пользовательской метки
            public SeparateLabel(bool? DiagonalFromTopLeftToBottomRight = true, Brush? LeftTriangleBrush = null, Brush? RightTriangleBrush = null, Brush? LeftLabelTextBrush = null, Brush? RightLabelTextBrush = null, string LeftLabelText = "", string RightLabelText = "", FontFamily? LabelsFontFamily = null, double? LabelsFontSize = null)
            {
                this.DiagonalFromTopLeftToBottomRight = DiagonalFromTopLeftToBottomRight;
                this.LeftTriangleBrush = LeftTriangleBrush;
                this.RightTriangleBrush = RightTriangleBrush;
                this.LeftLabelTextBrush = LeftLabelTextBrush;
                this.RightLabelTextBrush = RightLabelTextBrush;
                this.LeftLabelText = LeftLabelText;
                this.RightLabelText = RightLabelText;
                LeftLabelFontFamily = LabelsFontFamily;
                LeftLabelFontSize = LabelsFontSize;
                RightLabelFontFamily = LabelsFontFamily;
                RightLabelFontSize = LabelsFontSize;

                Loaded += (sender, e) => CreateControl();
            }

            // Конструктор с параметрами цветов и размерами шрифта текста для каждой из пользовательских меток
            public SeparateLabel(bool? DiagonalFromTopLeftToBottomRight = true, Brush? LeftTriangleBrush = null, Brush? RightTriangleBrush = null, Brush? LeftLabelTextBrush = null, Brush? RightLabelTextBrush = null, string LeftLabelText = "", string RightLabelText = "", FontFamily? LeftLabelFontFamily = null, double? LeftLabelFontSize = null, FontFamily? RightLabelFontFamily = null, double? RightLabelFontSize = null) : this(DiagonalFromTopLeftToBottomRight, LeftTriangleBrush, RightTriangleBrush, LeftLabelTextBrush, RightLabelTextBrush, LeftLabelText, RightLabelText, null, null)
            {
                this.LeftLabelFontFamily = LeftLabelFontFamily;
                this.LeftLabelFontSize = LeftLabelFontSize;
                this.RightLabelFontFamily = RightLabelFontFamily;
                this.RightLabelFontSize = RightLabelFontSize;
            }

            protected virtual void CreateControl()
            {
                Grid SeparateLabelGrid = new();

                Polygon LeftLabel = new()
                {
                    Fill = _LeftTriangleBrush,
                    Stretch = Stretch.Fill
                };

                Polygon RightLabel = new()
                {
                    Fill = _RightTriangleBrush,
                    Stretch = Stretch.Fill
                };

                if (_LeftLabelFontSize <= 0)
                {
                    _LeftLabelFontSize = Math.Sqrt(Math.Pow(ActualWidth, 2) + Math.Pow(ActualHeight, 2)) * 0.075;
                }

                if (_RightLabelFontSize <= 0)
                {
                    _RightLabelFontSize = Math.Sqrt(Math.Pow(ActualWidth, 2) + Math.Pow(ActualHeight, 2)) * 0.075;
                }

                LeftLabelTextBlock = new()
                {
                    Text = _LeftLabelText,
                    Foreground = _LeftLabelTextBrush,
                    FontFamily = _LeftLabelFontFamily,
                    FontSize = _LeftLabelFontSize,
                    HorizontalAlignment = HorizontalAlignment.Left
                };

                RightLabelTextBlock = new()
                {
                    Text = _RightLabelText,
                    Foreground = _RightLabelTextBrush,
                    FontFamily = _RightLabelFontFamily,
                    FontSize = _RightLabelFontSize,
                    HorizontalAlignment = HorizontalAlignment.Right
                };

                if (_LeftLabelFontSize > Math.Sqrt(Math.Pow(ActualWidth, 2) + Math.Pow(ActualHeight, 2)) * 0.075 + 1)
                {
                    //_LeftLabelFontSize = Math.Sqrt(Math.Pow(ActualWidth, 2) + Math.Pow(ActualHeight, 2)) * 0.075;
                    //LeftLabelTextBlock.FontSize = _LeftLabelFontSize;
                }

                if (_RightLabelFontSize > Math.Sqrt(Math.Pow(ActualWidth, 2) + Math.Pow(ActualHeight, 2)) * 0.075 + 1)
                {
                    //_RightLabelFontSize = Math.Sqrt(Math.Pow(ActualWidth, 2) + Math.Pow(ActualHeight, 2)) * 0.075;
                    //RightLabelTextBlock.FontSize = _RightLabelFontSize;
                }

                if (_DiagonalFromTopLeftToBottomRight)
                {
                    LeftLabel.Points = new(new List<Point> { new(0, 1), new(0, 0), new(1, 1) });
                    RightLabel.Points = new(new List<Point> { new(0, 0), new(1, 0), new(1, 1) });
                    LeftLabelTextBlock.VerticalAlignment = VerticalAlignment.Bottom;
                    RightLabelTextBlock.VerticalAlignment = VerticalAlignment.Top;
                }

                else
                {
                    LeftLabel.Points = new(new List<Point> { new(0, 1), new(0, 0), new(1, 0) });
                    RightLabel.Points = new(new List<Point> { new(1, 0), new(1, 1), new(0, 1) });
                    LeftLabelTextBlock.VerticalAlignment = VerticalAlignment.Top;
                    RightLabelTextBlock.VerticalAlignment = VerticalAlignment.Bottom;
                }

                SeparateLabelGrid.Children.Add(LeftLabel);
                SeparateLabelGrid.Children.Add(RightLabel);
                SeparateLabelGrid.Children.Add(LeftLabelTextBlock);
                SeparateLabelGrid.Children.Add(RightLabelTextBlock);

                Children.Add(SeparateLabelGrid);
            }
        }

        internal class SeparateLabelWithAngledText : SeparateLabel
        {
            public SeparateLabelWithAngledText(bool? DiagonalFromTopLeftToBottomRight = true, Brush? LeftTriangleBrush = null, Brush? RightTriangleBrush = null, Brush? LeftLabelTextBrush = null, Brush? RightLabelTextBrush = null, string LeftLabelText = "", string RightLabelText = "", FontFamily? LeftLabelFontFamily = null, int LeftLabelFontSize = 0, FontFamily? RightLabelFontFamily = null, int RightLabelFontSize = 0) : base(DiagonalFromTopLeftToBottomRight, LeftTriangleBrush, RightTriangleBrush, LeftLabelTextBrush, RightLabelTextBrush, LeftLabelText, RightLabelText, LeftLabelFontFamily, LeftLabelFontSize, RightLabelFontFamily, RightLabelFontSize)
            { }

            protected override void CreateControl()
            {
                base.CreateControl();

                // Наклон и положение текста в зависимости от значения DiagonalFromTopLeftToBottomRight //

                double AngleInRadians = Math.Atan2(ActualHeight, ActualWidth);
                double AngleInDegrees = AngleInRadians * (180 / Math.PI);

                //Typeface LeftLabelTextBlockTypeFace = new(LeftLabelTextBlock.FontFamily, LeftLabelTextBlock.FontStyle, LeftLabelTextBlock.FontWeight, LeftLabelTextBlock.FontStretch);
                //FormattedText LeftLabelTextBlockFormattedText = new(LeftLabelTextBlock.Text, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, LeftLabelTextBlockTypeFace, LeftLabelTextBlock.FontSize, null, VisualTreeHelper.GetDpi(LeftLabelTextBlock).PixelsPerDip);
                //double LeftLabelTextBlockWidth = LeftLabelTextBlockFormattedText.Width;
                //double LeftLabelTextBlockHeight = LeftLabelTextBlockFormattedText.Height;

                Typeface RightLabelTextBlockTypeFace = new(RightLabelTextBlock.FontFamily, RightLabelTextBlock.FontStyle, RightLabelTextBlock.FontWeight, RightLabelTextBlock.FontStretch);
                FormattedText RightLabelTextBlockFormattedText = new(RightLabelTextBlock.Text, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, RightLabelTextBlockTypeFace, RightLabelTextBlock.FontSize, null, VisualTreeHelper.GetDpi(RightLabelTextBlock).PixelsPerDip);
                double RightLabelTextBlockWidth = RightLabelTextBlockFormattedText.Width;
                double RightLabelTextBlockHeight = RightLabelTextBlockFormattedText.Height;

                if (_DiagonalFromTopLeftToBottomRight)
                {
                    LeftLabelTextBlock.RenderTransform = new RotateTransform(AngleInDegrees);
                    RightLabelTextBlock.RenderTransform = new RotateTransform(AngleInDegrees);
                    RightLabelTextBlock.Margin = new(RightLabelTextBlockHeight, 0, 0, RightLabelTextBlockWidth);
                }

                else
                {
                    LeftLabelTextBlock.RenderTransform = new RotateTransform(-AngleInDegrees);
                    RightLabelTextBlock.RenderTransform = new RotateTransform(-AngleInDegrees);
                    RightLabelTextBlock.Margin = new(RightLabelTextBlockHeight * 0.75, RightLabelTextBlockWidth * 0.75, 0, 0);
                }

                LeftLabelTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
                LeftLabelTextBlock.VerticalAlignment = VerticalAlignment.Center;
                RightLabelTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
                RightLabelTextBlock.VerticalAlignment = VerticalAlignment.Center;
            }
        }

        internal class SeparateLabelWithButtons : SeparateLabel
        {
            private readonly StackPanel LabelWithButtonsStackPanel = new()
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Bottom
            };

            // Объявите делегат
            public delegate void ClickHandler(object sender, RoutedEventArgs e);

            // Создайте событие с этим делегатом
            public event ClickHandler? AddButtonClick;
            public event ClickHandler? DeleteButtonClick;

            private int _NumberOfButtons = 1;

            public int NumberOfButtons
            {
                get
                {
                    return _NumberOfButtons;
                }

                set
                {
                    if (value >= 2)
                    {
                        _NumberOfButtons = 2;
                    }
                }
            }

            // Конструктор с параметрами цветов, текстом для каждой из пользовательских меток и количеством кнопок
            public SeparateLabelWithButtons(bool? DiagonalFromTopLeftToBottomRight = true, Brush? LeftTriangleBrush = null, Brush? RightTriangleBrush = null, Brush? LeftLabelTextBrush = null, Brush? RightLabelTextBrush = null, string LeftLabelText = "", string RightLabelText = "", FontFamily? LeftLabelFontFamily = null, int LeftLabelFontSize = 0, FontFamily? RightLabelFontFamily = null, int RightLabelFontSize = 0, int NumberOfButtons = 1) : base(DiagonalFromTopLeftToBottomRight, LeftTriangleBrush, RightTriangleBrush, LeftLabelTextBrush, RightLabelTextBrush, LeftLabelText, RightLabelText, LeftLabelFontFamily, LeftLabelFontSize, RightLabelFontFamily, RightLabelFontSize)
            {
                Loaded += (sender, e) =>
                {
                    Children.Add(LabelWithButtonsStackPanel);

                    this.NumberOfButtons = NumberOfButtons;

                    CreateButton(1);

                    if (this.NumberOfButtons == 2)
                    {
                        CreateButton(2);
                    }
                };
            }

            private void CreateButton(int TypeOfButton)
            {
                switch (TypeOfButton)
                {
                    case 1:

                        // Кнопка "добавить"
                        Button AddButton = new()
                        {
                            Background = Brushes.YellowGreen,
                            Width = 15,
                            Height = 15,
                            Content = new TextBlock()
                            {
                                Text = "+",
                                HorizontalAlignment = HorizontalAlignment.Center,
                                VerticalAlignment = VerticalAlignment.Center
                            },
                            Margin = new(0, 0, 3, 0),
                            Cursor = Cursors.Hand
                        };

                        AddButton.Click += (sender, e) =>
                        {
                            AddButtonClick?.Invoke(sender, e);
                        };

                        LabelWithButtonsStackPanel.Children.Add(AddButton);

                        break;

                    case 2:

                        // Кнопка "удалить"
                        Button DeleteButton = new()
                        {
                            Background = Brushes.Salmon,
                            Width = 15,
                            Height = 15,
                            Content = new TextBlock()
                            {
                                Text = "-",
                                HorizontalAlignment = HorizontalAlignment.Center,
                                VerticalAlignment = VerticalAlignment.Center
                            },
                            Cursor = Cursors.Hand
                        };

                        DeleteButton.Click += (sender, e) =>
                        {
                            DeleteButtonClick?.Invoke(sender, e);
                        };

                        LabelWithButtonsStackPanel.Children.Add(DeleteButton);

                        break;
                }
            }
        }
    }
}