﻿using System.Windows.Controls;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Windows.Media;

using Digital_Schedule_Editor.Interfaces;
using Digital_Schedule_Editor.Classes.SerializingClasses;
using Digital_Schedule_Editor.Modules.Windows.College;
using Digital_Schedule_Editor.Extensions.CustomComponents;
using Digital_Schedule_Editor.Modules.Windows.Common;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    /// <summary>
    /// Класс пользовательского <see cref="ComboBox"/> с управляемым <see cref="ObservableCollection{T}"/>, где <typeparamref name="T"/> — <see cref="string"/>
    /// </summary>
    public partial class CollectionComboBox : UserControl, IEditMainDataWindowControl
    {
        public MainDataClass? MainData => EditGroupScheduleWindow.LoadData<MainDataClass>();
        public ObservableCollection<string>? EntityList { get; set; }
        public int OriginalEntityListItemsCount { get; set; }

        private string? _EntitiesLabelText;
        public string? EntitiesLabelText { get => _EntitiesLabelText; set => _EntitiesLabelText = EntitiesLabelTextBlock.Text = value; }

        private string? _PlaceholderText;
        public string? PlaceholderText { get => _PlaceholderText; set => _PlaceholderText = EntitiesComboBox.PlaceholderText = value; }

        public CollectionComboBox()
        {
            InitializeComponent();

            Loaded += (sender, e) =>
            {
                EntityList ??= new();
                OriginalEntityListItemsCount = EntityList.Count;

                EntityList.CollectionChanged += OnCollectionChanged;

                EntitiesComboBox.ItemsSource = EntityList;
                EntitiesLabelTextBlock.Text = $"{EntitiesLabelText?.Remove(EntitiesLabelText.Length - 8)} ({EntityList.Count} шт.)";

                EditMainDataWindow.OnDataChanged += () =>
                {
                    OriginalEntityListItemsCount = EntityList.Count;
                    EntitiesLabelTextBlock.Text = $"{EntitiesLabelText?.Remove(EntitiesLabelText.Length - 8)} ({EntityList.Count} шт.)";
                };

                DeleteEntityButton.Click += (sender, e) =>
                {
                    EntityList.Remove(EntitiesComboBox.Text);
                    EntitiesComboBox.Text = string.Empty;
                    EntitiesComboBox.Focus();
                };

                AddEntityButton.Click += (sender, e) =>
                {
                    EntityList.Add(EntitiesComboBox.Text);
                    ObservableCollection<string> SortedEntityList = new(EntityList);
                    SortedEntityList.SortCollection();
                    EntitiesComboBox.ItemsSource = EntityList = SortedEntityList;
                    EntityList.CollectionChanged += OnCollectionChanged;
                    EntitiesComboBox.Text = string.Empty;
                    EntitiesComboBox.Focus();
                };

                EntitiesComboBox.Loaded += (sender, e) =>
                {
                    if (EntitiesComboBox.Template.FindName("PART_EditableTextBox", EntitiesComboBox) is TextBox EntitiesComboBoxEditableTextBox)
                    {
                        EntitiesComboBoxEditableTextBox.TextChanged += (sender, e) =>
                        {
                            if (!string.IsNullOrWhiteSpace(EntitiesComboBox.Text))
                            {
                                if (((SolidColorBrush)EntitiesComboBox.Foreground).Color == Brushes.Black.Color)
                                {
                                    if (!EntityList.Contains(EntitiesComboBox.Text))
                                    {
                                        AddEntityButton.IsEnabled = true;
                                        DeleteEntityButton.IsEnabled = false;
                                    }

                                    else if (EntityList.Contains(EntitiesComboBox.Text))
                                    {
                                        AddEntityButton.IsEnabled = false;
                                        DeleteEntityButton.IsEnabled = true;
                                    }
                                }
                            }

                            else
                            {
                                AddEntityButton.IsEnabled = false;
                                DeleteEntityButton.IsEnabled = false;
                            }
                        };
                    }
                };
            };
        }

        private void OnCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            EntitiesLabelTextBlock.Text = $"{EntitiesLabelText?.Remove(EntitiesLabelText.Length - 8)} ({EntityList?.Count} шт.) {Environment.NewLine} [было {OriginalEntityListItemsCount} шт.]";

            EditMainDataWindow.TotalElementsCountChanged?.Invoke();
        }
    }
}