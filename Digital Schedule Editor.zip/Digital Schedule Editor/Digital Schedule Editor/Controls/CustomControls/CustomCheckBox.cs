﻿// V. 1.5.

using System.Windows.Controls;
using System.Windows.Input;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    internal class CustomCheckBox : CheckBox
    {
        public CustomCheckBox()
        {
            KeyDown += (sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    if (sender is CheckBox CheckBox)
                    {
                        OnToggle();

                        e.Handled = true;
                    }
                }
            };
        }

        protected override void OnToggle()
        {
            IsChecked = IsChecked switch
            {
                null => true,
                true => false,
                false => true
            };
        }
    }
}