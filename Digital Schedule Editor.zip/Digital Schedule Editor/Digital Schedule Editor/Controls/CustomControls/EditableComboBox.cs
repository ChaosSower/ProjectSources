﻿// На удаление!

using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Digital_Schedule_Editor.Controls.CustomControls
{
    internal class EditableComboBox : UserControl
    {
        //private readonly Panel Panel = new();

        private readonly ComboBox ComboBox = new()
        {
            Cursor = Cursors.Hand,
            //Sorted = true
        };

        //private readonly SplitContainer SplitContainer = new()
        //{
        //    IsSplitterFixed = true,
        //    SplitterDistance = 83,
        //    SplitterWidth = 1,
        //    TabStop = false
        //};

        private readonly Button DeleteButton = new()
        {
            Background = Brushes.Salmon,
            Cursor = Cursors.Hand,
            Content = "Удалить"
        };

        private readonly Button AddButton = new()
        {
            Background = Brushes.YellowGreen,
            Cursor = Cursors.Hand,
            Content = "Добавить"
        };

        public readonly List<string> ComboBoxItems = new();

        public EditableComboBox()
        {
            //// Размещаем кнопки в SplitContainer
            //SplitContainer.Panel1.Controls.Add(DeleteButton);
            //AddButton.Dock = DockStyle.Fill;

            //SplitContainer.Panel2.Controls.Add(AddButton);
            //DeleteButton.Dock = DockStyle.Bottom;

            //// Размещаем SplitContainer и ComboBox в Panel
            ////Panel.Controls.Add(ComboBox);
            //ComboBox.Dock = DockStyle.Top;

            //Panel.Controls.Add(SplitContainer);
            //SplitContainer.Dock = DockStyle.Bottom;
            //SplitContainer.BorderStyle = BorderStyle.FixedSingle;

            // Устанавливаем свойство Dock для Panel
            //Panel.Dock = DockStyle.Fill;

            // Добавляем Panel на UserControl

            // Подписываемся на события Click кнопок
            AddButton.Click += AddButton_Click;
            DeleteButton.Click += DeleteButton_Click;

            //Controls.Add(Panel);
            //Panel.Dock = DockStyle.Fill;
            //this.Dock = DockStyle.Fill;
        }


        private void AddButton_Click(object? sender, EventArgs e)
        {
            // Проверяем, что введено хоть что-то
            if (string.IsNullOrEmpty(ComboBox.Text))
            {
                return;
            }

            // Проверяем, есть ли такой элемент в списке
            if (ComboBoxItems.Contains(ComboBox.Text))
            {
                return;
            }

            // Модифицируем список
            ComboBoxItems.Add(ComboBox.Text);

            // Модифицируем ComboBox
            ComboBox.Items.Add(ComboBox.Text);

            ComboBox.Text = string.Empty;
        }

        private void DeleteButton_Click(object? sender, EventArgs e)
        {
            // Проверяем, что введено хоть что-то
            if (string.IsNullOrEmpty(ComboBox.Text))
            {
                return;
            }

            // Проверяем, есть ли такой элемент в списке
            if (!ComboBoxItems.Contains(ComboBox.Text))
            {
                return;
            }

            // Модифицируем список
            ComboBoxItems.Remove(ComboBox.Text);

            // Модифицируем ComboBox
            ComboBox.Items.Remove(ComboBox.Text);

            ComboBox.Text = string.Empty;
        }
    }
}