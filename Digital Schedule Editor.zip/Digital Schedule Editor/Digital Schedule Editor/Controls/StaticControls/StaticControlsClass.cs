﻿using System.Windows.Controls;
using System.Windows.Media;

using static Digital_Schedule_Editor.Controls.CustomControls.SeparateLabelClass;

namespace Digital_Schedule_Editor.Controls.StaticControls
{
    // TODO: добавить xml-комментарий - этот класс выступает альтернативой инициализации поля в вызываемом классе
    // то есть буквально экономится 20 строк кода))) (с другой стороны, можно легко управлять элементами (простота контроля), без поиска в коде на 1000 строк)
    // Важно: при запуске приложения инициализируются ВСЕ статические элементы - даже те, которые не используются
    internal static class StaticControlsClass
    {
        public static readonly Grid GroupsScheduleTableLayoutGrid = new()
        {
            ColumnDefinitions =
            {
                new()
            },
            RowDefinitions =
            {
                new()
            },
            //Padding = new(10, 10, 0, 0),
            //Margin = new(10, 10, 0, 0)
        };

        public static ScrollViewer GroupsScheduleTableLayoutScrollViewer = new()
        {
            Content = GroupsScheduleTableLayoutGrid,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Margin = new(0, 0, 5, 0)
        };

        public static readonly SeparateLabelWithAngledText MainWindowSeparateLabel = new()
        {
            //DiagonalFromTopLeftToBottomRight = true,
            LeftLabelFontSize = 9,
            RightLabelFontSize = 11,
            RightTriangleBrush = Brushes.LightGray,
            RightLabelTextBrush = Brushes.Black,
            LeftLabelText = "День недели",
            RightLabelText = "Группа",
            LeftLabelFontFamily = new("Segoe UI"),
            RightLabelFontFamily = new("Segoe UI"),
            //BorderStyle = BorderStyle.None,
            //BorderBrush = null,
            Margin = new(1)
        };
    }
}