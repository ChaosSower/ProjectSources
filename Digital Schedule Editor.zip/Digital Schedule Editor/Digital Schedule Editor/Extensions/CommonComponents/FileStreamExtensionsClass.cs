﻿using System.IO;

using static Digital_Schedule_Editor.Classes.AbstractClasses.XMLSerializingDataClass;

namespace Digital_Schedule_Editor.Extensions.CommonComponents
{
    internal static class FileStreamExtensionsClass
    {
        public static void KeepFileStream(this FileStream FileStream, string FileName, bool LockStream = true)
        {
            try
            {
                if (LockStream)
                {
                    OpenedFileStreams.Add((FileName, FileStream));
                }

                else
                {
                    OpenedFileStreams.Find(x => x.Item2 == FileStream).Item2.Close();
                    OpenedFileStreams.RemoveAll(x => x.Item1 == FileName);
                }
            }

            catch (NullReferenceException)
            {
                // TODO: создать логирование ошибки
            }
        }

        public static FileStream CheckFileStreamInOpenedFileStreamsList(this FileStream? FileStream, string FileName)
        {
            (string, FileStream) OpenedFileStream = OpenedFileStreams.Find(x => x.Item1 == FileName);

            if (OpenedFileStream != default) // использование найденного FileStream
            {
                FileStream = OpenedFileStream.Item2;
                FileStream.Seek(0, SeekOrigin.Begin); // сброс позиции чтения в начало
            }

            else
            {
                FileStream = new(FileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                FileStream.KeepFileStream(FileName);
            }

            return FileStream;
        }
    }
}