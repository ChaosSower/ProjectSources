﻿using System.Windows;
using System.Windows.Media;

namespace Digital_Schedule_Editor.Extensions.CommonComponents
{
    internal static class ControlExtensionsClass
    {
        // Расширение выполнения принимаемого метода для контрола и его дочерних элементов
        public static void ProcessAllChildVisualControls(this Visual VisualControl, Action<Visual> Method)
        {
            Queue<Visual> Queue = new();

            Queue.Enqueue(VisualControl);

            while (Queue.Count > 0)
            {
                Visual VisualParentControl = Queue.Dequeue();

                Method(VisualParentControl);

                int ChildrenCount = VisualTreeHelper.GetChildrenCount(VisualParentControl);

                for (int i = 0; i < ChildrenCount; i++)
                {
                    if (VisualTreeHelper.GetChild(VisualParentControl, i) is Visual VisualChild)
                    {
                        Queue.Enqueue(VisualChild);
                    }
                }
            }
        }

        // Расширение выполнения принимаемого метода для контрола и его дочерних элементов (без учёта их визуальных эффектов и элементов)
        public static void ProcessAllChildLogicalControls(this DependencyObject LogicalControl, Action<DependencyObject> Method)
        {
            Queue<DependencyObject> Queue = new();

            Queue.Enqueue(LogicalControl);

            while (Queue.Count > 0)
            {
                DependencyObject LogicalParentControl = Queue.Dequeue();

                Method(LogicalParentControl);

                foreach (DependencyObject LogicalChild in LogicalTreeHelper.GetChildren(LogicalParentControl))
                {
                    Queue.Enqueue(LogicalChild);
                }
            }
        }
    }
}