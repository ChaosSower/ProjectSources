﻿using Digital_Schedule_Editor.Methods;
using Digital_Schedule_Editor.Interfaces;

namespace Digital_Schedule_Editor.Extensions.CustomComponents
{
    internal static class CustomCollectionExtensionsClass
    {
        // Расширение сортировки строкового списка элемента, содержащего слова и числа
        public static void SortCollection<T>(this IList<T> Collection, bool IsOrderAscending = true) where T : class
        {
            List<string> List = new();

            for (int i = 0; i < Collection.Count; i++)
            {
                List.Add(Collection[i]?.ToString() ?? string.Empty);
            }

            List.Sort((FirstElement, SecondElement) =>
            {
                bool FirstElementIsInt = CommonMethodsClass.IsNumeric(FirstElement);
                bool SecondElementIsInt = CommonMethodsClass.IsNumeric(SecondElement);

                if (FirstElementIsInt && SecondElementIsInt) // если обе строки числа - сравнение в качестве чисел
                {
                    if (IsOrderAscending)
                    {
                        return int.Parse(FirstElement).CompareTo(int.Parse(SecondElement));
                    }

                    else
                    {
                        return int.Parse(SecondElement).CompareTo(int.Parse(FirstElement));
                    }
                }

                else if (FirstElementIsInt) // если только x - число, x идёт первым при возрастающей сортировке
                {
                    if (IsOrderAscending)
                    {
                        return -1;
                    }

                    else
                    {
                        return 1;
                    }
                }

                else if (SecondElementIsInt) // если только y - число, y идёт первым при возрастающей сортировке
                {
                    if (IsOrderAscending)
                    {
                        return 1;
                    }

                    else
                    {
                        return -1;
                    }
                }

                else // если оба элемента строки - сравнение в качестве строк
                {
                    if (IsOrderAscending)
                    {
                        return FirstElement.CompareTo(SecondElement);
                    }

                    else
                    {
                        return SecondElement.CompareTo(FirstElement);
                    }
                }
            });

            Collection.Clear();

            foreach (string String in List)
            {
                if (String is T Generic)
                {
                    Collection.Add(Generic);
                }
            }
        }
    }
}