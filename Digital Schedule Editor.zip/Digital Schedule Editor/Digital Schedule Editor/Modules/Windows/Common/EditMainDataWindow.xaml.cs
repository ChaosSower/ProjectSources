﻿// https://www.youtube.com/watch?v=iZyfcb2eAhQ
// https://learn.microsoft.com/en-us/answers/questions/840981/auto-complete-for-textbox-in-wpf-(mvvm)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using Digital_Schedule_Editor.Classes;
using Digital_Schedule_Editor.Classes.SerializingClasses;
using Digital_Schedule_Editor.Controls.CustomControls;
using Digital_Schedule_Editor.Extensions.CommonComponents;
using Digital_Schedule_Editor.Methods;
using Digital_Schedule_Editor.Modules.Windows.College;

namespace Digital_Schedule_Editor.Modules.Windows.Common
{
    /// <summary>
    /// Логика окна редактирования основных данных EditMainDataWindow.xaml
    /// </summary>
    public partial class EditMainDataWindow : Window
    {
        /// <summary>
        /// Поле хранимых данных программы
        /// </summary>
        private MainDataClass MainData;

        public static Action? TotalElementsCountChanged;

        private List<string> SubjectList = new();
        private List<string> TeacherList = new();
        private List<string> GroupList = new();
        private List<string> ClassroomList = new();

        private List<(string, string)> SubjectAndTeacherList = new();
        private List<(string, string)> SubjectAndClassroomList = new();
        private List<(string, string)> TeacherAndClassroomList = new();
        private List<(string, string)> NumberOfLessonAndTimeList = new();

        /// <summary>
        /// Словарь элементов и их изначальных текстов
        /// </summary>
        private readonly Dictionary<Control, string> ControlAndItsOriginalTextDictionary;

        /// <summary>
        /// Словарь кнопок и связанных с ними элементов
        /// </summary>
        private readonly Dictionary<Button, (List<ComboBox> ComboBoxes, List<Label> Labels)> ButtonAndItsControlsDictionary;

        /// <summary>
        /// Словарь кнопок и их делегатов
        /// </summary>
        private readonly Dictionary<Button, (BoolDelegateWithoutParameters BoolDelegateWithoutParameters, bool BoolDelegateWithoutParametersArgument)> ButtonNameAndItsDelegateDictionary;

        // Поля классов кнопок //

        //private readonly SubjectsComboBoxWithButtons SubjectButton;
        //private readonly TeachersComboBoxWithButtons TeacherButton;
        //private readonly GroupsComboBoxWithButtons GroupButton;
        //private readonly ClassroomsComboBoxWithButtons ClassroomButton;
        private readonly SubjectsAndTeachersComboBoxesWithButtons SubjectsAndTeachersButton;
        private readonly SubjectsAndClassroomsComboBoxesWithButtons SubjectsAndClassroomsButton;
        private readonly TeachersAndClassroomsComboBoxesWithButtons TeachersAndClassroomsButton;
        private readonly NumbersOfLessonAndTimeComboBoxesWithButtons NumbersOfLessonAndTimeButton;

        // TODO: продумать возможность введения параметра в виде метода (использовать не конкретику, а base?)
        /// <summary>
        /// Bool-делегат без изначальных параметров
        /// </summary>
        /// <returns>Состояние выполненности метода (true / false)</returns>
        private delegate bool BoolDelegateWithoutParameters();

        /// <summary>
        /// Поле, показывающее, были ли произведены изменения пользователем на форме
        /// </summary>
        private bool ChangesHaveBeenMade;

        /// <summary>
        /// Логика окна редактирования основных данных EditMainDataWindow.cs
        /// </summary>
        public EditMainDataWindow()
        {
            InitializeComponent();

            Loaded += (sender, e) =>
            {
                NumbersOfLessonComboBox.IsEnabled = false;
                TimeIntervalsOfLessonComboBox.IsEnabled = false;
                LessonAndTimeLinksComboBox.IsEnabled = false;
                LessonAndTimeIntervalUnbindingButton.IsEnabled = false;
                LessonAndTimeIntervalBindingButton.IsEnabled = false;
                SaveChangesButton.IsEnabled = false;
                SaveChangesButton.Foreground = Brushes.Gray;
            };

            MainData = EditGroupScheduleWindow.LoadData<MainDataClass>(); // переменная загруженных данных проекта

            SubjectsControl.EntityList = new(MainData.SubjectList);
            TeachersControl.EntityList = new(MainData.TeacherList);
            GroupsControl.EntityList = new(MainData.GroupList);
            ClassroomsControl.EntityList = new(MainData.ClassroomList);

            //EditMainDataWindowFlowLayoutPanel.ProcessAllControls(Control =>
            //{
            //    if (Control is ComboBox ComboBox)
            //    {
            //        //ComboBox.Sorted = true;
            //        ComboBox.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            //    }
            //});

            // TODO: определиться, нужна ли проверка на отсортированность списка
            // в уже существующем XML-файле (ведь при создании с нуля список всегда отсортирован)
            // Ответ: да, нужна! Создай тогда метод, работающий в LoadData()

            LoadData();

            //SubjectsLabel.Content = $"Дисциплины ({SubjectList.Count})";
            //TeachersLabel.Content = $"Преподаватели ({TeacherList.Count})";
            //GroupsLabel.Content = $"Группы ({GroupList.Count})";
            //ClassroomsLabel.Content = $"Аудитории ({ClassroomList.Count})";
            MainDataLabelTextBlock.Text = $"Основные данные (общее кол-во данных: {SubjectsControl.EntityList.Count + TeachersControl.EntityList.Count + GroupsControl.EntityList.Count + ClassroomsControl.EntityList.Count} шт.)";

            TotalElementsCountChanged += () =>
            {
                MainDataLabelTextBlock.Text = $"Основные данные (общее кол-во данных: {SubjectsControl.EntityList.Count + TeachersControl.EntityList.Count + GroupsControl.EntityList.Count + ClassroomsControl.EntityList.Count} шт.) {Environment.NewLine} [было {new List<int> { MainData.SubjectList.Count, MainData.TeacherList.Count, MainData.GroupList.Count, MainData.ClassroomList.Count }.Sum()} шт.]";
                SaveChangesButton.Foreground = Brushes.Black;
                SaveChangesButton.IsEnabled = true;
            };

            NumbersOfLessonComboBox.Items.Add(ConstantsClass.NumbersOfLessonArray);
            TimeIntervalsOfLessonComboBox.Items.Add(ConstantsClass.StandardTimeSlotsArray);

            //SubjectButton = new(SubjectsComboBox, SubjectList);
            //TeacherButton = new(TeachersComboBox, TeacherList);
            //GroupButton = new(GroupsComboBox, GroupList);
            //ClassroomButton = new(ClassroomsComboBox, ClassroomList);

            SubjectsAndTeachersButton = new(SubjectsOfTeacherComboBox, SubjectList, TeachersOfSubjectComboBox, TeacherList, SubjectAndTeacherLinksComboBox, SubjectAndTeacherList);
            SubjectsAndClassroomsButton = new(SubjectsOfClassroomComboBox, SubjectList, ClassroomsOfSubjectComboBox, ClassroomList, SubjectAndClassroomLinksComboBox, SubjectAndClassroomList);
            TeachersAndClassroomsButton = new(TeachersOfClassroomComboBox, TeacherList, ClassroomsOfTeacherComboBox, ClassroomList, TeacherAndClassroomLinksComboBox, TeacherAndClassroomList);
            NumbersOfLessonAndTimeButton = new(NumbersOfLessonComboBox, ConstantsClass.NumbersOfLessonArray.ToList(), TimeIntervalsOfLessonComboBox, ConstantsClass.StandardTimeSlotsArray.ToList(), LessonAndTimeLinksComboBox, NumberOfLessonAndTimeList);

            SubjectAndTeacherLinkLabelTextBlock.Text = $"Привязка дисциплины к преподавателю (связей: {SubjectAndTeacherList.Count} шт.)";
            SubjectAndClassroomLinkLabelTextBlock.Text = $"Привязка дисциплины к аудитории (связей: {SubjectAndClassroomList.Count} шт.)";
            TeacherAndClassroomLinkLabelTextBlock.Text = $"Привязка преподавателя к аудитории (связей: {TeacherAndClassroomList.Count} шт.)";
            LessonAndTimeLinkLabelTextBlock.Text = $"Привязка пары ко времени (связей: {NumberOfLessonAndTimeList.Count} шт.)";

            ControlAndItsOriginalTextDictionary = new()
            {
                //{ SubjectsLabel, "Дисциплины" },
                //{ TeachersLabel, "Преподаватели" },
                //{ GroupsLabel, "Группы" },
                //{ ClassroomsLabel, "Аудитории" },
                { SubjectAndTeacherLinkLabel, "Привязка дисциплины к преподавателю" },
                { SubjectOfTeacherLabel, "Дисциплина" },
                { TeacherOfSubjectLabel, "Преподаватель" },
                { SubjectAndTeacherLinksLabel, "Связи" },
                { SubjectAndClassroomLinkLabel, "Привязка дисциплины к аудитории" },
                { SubjectOfClassroomLabel, "Дисциплина" },
                { ClassroomOfSubjectLabel, "Аудитория" },
                { SubjectAndClassroomLinksLabel, "Связи" },
                { TeacherAndClassroomLinkLabel, "Привязка преподавателя к аудитории" },
                { TeacherOfClassroomLabel, "Преподаватель" },
                { ClassroomOfTeacherLabel, "Аудитория" },
                { TeacherAndClassroomLinksLabel, "Связи" },
                { LessonAndTimeLinkLabel, "Привязка пары ко времени" },
                { NumberOfLessonLabel, "Номер пары" },
                { TimeIntervalOfLessonLabel, "Время" },
                { LessonAndTimeLinksLabel, "Связи" },
                //{ SubjectsComboBox, "Код дисциплины (оптимально) Название дисциплины" },
                //{ TeachersComboBox, "Иванов И. И." },
                //{ GroupsComboBox, "ИСП 001" },
                //{ ClassroomsComboBox, "001" },
                { SubjectsOfTeacherComboBox, "Код дисциплины (оптимально) Название дисциплины" },
                { TeachersOfSubjectComboBox, "Иванов И. И." },
                { SubjectAndTeacherLinksComboBox, "Код дисциплины (оптимально) Название дисциплины — Иванов И. И." },
                { SubjectsOfClassroomComboBox, "Код дисциплины (оптимально) Название дисциплины" },
                { ClassroomsOfSubjectComboBox, "001" },
                { SubjectAndClassroomLinksComboBox, "Код дисциплины (оптимально) Название дисциплины — 001" },
                { TeachersOfClassroomComboBox, "Иванов И. И." },
                { ClassroomsOfTeacherComboBox, "001" },
                { TeacherAndClassroomLinksComboBox, "Иванов И. И. — 001" },
                { NumbersOfLessonComboBox, "1" },
                { TimeIntervalsOfLessonComboBox, "09:00 - 10:30" },
                { LessonAndTimeLinksComboBox, "1 — 09:00 - 10:30" }
            };

            ButtonAndItsControlsDictionary = new()
            {
                //{
                //    AddSubjectButton, (new() { SubjectsComboBox, SubjectsOfTeacherComboBox, SubjectsOfClassroomComboBox }, new() { SubjectsLabel, SubjectOfTeacherLabel, SubjectOfClassroomLabel })
                //},
                //{
                //    DeleteSubjectButton, (new() { SubjectsComboBox, SubjectsOfTeacherComboBox, SubjectsOfClassroomComboBox }, new() { SubjectsLabel, SubjectOfTeacherLabel, SubjectOfClassroomLabel })
                //},
                //{
                //    AddTeacherButton, (new() { TeachersComboBox, TeachersOfSubjectComboBox, TeachersOfClassroomComboBox }, new() { TeachersLabel, TeacherOfSubjectLabel, TeacherOfClassroomLabel })
                //},
                //{
                //    DeleteTeacherButton, (new() { TeachersComboBox, TeachersOfSubjectComboBox, TeachersOfClassroomComboBox }, new() { TeachersLabel, TeacherOfSubjectLabel, TeacherOfClassroomLabel })
                //},
                //{
                //    AddGroupButton, (new() { GroupsComboBox }, new() { GroupsLabel })
                //},
                //{
                //    DeleteGroupButton, (new() { GroupsComboBox }, new() { GroupsLabel })
                //},
                //{
                //    AddClassroomButton, (new() { ClassroomsComboBox, ClassroomsOfSubjectComboBox, ClassroomsOfTeacherComboBox }, new() { ClassroomsLabel, ClassroomOfSubjectLabel, ClassroomOfTeacherLabel })
                //},
                //{
                //    DeleteClassroomButton, (new() { ClassroomsComboBox, ClassroomsOfSubjectComboBox, ClassroomsOfTeacherComboBox }, new() { ClassroomsLabel, ClassroomOfSubjectLabel, ClassroomOfTeacherLabel })
                //},
                {
                    SubjectAndTeacherBindingButton, (new() { SubjectsOfTeacherComboBox, TeachersOfSubjectComboBox, SubjectAndTeacherLinksComboBox }, new() { SubjectAndTeacherLinkLabel, SubjectOfTeacherLabel, TeacherOfSubjectLabel, SubjectAndTeacherLinksLabel })
                },
                {
                    SubjectAndTeacherUnbindingButton, (new() { SubjectsOfTeacherComboBox, TeachersOfSubjectComboBox, SubjectAndTeacherLinksComboBox }, new() { SubjectAndTeacherLinkLabel, SubjectOfTeacherLabel, TeacherOfSubjectLabel, SubjectAndTeacherLinksLabel })
                },
                {
                    SubjectAndClassroomBindingButton, (new() { SubjectsOfClassroomComboBox, ClassroomsOfSubjectComboBox, SubjectAndClassroomLinksComboBox }, new() { SubjectAndClassroomLinkLabel, SubjectOfClassroomLabel, ClassroomOfSubjectLabel, SubjectAndClassroomLinksLabel })
                },
                {
                    SubjectAndClassroomUnbindingButton, (new() { SubjectsOfClassroomComboBox, ClassroomsOfSubjectComboBox, SubjectAndClassroomLinksComboBox }, new() { SubjectAndClassroomLinkLabel, SubjectOfClassroomLabel, ClassroomOfSubjectLabel, SubjectAndClassroomLinksLabel })
                },
                {
                    TeacherAndClassroomBindingButton, (new() { TeachersOfClassroomComboBox, ClassroomsOfTeacherComboBox, TeacherAndClassroomLinksComboBox }, new() { TeacherAndClassroomLinkLabel, TeacherOfClassroomLabel, ClassroomOfTeacherLabel, TeacherAndClassroomLinksLabel })
                },
                {
                    TeacherAndClassroomUnbindingButton, (new() { TeachersOfClassroomComboBox, ClassroomsOfTeacherComboBox, TeacherAndClassroomLinksComboBox }, new() { TeacherAndClassroomLinkLabel, TeacherOfClassroomLabel, ClassroomOfTeacherLabel, TeacherAndClassroomLinksLabel })
                },
                {
                    LessonAndTimeIntervalBindingButton, (new() { NumbersOfLessonComboBox, TimeIntervalsOfLessonComboBox, LessonAndTimeLinksComboBox }, new() { LessonAndTimeLinkLabel, NumberOfLessonLabel, TimeIntervalOfLessonLabel, LessonAndTimeLinksLabel })
                },
                {
                    LessonAndTimeIntervalUnbindingButton, (new() { NumbersOfLessonComboBox, TimeIntervalsOfLessonComboBox, LessonAndTimeLinksComboBox }, new() { LessonAndTimeLinkLabel, NumberOfLessonLabel, TimeIntervalOfLessonLabel, LessonAndTimeLinksLabel })
                }
            };

            ButtonNameAndItsDelegateDictionary = new()
            {
                //{
                //    AddSubjectButton,
                //    (new(() => SubjectButton.ButtonClickDelegateVariable.Invoke(true)), true)
                //},
                //{
                //    DeleteSubjectButton,
                //    (new(() => SubjectButton.ButtonClickDelegateVariable.Invoke(false)), false)
                //},
                //{
                //    AddTeacherButton,
                //    (new(() => TeacherButton.ButtonClickDelegateVariable.Invoke(true)), true)
                //},
                //{
                //    DeleteTeacherButton,
                //    (new(() => TeacherButton.ButtonClickDelegateVariable.Invoke(false)), false)
                //},
                //{
                //    AddGroupButton,
                //    (new(() => GroupButton.ButtonClickDelegateVariable.Invoke(true)), true)
                //},
                //{
                //    DeleteGroupButton,
                //    (new(() => GroupButton.ButtonClickDelegateVariable.Invoke(false)), false)
                //},
                //{
                //    AddClassroomButton,
                //    (new(() => ClassroomButton.ButtonClickDelegateVariable.Invoke(true)), true)
                //},
                //{
                //    DeleteClassroomButton,
                //    (new(() => ClassroomButton.ButtonClickDelegateVariable.Invoke(false)), false)
                //},
                {
                    SubjectAndTeacherBindingButton,
                    (new(() => SubjectsAndTeachersButton.ButtonClickDelegateVariable.Invoke(true)), true)
                },
                {
                    SubjectAndTeacherUnbindingButton,
                    (new(() => SubjectsAndTeachersButton.ButtonClickDelegateVariable.Invoke(false)), false)
                },
                {
                    SubjectAndClassroomBindingButton,
                    (new(() => SubjectsAndClassroomsButton.ButtonClickDelegateVariable.Invoke(true)), true)
                },
                {
                    SubjectAndClassroomUnbindingButton,
                    (new(() => SubjectsAndClassroomsButton.ButtonClickDelegateVariable.Invoke(false)), false)
                },
                {
                    TeacherAndClassroomBindingButton,
                    (new(() => TeachersAndClassroomsButton.ButtonClickDelegateVariable.Invoke(true)), true)
                },
                {
                    TeacherAndClassroomUnbindingButton,
                    (new(() => TeachersAndClassroomsButton.ButtonClickDelegateVariable.Invoke(false)), false)
                },
                {
                    LessonAndTimeIntervalBindingButton,
                    (new(() => NumbersOfLessonAndTimeButton.ButtonClickDelegateVariable.Invoke(true, true)), true)
                },
                {
                    LessonAndTimeIntervalUnbindingButton,
                    (new(() => NumbersOfLessonAndTimeButton.ButtonClickDelegateVariable.Invoke(false, true)), false)
                }
            };

            EditMainDataWindowTableLayoutGrid.ProcessAllChildVisualControls(Control =>
            {
                if (Control is Button Button)
                {
                    Button.Cursor = Cursors.Hand;

                    Button.Click += (sender, e) =>
                    {
                        if (Button == SaveChangesButton)
                        {
                            return;
                        }

                        (BoolDelegateWithoutParameters BoolDelegateWithoutParameters, bool BoolDelegateWithoutParametersArgument) = ButtonNameAndItsDelegateDictionary[Button];
                        (List<ComboBox> ComboBoxes, List<Label> Labels) = ButtonAndItsControlsDictionary[Button];

                        //string FirstComboBoxText = string.Empty;
                        //string SecondComboBoxText = string.Empty;

                        //if (/*ComboBoxes[0] == SubjectsComboBox ||*//* ComboBoxes[0] == TeachersComboBox ||*//* ComboBoxes[0] == GroupsComboBox ||*/ ComboBoxes[0] == ClassroomsComboBox)
                        //{
                        //    if (ControlAndItsOriginalTextDictionary.Any(KeyValuePair => KeyValuePair.Value == ComboBoxes[0].Text) && ComboBoxes[0].Foreground == Brushes.Gray)
                        //    {
                        //        return;
                        //    }
                        //}

                        //else
                        //{
                        //    if (ControlAndItsOriginalTextDictionary.Any(KeyValuePair => KeyValuePair.Value == ComboBoxes[0].Text) && ComboBoxes[0].Foreground == Brushes.Gray || ControlAndItsOriginalTextDictionary.Any(KeyValuePair => KeyValuePair.Value == ComboBoxes[1].Text) && ComboBoxes[1].Foreground == Brushes.Gray)
                        //    {
                        //        if (ControlAndItsOriginalTextDictionary.Any(KeyValuePair => KeyValuePair.Value == ComboBoxes[2].Text) && ComboBoxes[2].Foreground == Brushes.Gray)
                        //        {
                        //            return;
                        //        }
                        //    }
                        //}

                        string? ThirdComboBoxText = null;

                        if (ComboBoxes.Count == 3)
                        {
                            if (ComboBoxes[0].Text != string.Empty && ComboBoxes[1].Text != string.Empty && ComboBoxes[2].Text != string.Empty && ComboBoxes[2].Text != ControlAndItsOriginalTextDictionary[ComboBoxes[2]] && Labels.Count == 4)
                            {
                                ThirdComboBoxText = ComboBoxes[2].Text;
                            }
                        }

                        bool Successes = BoolDelegateWithoutParameters.Invoke();

                        if (Successes)
                        {
                            if (ThirdComboBoxText != null)
                            {
                                ComboBoxes[2].Text = ThirdComboBoxText;
                                //Labels[3].Content = ControlAndItsOriginalTextDictionary[Labels[3]];
                                //Labels[3].Foreground = Brushes.Black;
                            }

                            string[] MainComboBoxItems;

                            //if (/*ComboBoxes[0] == SubjectsComboBox ||*//* ComboBoxes[0] == TeachersComboBox ||*//* ComboBoxes[0] == GroupsComboBox ||*/ ComboBoxes[0] == ClassroomsComboBox)
                            //{
                            //    MainComboBoxItems = ComboBoxes[0].Items.Cast<string>().ToArray();
                            //    ComboBoxes[0].Text = ControlAndItsOriginalTextDictionary[ComboBoxes[0]];
                            //    ComboBoxes[0].Foreground = Brushes.Gray;
                            //    ComboBoxes[0].Focus();

                            //    Labels[0].Content = ControlAndItsOriginalTextDictionary[Labels[0]] + $" ({MainComboBoxItems.Length})*";

                            //    foreach (ComboBox ComboBox in ComboBoxes)
                            //    {
                            //        ComboBox.Items.Clear();
                            //        MainComboBoxItems.ToList().ForEach(MainComboBoxItem => ComboBox.Items.Add(MainComboBoxItem));
                            //    }

                            //    if (ComboBoxes.Count == 3)
                            //    {
                            //        (List<ComboBox> LinkComboBoxComboBoxes, List<Label> LinkComboBoxLabels) = ButtonAndItsControlsDictionary.FirstOrDefault(KeyValuePair => KeyValuePair.Value.Labels.Count == 4 && (KeyValuePair.Value.ComboBoxes.Contains(ComboBoxes[1]) || KeyValuePair.Value.ComboBoxes.Contains(ComboBoxes[2]))).Value;
                            //        string[] ComboBoxesAndTheirText = LinkComboBoxComboBoxes[2].Text.Replace('-', '—').Split(new[] { " — " }, StringSplitOptions.None);

                            //        if (ComboBoxesAndTheirText.Length == 2)
                            //        {
                            //            string FirstComboBoxText = ComboBoxesAndTheirText[0];
                            //            string SecondComboBoxText = ComboBoxesAndTheirText[1];

                            //            if (!LinkComboBoxComboBoxes[0].Items.Contains(FirstComboBoxText) || !LinkComboBoxComboBoxes[1].Items.Contains(SecondComboBoxText))
                            //            {
                            //                LinkComboBoxLabels[3].Content = ControlAndItsOriginalTextDictionary[LinkComboBoxLabels[3]];
                            //                LinkComboBoxLabels[3].Foreground = Brushes.Black;
                            //                LinkComboBoxLabels[3].FontSize = 12;
                            //                LinkComboBoxLabels[3].BorderThickness = default;
                            //                LinkComboBoxLabels[3].BorderBrush = Brushes.Black;
                            //            }

                            //            else if (LinkComboBoxComboBoxes[2].Items.Contains(LinkComboBoxComboBoxes[2].Text.Replace('-', '—')))
                            //            {
                            //                if (LinkComboBoxLabels[3].Content.ToString() != ControlAndItsOriginalTextDictionary[LinkComboBoxLabels[3]] + " (связано)")
                            //                {
                            //                    LinkComboBoxLabels[3].Content = ControlAndItsOriginalTextDictionary[LinkComboBoxLabels[3]] + " (связано)";
                            //                    LinkComboBoxLabels[3].Foreground = Brushes.Black;
                            //                    LinkComboBoxLabels[3].FontSize = 12;
                            //                    LinkComboBoxLabels[3].BorderThickness = default;
                            //                    LinkComboBoxLabels[3].BorderBrush = Brushes.Black;
                            //                }
                            //            }

                            //            else
                            //            {
                            //                // TODO: изменить на проверку уже наличия в связанном списке (string, string)
                            //                if (!LinkComboBoxComboBoxes[2].Items.Contains(LinkComboBoxComboBoxes[2].Text))
                            //                {
                            //                    if (LinkComboBoxLabels[3].Content.ToString() != ControlAndItsOriginalTextDictionary[LinkComboBoxLabels[3]] + " (связь доступна)")
                            //                    {
                            //                        LinkComboBoxLabels[3].Content = ControlAndItsOriginalTextDictionary[LinkComboBoxLabels[3]] + " (связь доступна)";
                            //                        LinkComboBoxLabels[3].Foreground = Brushes.Yellow;
                            //                        LinkComboBoxLabels[3].Height = LinkComboBoxLabels[3].ActualHeight;
                            //                        LinkComboBoxLabels[3].FontSize = 11;
                            //                        LinkComboBoxLabels[3].BorderThickness = new(1);
                            //                        LinkComboBoxLabels[3].BorderBrush = Brushes.Yellow;
                            //                    }
                            //                }

                            //                else
                            //                {
                            //                    LinkComboBoxLabels[3].Content = ControlAndItsOriginalTextDictionary[LinkComboBoxLabels[3]];
                            //                    LinkComboBoxLabels[3].Foreground = Brushes.Black;
                            //                    LinkComboBoxLabels[3].FontSize = 12;
                            //                    LinkComboBoxLabels[3].BorderThickness = default;
                            //                    LinkComboBoxLabels[3].BorderBrush = Brushes.Black;
                            //                }
                            //            }
                            //        }

                            //        else
                            //        {
                            //            if (LinkComboBoxLabels[3].Content.ToString().Contains('*'))
                            //            {
                            //                LinkComboBoxLabels[3].Content = ControlAndItsOriginalTextDictionary[LinkComboBoxLabels[3]] + '*';
                            //            }

                            //            else
                            //            {
                            //                LinkComboBoxLabels[3].Content = ControlAndItsOriginalTextDictionary[LinkComboBoxLabels[3]];
                            //            }

                            //            LinkComboBoxLabels[3].Foreground = Brushes.Black;
                            //            LinkComboBoxLabels[3].FontSize = 12;
                            //            LinkComboBoxLabels[3].BorderThickness = default;
                            //            LinkComboBoxLabels[3].BorderBrush = Brushes.Black;
                            //        }
                            //    }
                            //}

                            //else
                            //{
                            //    MainComboBoxItems = ComboBoxes[2].Items.Cast<string>().ToArray();
                            //    Labels[0].Content = $"{ControlAndItsOriginalTextDictionary[Labels[0]]} (связей — {MainComboBoxItems.Length})*";

                            //    foreach (ComboBox ComboBox in ComboBoxes)
                            //    {
                            //        if (ComboBox.Text == string.Empty)
                            //        {
                            //            ComboBox.Text = ControlAndItsOriginalTextDictionary[ComboBox];
                            //            ComboBox.Foreground = Brushes.Gray;
                            //        }
                            //    }
                            //}

                            foreach (Label Label in Labels)
                            {
                                if (!/*(*/Label.Content.ToString() /*?? string.Empty)*/.Contains('*'))
                                {
                                    Label.Content = Label.Content.ToString() + '*';
                                }
                            }

                            ChangesHaveBeenMade = true;

                            SaveChangesButton.Foreground = Brushes.Black;
                            SaveChangesButton.IsEnabled = true;
                        }
                    };
                }

                else if (Control is ComboBox ComboBox)
                {
                    if (ComboBox is TraceableComboBox TraceableComboBox)
                    {
                        TraceableComboBox.AddItemButton = ButtonAndItsControlsDictionary.FirstOrDefault(KeyValuePair => KeyValuePair.Value.ComboBoxes.Contains(ComboBox) && (KeyValuePair.Key.Name.Contains("Add") /*|| KeyValuePair.Key.Name.Contains("Binding")*/)).Key;
                        TraceableComboBox.SaveItemsButton = SaveChangesButton;
                    }

                    ComboBox.Foreground = Brushes.Gray;
                    ComboBox.Text = ControlAndItsOriginalTextDictionary[ComboBox];

                    bool ComboBoxLeaved = false;
                    bool ComboBoxEntered = false;

                    if (ButtonAndItsControlsDictionary.Where(KeyValuePair => KeyValuePair.Value.Labels.Count == 4 && KeyValuePair.Value.ComboBoxes.Contains(ComboBox)).Any(KeyValuePair => KeyValuePair.Value.ComboBoxes[2] == ComboBox))
                    {
                        (List<ComboBox> ComboBoxes, List<Label> Labels) = ButtonAndItsControlsDictionary.Where(KeyValuePair => KeyValuePair.Value.Labels.Count == 4 && KeyValuePair.Value.ComboBoxes.Contains(ComboBox)).FirstOrDefault(KeyValuePair => KeyValuePair.Value.ComboBoxes[2] == ComboBox).Value;
                        ComboBox.Text = ControlAndItsOriginalTextDictionary[ComboBoxes[2]];
                        ComboBox.Foreground = Brushes.Gray;

                        ComboBox.AddHandler(TextBoxBase.TextChangedEvent, new TextChangedEventHandler((sender, e) =>
                        {
                            //(List<ComboBox> ComboBoxes, List<Label> Labels) = ButtonAndItsControlsDictionary.Where(KeyValuePair => KeyValuePair.Value.Labels.Count == 4 && KeyValuePair.Value.ComboBoxes.Contains(ComboBox)).FirstOrDefault(KeyValuePair => KeyValuePair.Value.ComboBoxes[2] == ComboBox).Value;

                            string[] ComboBoxesAndTheirText = ComboBox.Text.Replace('-', '—').Split(new[] { " — " }, StringSplitOptions.None);

                            if (ComboBoxesAndTheirText.Length == 2)
                            {
                                string FirstComboBoxText = ComboBoxesAndTheirText[0];
                                string SecondComboBoxText = ComboBoxesAndTheirText[1];

                                if (!ComboBoxes[0].Items.Contains(FirstComboBoxText) || !ComboBoxes[1].Items.Contains(SecondComboBoxText))
                                {
                                    Labels[3].Content = ControlAndItsOriginalTextDictionary[Labels[3]];
                                    Labels[3].Foreground = Brushes.Black;
                                    Labels[3].FontSize = 12;
                                    Labels[3].BorderThickness = default;
                                    Labels[3].BorderBrush = Brushes.Black;
                                }

                                else if (ComboBoxes[2].Items.Contains(ComboBoxes[2].Text.Replace('-', '—')))
                                {
                                    if (Labels[3].Content.ToString() != ControlAndItsOriginalTextDictionary[Labels[3]] + " (связано)")
                                    {
                                        Labels[3].Content = ControlAndItsOriginalTextDictionary[Labels[3]] + " (связано)";
                                        Labels[3].Foreground = Brushes.Black;
                                        Labels[3].FontSize = 12;
                                        Labels[3].BorderThickness = default;
                                        Labels[3].BorderBrush = Brushes.Black;
                                    }
                                }

                                else
                                {
                                    // TODO: изменить на проверку уже наличия в связанном списке (string, string)
                                    if (!ComboBox.Items.Contains(ComboBox.Text))
                                    {
                                        if (Labels[3].Content.ToString() != ControlAndItsOriginalTextDictionary[Labels[3]] + " (связь доступна)")
                                        {
                                            Labels[3].Content = ControlAndItsOriginalTextDictionary[Labels[3]] + " (связь доступна)";
                                            Labels[3].Foreground = Brushes.Yellow;
                                            Labels[3].Height = Labels[3].ActualHeight;
                                            Labels[3].FontSize = 11;
                                            Labels[3].BorderThickness = new(1);
                                            Labels[3].BorderBrush = Brushes.Yellow;
                                        }
                                    }

                                    else
                                    {
                                        Labels[3].Content = ControlAndItsOriginalTextDictionary[Labels[3]];
                                        Labels[3].Foreground = Brushes.Black;
                                        Labels[3].FontSize = 12;
                                        Labels[3].BorderThickness = default;
                                        Labels[3].BorderBrush = Brushes.Black;
                                    }
                                }
                            }

                            else
                            {
                                if (Labels[3].Content.ToString().Contains('*'))
                                {
                                    Labels[3].Content = ControlAndItsOriginalTextDictionary[Labels[3]] + '*';
                                }

                                else
                                {
                                    Labels[3].Content = ControlAndItsOriginalTextDictionary[Labels[3]];
                                }

                                Labels[3].Foreground = Brushes.Black;
                                Labels[3].FontSize = 12;
                                Labels[3].BorderThickness = default;
                                Labels[3].BorderBrush = Brushes.Black;
                            }

                            //else
                            //{
                            //    if (SubjectAndTeacherList.Contains((ButtonAndItsControls.Value.ComboBoxes[0].Text, ButtonAndItsControls.Value.ComboBoxes[1].Text)) || SubjectAndClassroomList.Contains((ButtonAndItsControls.Value.ComboBoxes[0].Text, ButtonAndItsControls.Value.ComboBoxes[1].Text)) || TeacherAndClassroomList.Contains((ButtonAndItsControls.Value.ComboBoxes[0].Text, ButtonAndItsControls.Value.ComboBoxes[1].Text)) || NumberOfLessonAndTimeList.Contains((ButtonAndItsControls.Value.ComboBoxes[0].Text, ButtonAndItsControls.Value.ComboBoxes[1].Text)))
                            //    {
                            //        //if (ChangesHaveBeenMade)
                            //        //{
                            //        //    if (ButtonAndItsControls.Value.Labels[0].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]] + " (связано)*" && ButtonAndItsControls.Value.Labels[1].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]] + " (связано)*")
                            //        //    {
                            //        //        ButtonAndItsControls.Value.Labels[0].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]]} (связано)*";
                            //        //        ButtonAndItsControls.Value.Labels[1].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]]} (связано)*";
                            //        //    }
                            //        //}

                            //        //else
                            //        //{
                            //        //    if (ButtonAndItsControls.Value.Labels[0].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]] + " (связано)" && ButtonAndItsControls.Value.Labels[1].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]] + " (связано)")
                            //        //    {
                            //        //        ButtonAndItsControls.Value.Labels[0].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]]} (связано)";
                            //        //        ButtonAndItsControls.Value.Labels[1].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]]} (связано)";
                            //        //    }
                            //        //}
                            //    }

                            //    else
                            //    {
                            //        //(BoolDelegateWithoutParameters BoolDelegateWithoutParameters, bool BoolDelegateWithoutParametersArgument) = ButtonNameAndItsDelegateDictionary[ButtonAndItsControls.Key];

                            //        //if (Clicked == true)
                            //        //{
                            //        //    if (ButtonAndItsControls.Value.Labels[0].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]] + '*' && ButtonAndItsControls.Value.Labels[1].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]] + '*')
                            //        //    {
                            //        //        ButtonAndItsControls.Value.Labels[0].Text = ButtonAndItsControls.Value.Labels[0].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]]}*";
                            //        //        ButtonAndItsControls.Value.Labels[1].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]]}*";
                            //        //    }
                            //        //}

                            //        //else
                            //        //{
                            //        //    if (ButtonAndItsControls.Value.Labels[0].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]] + '*' && ButtonAndItsControls.Value.Labels[1].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]] + '*')
                            //        //    {
                            //        //        ButtonAndItsControls.Value.Labels[0].Text = ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]];
                            //        //        ButtonAndItsControls.Value.Labels[1].Text = ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]];
                            //        //    }
                            //        //}
                            //    }
                            //}
                        }));

                        //ComboBox.TextChanged += (sender, e) =>
                        //{
                        //    //(List<ComboBox> ComboBoxes, List<Label> Labels) = ButtonAndItsControlsDictionary.Where(KeyValuePair => KeyValuePair.Value.Labels.Count == 4 && KeyValuePair.Value.ComboBoxes.Contains(ComboBox)).FirstOrDefault(KeyValuePair => KeyValuePair.Value.ComboBoxes[2] == ComboBox).Value;

                        //    string[] ComboBoxesAndTheirText = ComboBox.Text.Split(new[] { " — " }, StringSplitOptions.None);

                        //    if (ComboBoxesAndTheirText.Length == 2)
                        //    {
                        //        string FirstComboBoxText = ComboBoxesAndTheirText[0];
                        //        string SecondComboBoxText = ComboBoxesAndTheirText[1];

                        //        if (!ComboBoxes[0].Items.Contains(FirstComboBoxText) || !ComboBoxes[1].Items.Contains(SecondComboBoxText))
                        //        {
                        //            Labels[3].Text = ControlAndItsOriginalTextDictionary[Labels[3]];
                        //            Labels[3].ForeColor = SystemColors.ControlText;
                        //        }

                        //        else
                        //        {
                        //            // TODO: изменить на проверку уже наличия в связанном списке (string, string)
                        //            if (!ComboBox.Items.Contains(ComboBox.Text))
                        //            {
                        //                if (Labels[3].Text != ControlAndItsOriginalTextDictionary[Labels[3]] + "\n(связь доступна)")
                        //                {
                        //                    Labels[3].Text = ControlAndItsOriginalTextDictionary[Labels[3]] + "\n(связь доступна)";
                        //                    Labels[3].ForeColor = Color.Yellow;
                        //                    // TODO: добавить также рамку для Label жёлтого цвета
                        //                }
                        //            }

                        //            else
                        //            {
                        //                Labels[3].Text = ControlAndItsOriginalTextDictionary[Labels[3]];
                        //                Labels[3].ForeColor = SystemColors.ControlText;
                        //            }
                        //        }
                        //    }

                        //    else
                        //    {
                        //        if (Labels[3].Text.Contains('*'))
                        //        {
                        //            Labels[3].Text = ControlAndItsOriginalTextDictionary[Labels[3]] + '*';
                        //        }

                        //        else
                        //        {
                        //            Labels[3].Text = ControlAndItsOriginalTextDictionary[Labels[3]];
                        //        }

                        //        Labels[3].ForeColor = SystemColors.ControlText;
                        //    }

                        //    //else
                        //    //{
                        //    //    if (SubjectAndTeacherList.Contains((ButtonAndItsControls.Value.ComboBoxes[0].Text, ButtonAndItsControls.Value.ComboBoxes[1].Text)) || SubjectAndClassroomList.Contains((ButtonAndItsControls.Value.ComboBoxes[0].Text, ButtonAndItsControls.Value.ComboBoxes[1].Text)) || TeacherAndClassroomList.Contains((ButtonAndItsControls.Value.ComboBoxes[0].Text, ButtonAndItsControls.Value.ComboBoxes[1].Text)) || NumberOfLessonAndTimeList.Contains((ButtonAndItsControls.Value.ComboBoxes[0].Text, ButtonAndItsControls.Value.ComboBoxes[1].Text)))
                        //    //    {
                        //    //        //if (ChangesHaveBeenMade)
                        //    //        //{
                        //    //        //    if (ButtonAndItsControls.Value.Labels[0].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]] + " (связано)*" && ButtonAndItsControls.Value.Labels[1].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]] + " (связано)*")
                        //    //        //    {
                        //    //        //        ButtonAndItsControls.Value.Labels[0].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]]} (связано)*";
                        //    //        //        ButtonAndItsControls.Value.Labels[1].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]]} (связано)*";
                        //    //        //    }
                        //    //        //}

                        //    //        //else
                        //    //        //{
                        //    //        //    if (ButtonAndItsControls.Value.Labels[0].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]] + " (связано)" && ButtonAndItsControls.Value.Labels[1].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]] + " (связано)")
                        //    //        //    {
                        //    //        //        ButtonAndItsControls.Value.Labels[0].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]]} (связано)";
                        //    //        //        ButtonAndItsControls.Value.Labels[1].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]]} (связано)";
                        //    //        //    }
                        //    //        //}
                        //    //    }

                        //    //    else
                        //    //    {
                        //    //        //(BoolDelegateWithoutParameters BoolDelegateWithoutParameters, bool BoolDelegateWithoutParametersArgument) = ButtonNameAndItsDelegateDictionary[ButtonAndItsControls.Key];

                        //    //        //if (Clicked == true)
                        //    //        //{
                        //    //        //    if (ButtonAndItsControls.Value.Labels[0].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]] + '*' && ButtonAndItsControls.Value.Labels[1].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]] + '*')
                        //    //        //    {
                        //    //        //        ButtonAndItsControls.Value.Labels[0].Text = ButtonAndItsControls.Value.Labels[0].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]]}*";
                        //    //        //        ButtonAndItsControls.Value.Labels[1].Text = $"{ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]]}*";
                        //    //        //    }
                        //    //        //}

                        //    //        //else
                        //    //        //{
                        //    //        //    if (ButtonAndItsControls.Value.Labels[0].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]] + '*' && ButtonAndItsControls.Value.Labels[1].Text != ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]] + '*')
                        //    //        //    {
                        //    //        //        ButtonAndItsControls.Value.Labels[0].Text = ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[0]];
                        //    //        //        ButtonAndItsControls.Value.Labels[1].Text = ControlAndItsOriginalTextDictionary[ButtonAndItsControls.Value.Labels[1]];
                        //    //        //    }
                        //    //        //}
                        //    //    }
                        //    //}
                        //};
                    }

                    //!!
                    //ComboBox.GotFocus += (sender, e) =>
                    //{
                    //    ComboBoxEntered = true;

                    //    if (ComboBox.Text == ControlAndItsOriginalTextDictionary[ComboBox] && ComboBox.Foreground == Brushes.Gray)
                    //    {
                    //        ComboBox.Text = string.Empty;
                    //    }

                    //    ComboBox.Foreground = Brushes.Black;
                    //};

                    //ComboBox.LostFocus += (sender, e) =>
                    //{
                    //    ComboBoxEntered = false;
                    //    ComboBoxLeaved = true;

                    //    if (string.IsNullOrWhiteSpace(ComboBox.Text))
                    //    {
                    //        ComboBox.Foreground = Brushes.Gray;
                    //        ComboBox.Text = ControlAndItsOriginalTextDictionary[ComboBox];
                    //    }
                    //};

                    //ComboBox.DropDownClosed += (sender, e) =>
                    //{
                    //    if (string.IsNullOrWhiteSpace(ComboBox.Text) && ComboBoxLeaved && !ComboBoxEntered)
                    //    {
                    //        ComboBox.Foreground = Brushes.Gray;
                    //        ComboBox.Text = ControlAndItsOriginalTextDictionary[ComboBox];

                    //        ComboBoxLeaved = false;
                    //    }
                    //};
                }

                //else if (Control is Label Label)
                //{
                    //TODO: сделать, чтобы не задавать текст вручную
                //}
            });

            Closing += (sender, e) =>
            {
                if (ChangesHaveBeenMade)
                {
                    MessageBoxResult SaveChangesMessageBoxResult = MessageBox.Show("Внимание, вы внесли изменения, но не сохранили их!\n\nВы уверены, что хотите продолжить без сохранения изменений?", "Сохранение изменений", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);

                    if (SaveChangesMessageBoxResult == MessageBoxResult.No)
                    {
                        e.Cancel = true;
                    }
                }
            };
        }

        // Метод обработки загруженных данных
        private void LoadData()
        {
            LoadMainData();
            LoadLinks();
        }

        // Метод загрузки существующих основных данных
        private void LoadMainData()
        {
            if (MainData.SubjectList != null && MainData.SubjectList.Count != 0)
            {
                SubjectList = MainData.SubjectList.ToList();

                foreach (string SubjectListItem in SubjectList)
                {
                    //SubjectsComboBox.Items.Add(SubjectListItem);
                    SubjectsOfTeacherComboBox.Items.Add(SubjectListItem);
                    SubjectsOfClassroomComboBox.Items.Add(SubjectListItem);
                }
            }

            if (MainData.TeacherList != null && MainData.TeacherList.Count != 0)
            {
                TeacherList = MainData.TeacherList.ToList();

                foreach (string TeacherListItem in TeacherList)
                {
                    //TeachersComboBox.Items.Add(TeacherListItem);
                    TeachersOfSubjectComboBox.Items.Add(TeacherListItem);
                    TeachersOfClassroomComboBox.Items.Add(TeacherListItem);
                }
            }

            if (MainData.GroupList != null && MainData.GroupList.Count != 0)
            {
                GroupList = MainData.GroupList.ToList();

                foreach (string GroupListItem in GroupList)
                {
                    //GroupsComboBox.Items.Add(GroupListItem);
                }
            }

            if (MainData.ClassroomList != null && MainData.ClassroomList.Count != 0)
            {
                ClassroomList = MainData.ClassroomList.ToList();

                foreach (string ClassroomListItem in ClassroomList)
                {
                    //ClassroomsComboBox.Items.Add(ClassroomListItem);
                    ClassroomsOfSubjectComboBox.Items.Add(ClassroomListItem);
                    ClassroomsOfTeacherComboBox.Items.Add(ClassroomListItem);
                }
            }
        }

        // Метод загрузки существующих связей
        private void LoadLinks()
        {
            if (MainData.SubjectAndTeacherList != null && MainData.SubjectAndTeacherList.Count != 0)
            {
                SubjectAndTeacherList = MainData.SubjectAndTeacherList.ToList();

                string[] SubjectAndTeacherArray = SubjectAndTeacherList.Select(SubjectAndTeacherList => SubjectAndTeacherList.Item1 + " — " + SubjectAndTeacherList.Item2).ToArray();

                foreach (string SubjectAndTeacherArrayItem in SubjectAndTeacherArray)
                {
                    SubjectAndTeacherLinksComboBox.Items.Add(SubjectAndTeacherArrayItem);
                }
            }

            if (MainData.SubjectAndClassroomList != null && MainData.SubjectAndClassroomList.Count != 0)
            {
                SubjectAndClassroomList = MainData.SubjectAndClassroomList.ToList();

                string[] SubjectAndClassroomArray = SubjectAndClassroomList.Select(SubjectAndClassroomList => SubjectAndClassroomList.Item1 + " — " + SubjectAndClassroomList.Item2).ToArray();

                foreach (string SubjectAndClassroomArrayItem in SubjectAndClassroomArray)
                {
                    SubjectAndClassroomLinksComboBox.Items.Add(SubjectAndClassroomArrayItem);
                }
            }

            if (MainData.TeacherAndClassroomList != null && MainData.TeacherAndClassroomList.Count != 0)
            {
                TeacherAndClassroomList = MainData.TeacherAndClassroomList.ToList();

                string[] TeacherAndClassroomArray = TeacherAndClassroomList.Select(TeacherAndClassroomList => TeacherAndClassroomList.Item1 + " — " + TeacherAndClassroomList.Item2).ToArray();

                foreach (string TeacherAndClassroomArrayItem in TeacherAndClassroomArray)
                {
                    TeacherAndClassroomLinksComboBox.Items.Add(TeacherAndClassroomArrayItem);
                }
            }

            if (MainData.NumberOfLessonAndTimeList != null && MainData.NumberOfLessonAndTimeList.Count != 0)
            {
                NumberOfLessonAndTimeList = MainData.NumberOfLessonAndTimeList.ToList();

                string[] NumberOfLessonAndTimeArray = NumberOfLessonAndTimeList.Select(NumberOfLessonAndTimeList => NumberOfLessonAndTimeList.Item1 + " — " + NumberOfLessonAndTimeList.Item2).ToArray();

                foreach (string NumberOfLessonAndTimeArrayItem in NumberOfLessonAndTimeArray)
                {
                    LessonAndTimeLinksComboBox.Items.Add(NumberOfLessonAndTimeArrayItem);
                }
            }
        }

        // Событие, которое вызывается при изменении данных
        public static event Action? OnDataChanged;

        // Событие сохранения всех данных по нажатию на кнопку
        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            MainData = EditGroupScheduleWindow.LoadData<MainDataClass>();
            //// Для списка предметов
            //string subjects = string.Join(", ", SubjectList);
            //MessageBox.Show(subjects, "Список предметов");

            if (SubjectList == MainData.SubjectList && TeacherList == MainData.TeacherList && GroupList == MainData.GroupList && ClassroomList == MainData.ClassroomList)
            {
                return;
            }

            //if (!ChangesHaveBeenMade)
            //{
            //    return;
            //}

            MainData.SubjectList = new(SubjectsControl.EntityList);
            MainData.TeacherList = new(TeachersControl.EntityList);
            MainData.GroupList = new(GroupsControl.EntityList);
            MainData.ClassroomList = new(ClassroomsControl.EntityList);
            MainData.SubjectAndTeacherList = SubjectAndTeacherList;
            MainData.SubjectAndClassroomList = SubjectAndClassroomList;
            MainData.TeacherAndClassroomList = TeacherAndClassroomList;
            MainData.NumberOfLessonAndTimeList = NumberOfLessonAndTimeList;

            MainData.SaveData<MainDataClass>();

            // Добавление обработчика для всех меток на форме
            EditMainDataWindowTableLayoutGrid.ProcessAllChildVisualControls(Control =>
            {
                if (Control is Label Label)
                {
                    CommonMethodsClass.RemoveACertainLastCharacterInControlText(Label, '*');
                }
            });

            SaveChangesButton.Foreground = Brushes.Gray;
            SaveChangesButton.IsEnabled = false;

            OnDataChanged?.Invoke();

            ChangesHaveBeenMade = false;

            MainDataLabelTextBlock.Text = $"Основные данные (общее кол-во данных: {SubjectsControl.EntityList.Count + TeachersControl.EntityList.Count + GroupsControl.EntityList.Count + ClassroomsControl.EntityList.Count} шт.)";

            MessageBox.Show("Данные успешно сохранены!", string.Empty, MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }

    //internal class SubjectsComboBoxWithButtons : ComboBoxesWithButtons
    //{
    //    public SubjectsComboBoxWithButtons(ComboBox ComboBox, List<string> ComboBoxList) : base(ComboBox, ComboBoxList)
    //    {

    //    }

    //    [Obsolete("Экземпляр класса и так будет выполнять базовый метод. Строка ниже излишняя")]
    //    public override void ModifyList(List<string> list, string item, bool isAdd)
    //    {
    //        base.ModifyList(list, item, isAdd);
    //    }
    //}

    //internal class TeachersComboBoxWithButtons : ComboBoxesWithButtons
    //{
    //    public TeachersComboBoxWithButtons(ComboBox ComboBox, List<string> ComboBoxList) : base(ComboBox, ComboBoxList)
    //    {

    //    }

    //    [Obsolete("Экземпляр класса и так будет выполнять базовый метод. Строка ниже излишняя")]
    //    public override void ModifyList(List<string> list, string item, bool isAdd)
    //    {
    //        base.ModifyList(list, item, isAdd);
    //    }
    //}

    //internal class GroupsComboBoxWithButtons : ComboBoxesWithButtons
    //{
    //    public GroupsComboBoxWithButtons(ComboBox ComboBox, List<string> ComboBoxList) : base(ComboBox, ComboBoxList)
    //    {

    //    }

    //    [Obsolete("Экземпляр класса и так будет выполнять базовый метод. Строка ниже излишняя")]
    //    public override void ModifyList(List<string> list, string item, bool isAdd)
    //    {
    //        base.ModifyList(list, item, isAdd);
    //    }
    //}

    //internal class ClassroomsComboBoxWithButtons : ComboBoxesWithButtons
    //{
    //    public ClassroomsComboBoxWithButtons(ComboBox ComboBox, List<string> ComboBoxList) : base(ComboBox, ComboBoxList)
    //    {

    //    }

    //    [Obsolete("Экземпляр класса и так будет выполнять базовый метод. Строка ниже излишняя")]
    //    public override void ModifyList(List<string> list, string item, bool isAdd)
    //    {
    //        base.ModifyList(list, item, isAdd);
    //    }
    //}

    internal class SubjectsAndTeachersComboBoxesWithButtons : ComboBoxesWithButtons
    {
        public SubjectsAndTeachersComboBoxesWithButtons(ComboBox FirstComboBox, List<string> FirstComboBoxList, ComboBox SecondComboBox, List<string> SecondComboBoxList, ComboBox ThirdComboBox, List<(string, string)> ComboBoxesPairsList) : base(FirstComboBox, FirstComboBoxList, SecondComboBox, SecondComboBoxList, ThirdComboBox, ComboBoxesPairsList)
        {

        }

        [Obsolete("Экземпляр класса и так будет выполнять базовый метод. Строка ниже излишняя")]
        public override void ModifyList(List<string> list, string item, bool isAdd)
        {
            base.ModifyList(list, item, isAdd);
        }
    }

    internal class SubjectsAndClassroomsComboBoxesWithButtons : ComboBoxesWithButtons
    {
        public SubjectsAndClassroomsComboBoxesWithButtons(ComboBox FirstComboBox, List<string> FirstComboBoxList, ComboBox SecondComboBox, List<string> SecondComboBoxList, ComboBox ThirdComboBox, List<(string, string)> ComboBoxesPairsList) : base(FirstComboBox, FirstComboBoxList, SecondComboBox, SecondComboBoxList, ThirdComboBox, ComboBoxesPairsList)
        {

        }

        [Obsolete("Экземпляр класса и так будет выполнять базовый метод. Строка ниже излишняя")]
        public override void ModifyList(List<string> list, string item, bool isAdd)
        {
            base.ModifyList(list, item, isAdd);
        }
    }

    internal class TeachersAndClassroomsComboBoxesWithButtons : ComboBoxesWithButtons
    {
        public TeachersAndClassroomsComboBoxesWithButtons(ComboBox FirstComboBox, List<string> FirstComboBoxList, ComboBox SecondComboBox, List<string> SecondComboBoxList, ComboBox ThirdComboBox, List<(string, string)> ComboBoxesPairsList) : base(FirstComboBox, FirstComboBoxList, SecondComboBox, SecondComboBoxList, ThirdComboBox, ComboBoxesPairsList)
        {

        }

        [Obsolete("Экземпляр класса и так будет выполнять базовый метод. Строка ниже излишняя")]
        public override void ModifyList(List<string> list, string item, bool isAdd)
        {
            base.ModifyList(list, item, isAdd);
        }
    }

    internal class NumbersOfLessonAndTimeComboBoxesWithButtons : ComboBoxesWithButtons
    {
        public NumbersOfLessonAndTimeComboBoxesWithButtons(ComboBox FirstComboBox, List<string> FirstComboBoxList, ComboBox SecondComboBox, List<string> SecondComboBoxList, ComboBox ThirdComboBox, List<(string, string)> ComboBoxesPairsList) : base(FirstComboBox, FirstComboBoxList, SecondComboBox, SecondComboBoxList, ThirdComboBox, ComboBoxesPairsList)
        {

        }

        [Obsolete("Экземпляр класса и так будет выполнять базовый метод. Строка ниже излишняя")]
        public override void ModifyList(List<string> list, string item, bool isAdd)
        {
            base.ModifyList(list, item, isAdd);
        }
    }
}