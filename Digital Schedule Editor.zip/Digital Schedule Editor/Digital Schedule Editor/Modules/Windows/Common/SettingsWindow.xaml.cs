﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Text.RegularExpressions;

using Digital_Schedule_Editor.Extensions.CommonComponents;

namespace Digital_Schedule_Editor.Modules.Windows.Common
{
    /// <summary>
    /// Логика окна настроек SettingsWindow.xaml
    /// </summary>
    public partial class SettingsWindow : Window
    {
        public bool SetHomeroomsOnMondays;

        public SettingsWindow()
        {
            InitializeComponent();

            if (SetHomeroomsOnMondaysCheckBox.IsChecked.HasValue)
            {
                SetHomeroomsOnMondays = SetHomeroomsOnMondaysCheckBox.IsChecked.Value;
            }

            SettingsGrid.ProcessAllChildVisualControls(Control =>
            {
                if (Control is TextBlock TextBlock)
                {
                    TextBlock.MouseEnter += (sender, e) => TextBlock.TextDecorations = TextDecorations.Underline;
                    TextBlock.MouseLeave += (sender, e) => TextBlock.TextDecorations = null;
                }
            });
        }

        private void MaxHoursPerWeekForGroupTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Разрешить ввод только цифр
            if (!IsTextAllowed(e.Text))
            {
                e.Handled = true;
            }
        }

        private void MaxHoursPerWeekForGroupTextBox_Pasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(string)))
            {
                string text = string.Empty;

                if (e.DataObject.GetData(typeof(string)) is string String)
                {
                    text = String;
                }

                if (!IsTextAllowed(text))
                {
                    e.CancelCommand();
                }
            }

            else
            {
                e.CancelCommand();
            }
        }

        private static bool IsTextAllowed(string text)
        {
            // Регулярное выражение, которое соответствует только цифрам
            Regex Regex = NumbersOnlyRegex();
            return !Regex.IsMatch(text);
        }

        private void SetHomeroomsOnMondaysCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (SetHomeroomsOnMondaysCheckBox.IsChecked.HasValue)
            {
                if (SetHomeroomsOnMondaysCheckBox.IsChecked.Value)
                {
                    SetHomeroomsOnMondays = true;
                }

                else
                {
                    SetHomeroomsOnMondays = false;
                }
            }
        }

        private void SpecialRuleForMondayInfoTextBlock_MouseDown(object sender, MouseButtonEventArgs e)
        {
            SpecialRuleForMondayInfoTextBlock.Foreground = Brushes.Red;

            Window SpecialRuleForMondayInfoWindow = new()
            {
                WindowStyle = WindowStyle.ToolWindow,
                Width = SystemParameters.PrimaryScreenWidth / 4,
                Height = SystemParameters.PrimaryScreenHeight / 4,
            };

            SpecialRuleForMondayInfoWindow.ShowDialog();

            SpecialRuleForMondayInfoTextBlock.Foreground = Brushes.Black;
        }

        [GeneratedRegex("[^0-9]+")]
        private static partial Regex NumbersOnlyRegex();

        private void SaveSettingsOptionsButton_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}