﻿// TODO: залочить кнопки + и редакция для группы, чьё окно расписания открыто

using Digital_Schedule_Editor.Classes;
using Digital_Schedule_Editor.Classes.SerializingClasses;
using Digital_Schedule_Editor.Controls.CustomControls;
using Digital_Schedule_Editor.Controls.StaticControls;
using Digital_Schedule_Editor.Modules.Windows.College;
using Digital_Schedule_Editor.Modules.Windows.Common;
using System.Collections.Generic;
using System.Windows;

namespace Digital_Schedule_Editor.Modules.Windows.Common
{
    public partial class MainWindow : Window
    {
        // Поля //

        // Поля хранимых данных проекта
        private readonly MainDataClass MainData = new();
        private EditMainDataWindow EditMainDataWindow;
        private GroupDataClass GroupData;
        private readonly List<GroupDataClass> GroupDataList = new();

        //private new DialogResult DialogResult;

        //Panel GroupsScheduleTablePanel;
        //SplitContainer EditMainDataButtonAndSettingsButtonSplitContainer;

        //private int RowsInTableLayoutPanel;

        //readonly List<(string, int, int)> ElementPositionXY = new();

        //private List<(int Column, int Row, string Day, string Week, string Text)> GroupTextBoxesInfoList = new();

        //readonly TableLayoutPanel GroupsScheduleTableLayoutPanel = StaticControlsClass.GroupsScheduleTableLayoutPanel;
        //readonly SeparateLabelWithAngledText SeparateLabel = StaticControlsClass.SeparateLabel;

        //// TODO: автоматизировать пробелы между группами и днями недели (в долгосрочной перспективе)

        //private List<string> TextBoxElements = new();

        //// Индексы столбцов отступов после колонки номера группы
        //private readonly int[] IndentColumnIndexArray = new int[ConstantsClass.NumberOfGroups - 1]
        //{
        //    7, 12, 17, 22, 27, 32, 37, 42, 47, 52, 57, 62, 67, 72, 77, 82, 87, 92, 97, 102, 107, 112
        //};

        //// Индексы строк отступов после всех пар дня недели
        //private readonly int[] IndentRowIndexArray = new int[ConstantsClass.NumberOfDaysOfWeek - 1]
        //{
        //    12, 21, 30, 39
        //};

        //// Индексы столбцов ячеек НЧ недель
        //readonly int[] OddWeekColumnIndexArray = new int[ConstantsClass.NumberOfGroups]
        //{
        //    3, 8, 13, 18, 23, 28, 33, 38, 43, 48, 53, 58, 63, 68, 73, 78, 83, 88, 93, 98, 103, 108, 113
        //};

        //// Индексы столбцов ячеек Ч недель
        //readonly int[] EvenWeekColumnIndexArray = new int[ConstantsClass.NumberOfGroups]
        //{
        //    5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100, 105, 110, 115
        //};




        //// Индексы столбцов ячеек предметов и преподавателей
        //readonly int[] SubjectAndTeacherColumnIndexesArray = new int[ConstantsClass.NumberOfGroups * 2]
        //{
        //    3, 5, 8, 10, 13, 15, 18, 20, 23, 25, 28, 30, 33, 35, 38, 40, 43, 45, 48, 50, 53, 55, 58, 60, 63, 65, 68, 70, 73, 75, 78, 80, 83, 85, 88, 90, 93, 95, 98, 100, 103, 105, 108, 110, 113, 115
        //};

        //// Установка объединения двух столбцов для предметов
        //// дни недели * кол-во пар + кл. ч.
        //// Индексы строк ячеек предметов
        //private readonly int[] SubjectRowIndexArray = new int[ConstantsClass.NumberOfDaysOfWeek * 4 + 1]
        //{
        //    2, 4, 6, 8, 10, 13, 15, 17, 19, 22, 24, 26, 28, 31, 33, 35, 37, 40, 42, 44, 46
        //};

        //// Индексы строк ячеек преподавателей и кабинетов
        //private readonly int[] TeacherAndClassroomRowIndexesArray = new int[ConstantsClass.NumberOfDaysOfWeek * 4 + 1]
        //{
        //    3, 5, 7, 9, 11, 14, 16, 18, 20, 23, 25, 27, 29, 32, 34, 36, 38, 41, 43, 45, 47
        //};

        //// Индексы столбцов ячеек кабинетов
        //readonly int[] ClassroomColumnIndexArray = new int[ConstantsClass.NumberOfGroups * 2]
        //{
        //    4, 6, 9, 11, 14, 16, 19, 21, 24, 26, 29, 31, 34, 36, 39, 41, 44, 46, 49, 51, 54, 56, 59, 61, 64, 66, 69, 71, 74, 76, 79, 81, 84, 86, 89, 91, 94, 96, 99, 101, 104, 106, 109, 111, 114, 116
        //};

        //public MainWindow()
        //{
        //    //InitializeComponent();

        //    MainData = EditGroupScheduleWindow.LoadData<MainDataClass>();

        //    GroupsScheduleTableLayoutPanel.SuspendLayout(); // тут ???
        //    SetMainWindowDefaults();
        //    LoadGroupsDataAndGrid();
        //    GroupsScheduleTableLayoutPanel.ResumeLayout();

        //    // TODO: проверить, есть ли случаи, когда файлы придётся закрывать вручную, явно
        //    //FormClosing += (sender, s) =>
        //    //{
        //    //    foreach (var x in SerializableDataClass.OpenedFileStreams)
        //    //    {
        //    //        x.Item2.Close();
        //    //    }

        //    //    SerializableDataClass.OpenedFileStreams.Clear();
        //    //};
        //}

        //// События //

        //// Событие загрузки главного окна при запуске приложения
        //private void MainWindow_Shown(object sender, EventArgs e)
        //{
        //    ErrorProvider();

        //    int DialogResultCase = -1;

        //    if (MainData?.SubjectList?.Count == null && MainData?.TeacherList?.Count == null && MainData?.GroupList?.Count == null && MainData?.ClassroomList?.Count == null)
        //    {
        //        DialogResultCase = 0;
        //        DialogResult = MessageBox.Show("Внимание, отсутствуют необходимые данные для работы с расписанием!\n\nВы уверены, что хотите продолжить работу без них?", "Отсутствуют необходимые данные!", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);
        //    }

        //    // TODO: проверить работу кажого условия (корректно ли оно срабатывает)
        //    else if (MainData?.SubjectList?.Count == 0 && MainData?.TeacherList?.Count == 0 && MainData?.GroupList?.Count == 0 && MainData?.ClassroomList?.Count == 0)
        //    {
        //        DialogResultCase = 1;
        //        DialogResult = MessageBox.Show("Внимание, похоже, что необходимые данные для работы с расписанием не были корректно сохранены или были удалены!\n\nВы уверены, что хотите продолжить работу без них?", "Сохранённые данные отсутствуют!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
        //    }

        //    else if (MainData?.SubjectList?.Count == 0 || MainData?.TeacherList?.Count == 0 || MainData?.GroupList?.Count == 0 || MainData?.ClassroomList?.Count == 0)
        //    {
        //        // TODO: добавить проверку на Count = 0 в EditMainDataWindow перед сохранением
        //        // "вы уверены, что хотите продолжить без всех/некоторых необходимых данных?"
        //        DialogResultCase = 2;
        //        DialogResult = MessageBox.Show("Похоже, что некоторые данные для работы с расписанием отсутствуют.\n\nЖелаете заполнить недостающие данные?", "Отсутствуют некоторые данные", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
        //    }

        //    if (DialogResult == DialogResult.No && DialogResultCase != 2)
        //    {
        //        EditMainDataWindow = new();
        //        EditMainDataWindow.FormClosed += (sender, e) =>
        //        {
        //            //SetMainWindowDefaults();
        //            //LoadGroupsDataAndGrid();
        //        };

        //        EditMainDataWindow.Show();
        //    }

        //    if (DialogResult == DialogResult.Yes && DialogResultCase == 2)
        //    {
        //        EditMainDataWindow = new();
        //        EditMainDataWindow.FormClosed += (sender, e) =>
        //        {
        //            //SetMainWindowDefaults();
        //            //LoadGroupsDataAndGrid();
        //        };

        //        EditMainDataWindow.Show();
        //    }

        //    foreach (GroupDataClass x in GroupDataList)
        //    {
        //        //x.GroupName = x.
        //        //GroupData = new()
        //        //{
        //        //    GroupName = GroupDataList.
        //        //};

        //        //GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(); // переменная загруженных данных проекта

        //        GroupDataClass p = new()
        //        {
        //            GroupName = x.GroupName
        //        };

        //        p = EditGroupScheduleWindow.LoadData<GroupDataClass>(x.GroupName);

        //        if (p.DockableComboBoxesInfoList != null)
        //        {
        //            LoadGroupSchedule(p, null);
        //        }
        //    }

        //    //else
        //    {
        //        //if (GroupData?.GroupsDockableComboBoxPositionAndTheirTextList != null && GroupData.GroupsDockableComboBoxPositionAndTheirTextList.Count != 0)
        //        //{
        //        //    int maxRow = 0;
        //        //    int maxColumn = 0;
        //        //    int GroupCount = 0;
        //        //    bool IsItForFirstTime = true;

        //        //    foreach (var group in MainData.GroupList)
        //        //    {
        //        //        if (GroupData?.GroupsDockableComboBoxPositionAndTheirTextList?.FirstOrDefault(x => x.Item1 == group).Item2 != null)
        //        //        {
        //        //            // TODO: foreach
        //        //            GroupSubjectTextBoxesPositionAndTheirTextList = GroupData.GroupsDockableComboBoxPositionAndTheirTextList.FirstOrDefault(x => x.Item1 == group).Item2;
        //        //        }

        //        //        for (int i = 0; i < GroupsScheduleTableLayoutPanel.ColumnCount; i++)
        //        //        {
        //        //            string GroupText = GroupsScheduleTableLayoutPanel.GetControlFromPosition(i, 0).Text;

        //        //            if (GroupText == group)
        //        //            {
        //        //                ElementPositionXY.Add((group, i, 0));
        //        //                break;
        //        //            }
        //        //        }

        //        //        if (GroupSubjectTextBoxesPositionAndTheirTextList != null && GroupSubjectTextBoxesPositionAndTheirTextList.Count != 0)
        //        //        {
        //        //            // TODO: код производит неверный расчёт - исправить!
        //        //            maxRow = GroupSubjectTextBoxesPositionAndTheirTextList.Max(item => item.Item1);
        //        //            maxColumn = GroupSubjectTextBoxesPositionAndTheirTextList.Max(item => item.Item2);

        //        //            if (IsItForFirstTime)
        //        //            {
        //        //                IsItForFirstTime = false;
        //        //                // Добавляем стили для строк и колонок
        //        //                for (int i = 0; i < (maxRow - 1) * (maxColumn - 7); i++)
        //        //                {
        //        //                    RowsInTableLayoutPanel = GroupsScheduleTableLayoutPanel.RowCount - 1;
        //        //                    //RowIndex = RowsInTableLayoutPanel;

        //        //                    // Добавление новой строки
        //        //                    GroupsScheduleTableLayoutPanel.RowCount++;
        //        //                    // Добавление нового стиля строки
        //        //                    GroupsScheduleTableLayoutPanel.RowStyles.Add(new(SizeType.AutoSize));
        //        //                }
        //        //            }
        //        //        }

        //        //        for (int i = 0; i < (5 - 1) * (12 - 7); i++)
        //        //        {
        //        //            GroupsScheduleTableLayoutPanel.Controls.Add(new TextBox() { ReadOnly = true }, GroupCount + 1, i + 1);
        //        //        }

        //        //        UpdateSubjectsForGroup(GroupData);

        //        //        GroupCount++;
        //        //    }

        //        //for (int i = 0; i < (maxRow - 1) * (maxColumn - 7); i++)
        //        //{
        //        //    // TODO: переделать в создание строк
        //        //    ВКонецToolStripMenuItem_Click(this, EventArgs.Empty);
        //        //}

        //        //for (int i = 0; i < GroupsScheduleTableLayoutPanel.RowCount; i++)
        //        //{
        //        //    GroupsScheduleTableLayoutPanel.RowStyles.Add(new(SizeType.Absolute, 50/*AutoSize*/));
        //        //}

        //        //// TODO: убрать нижнее (сделано для красоты)
        //        //for (int x = 0; x < MainData.GroupList.Count; x++)
        //        //{
        //        //    for (int i = 0; i < (maxRow - 1) * (maxColumn - 7); i++)
        //        //    {
        //        //        GroupsScheduleTableLayoutPanel.Controls.Add(new TextBox() { ReadOnly = true }, x + 1, i + 1);
        //        //    }
        //        //}

        //        //for (int i = 0; i < (maxRow - 1) * (maxColumn - 7); i++)
        //        //{
        //        //    GroupsScheduleTableLayoutPanel.Controls.Add(new TextBox() { ReadOnly = true }, ElementPositionXY.Item1, i + 1);
        //        //}

        //        //GroupsScheduleTableLayoutPanel.Height = GroupsScheduleTableLayoutPanel.GetRowHeights().Sum();

        //        //foreach (GroupDataClass x in GroupDataList)
        //        //{
        //        //    var p = EditGroupScheduleWindow.LoadData<GroupDataClass>();

        //        //    if (p.DockableComboBoxesInfoList != null)
        //        //    {
        //        //        LoadGroupSchedule(x, null);
        //        //    }
        //        //}
        //    }

        //    SplitContainer GroupsScheduleTablePanelAndButtonsSeparator = new()
        //    {
        //        Dock = DockStyle.Fill,
        //        IsSplitterFixed = true,
        //        SplitterWidth = 1
        //    };

        //    // Возникло исключение о нехватки места для SplitterDistance при сворачивании окна!
        //    GroupsScheduleTablePanelAndButtonsSeparator.SplitterMoved += (s, e) =>
        //    {
        //        //GroupsScheduleTablePanelAndButtonsSeparator.SuspendLayout();
        //        if (GroupsScheduleTablePanelAndButtonsSeparator.SplitterDistance != Width - 117)
        //        {
        //            GroupsScheduleTablePanelAndButtonsSeparator.SplitterDistance = Width - 117;
        //        }
        //        //GroupsScheduleTablePanelAndButtonsSeparator.ResumeLayout();
        //    };

        //    GroupsScheduleTablePanel = new()
        //    {
        //        AutoScroll = true,
        //        Dock = DockStyle.Fill
        //    };

        //    GroupsScheduleTablePanel.Controls.Add(GroupsScheduleTableLayoutPanel);
        //    GroupsScheduleTablePanelAndButtonsSeparator.Panel1.Controls.Add(GroupsScheduleTablePanel);
        //    Controls.Add(GroupsScheduleTablePanelAndButtonsSeparator);

        //    //if (WindowState != FormWindowState.Minimized)
        //    {
        //        GroupsScheduleTablePanelAndButtonsSeparator.SplitterDistance = Width - 117;
        //    }

        //    //catch
        //    {

        //    }

        //    EditMainDataButtonAndSettingsButtonSplitContainer = new()
        //    {
        //        Dock = DockStyle.Bottom,
        //        IsSplitterFixed = true,
        //        Orientation = Orientation.Horizontal,
        //        SplitterDistance = 50,
        //        SplitterWidth = 1
        //    };

        //    Button EditMainDataButton = new()
        //    {
        //        Dock = DockStyle.Fill,
        //        Text = "Изменить основные данные"
        //    };

        //    EditMainDataButton.Click += (sender, e) =>
        //    {
        //        EditMainDataWindow = new();
        //        EditMainDataWindow.Show();
        //    };

        //    Button SettingsButton = new()
        //    {
        //        Dock = DockStyle.Fill
        //    };

        //    // Создаем изображение карандаша
        //    Bitmap pencilBitmap = GraphicsClass.DrawPencil(100, 100);


        //    /*
             
        //     //GroupsScheduleTablePanel.Controls.Add(GroupsScheduleTableLayoutPanel);
        //    GroupsScheduleTablePanelAndButtonsSeparator.Panel1.Controls.Add(GroupsScheduleTablePanel);
        //    //Controls.Add(GroupsScheduleTablePanelAndButtonsSeparator);
        //    GroupsScheduleTablePanelAndButtonsSeparator.SplitterDistance = Width - 117;

        //    SplitContainer EditMainDataButtonAndSettingsButtonSplitContainer = new()
        //    {
        //        Dock = DockStyle.Bottom,
        //        IsSplitterFixed = true,
        //        Orientation = Orientation.Horizontal,
        //        SplitterDistance = 50,
        //        SplitterWidth = 1
        //    };

        //    Button EditMainDataButton = new()
        //    {
        //        Dock = DockStyle.Fill,
        //        Text = "Изменить основные данные"
        //    };

        //    EditMainDataButton.Click += (sender, e) =>
        //    {
        //        EditMainDataWindow = new();
        //        EditMainDataWindow.Show();
        //    };

        //    Button SettingsButton = new()
        //    {
        //        Size = new(500, 500)
        //        //Dock = DockStyle.Fill
        //    };

        //    // Создаем изображение карандаша
        //    Bitmap pencilBitmap = GraphicsClass.DrawGear(100, 100);
        //     */

        //    // Устанавливаем изображение как BackgroundImage для кнопки
        //    SettingsButton.BackgroundImage = pencilBitmap;

        //    // Устанавливаем режим масштабирования изображения
        //    SettingsButton.BackgroundImageLayout = ImageLayout.Stretch; // Растягивает изображение, чтобы оно заполнило кнопку


        //    EditMainDataButtonAndSettingsButtonSplitContainer.Panel1.Controls.Add(EditMainDataButton);
        //    EditMainDataButtonAndSettingsButtonSplitContainer.Panel2.Controls.Add(SettingsButton);
        //    GroupsScheduleTablePanelAndButtonsSeparator.Panel2.Controls.Add(EditMainDataButtonAndSettingsButtonSplitContainer);
        //    EditMainDataButtonAndSettingsButtonSplitContainer.Height = 201;

        //    //this.Hide();

        //    //EditGroupScheduleWindow EditGroupScheduleWindow = new("ИСП 321");
        //    ////EditGroupScheduleWindow.FormClosed += (sender, e) => UpdateSubjects();
        //    //EditGroupScheduleWindow.Show();
        //    //Environment.Exit(0);
        //    //}

        //    SetWindowDefaults();
        //}

        //// Методы //

        //// Метод установки разметки расписания групп по умолчанию

        //// TODO: 1) Модифицировать данный метод, когда можно будет управлять
        //// классными часами по понедельникам (убирать их)
        //private void SetMainWindowDefaults()
        //{
        //    SetMainWindowDefaultGridStyles();

        //    GroupsScheduleTableLayoutPanel.Controls.Add(SeparateLabel, 0, 0);
        //    GroupsScheduleTableLayoutPanel.SetColumnSpan(SeparateLabel, 3);
        //    GroupsScheduleTableLayoutPanel.SetRowSpan(SeparateLabel, 2);

        //    int RowIndex = 0;

        //    foreach (string DayOfWeek in ConstantsClass.DaysOfWeek)
        //    {
        //        LabelWithVerticalText DayOfWeekLabel = new()
        //        {
        //            BackColor = Color.LightGray,
        //            BorderStyle = BorderStyle.None,
        //            Text = DayOfWeek,
        //            Dock = DockStyle.Fill,
        //            Margin = new(1)
        //        };

        //        if (DayOfWeek == "Понедельник")
        //        {
        //            GroupsScheduleTableLayoutPanel.Controls.Add(DayOfWeekLabel, 0, RowIndex + 2);
        //            GroupsScheduleTableLayoutPanel.SetRowSpan(DayOfWeekLabel, 10); // заполнение элементом 10 соседних строк
        //            // TODO: (+ 2) из-за классного часа по понедельникам для всех
        //        }

        //        else
        //        {
        //            GroupsScheduleTableLayoutPanel.Controls.Add(DayOfWeekLabel, 0, RowIndex + 4);
        //            GroupsScheduleTableLayoutPanel.SetRowSpan(DayOfWeekLabel, 8);
        //        }

        //        // TODO: данное число не будет "ручным" - оно будет зависеть от расписания каждой группы (3 пары или 5 пар,
        //        // но пока это не нужно - у всех всегда максимум 4 пары)

        //        RowIndex += 9;
        //    }

        //    // Расчёт всей сетки //
        //    // разметка (первые 3 столбца) + [первая колонка + вторая колонка (= группа [название] = 4) + отступ после группы (+1 => *5)] - отступ после последней группы
        //    for (int ColumnIndex = 0; ColumnIndex < 3 + ConstantsClass.NumberOfGroups * 5 - 1; ColumnIndex++)
        //    {
        //        // разметка (первые 2 строки) + (В каждом дне недели * 4 пары + 1 клас. час по ПН) * 2 строки (предмет и препод. с каб.) + 5 отступов под днём недели - отступ после последнего дня недели
        //        for (RowIndex = 0; RowIndex < 2 + (ConstantsClass.NumberOfDaysOfWeek * 4 + 1) * 2 + ConstantsClass.NumberOfDaysOfWeek - 1; RowIndex++)
        //        {
        //            TextBox GroupScheduleTextBox;

        //            // Устанавливаем "пробел", а не ячейки (если это поле разметки или отступа)
        //            if (ColumnIndex == 0 || RowIndex == 1 || (ColumnIndex == 1 || ColumnIndex == 2) && RowIndex < 2 || IndentColumnIndexArray.Contains(ColumnIndex) || IndentRowIndexArray.Contains(RowIndex))
        //            {
        //                continue;
        //            }

        //            // Если уже есть разметка чётности недели
        //            else if ((OddWeekColumnIndexArray.Contains(ColumnIndex - 1) || EvenWeekColumnIndexArray.Contains(ColumnIndex - 1)) && RowIndex == 0)
        //            {
        //                continue;
        //            }

        //            // Если уже добавлена ячейка предмета (на ширину в 2 стиля)
        //            else if (SubjectAndTeacherColumnIndexesArray.Contains(ColumnIndex - 1) && SubjectRowIndexArray.Contains(RowIndex))
        //            {
        //                continue;
        //            }

        //            GroupScheduleTextBox = new()
        //            {
        //                Dock = DockStyle.Fill,
        //                Margin = new(1),
        //                Multiline = true,
        //                ReadOnly = true,
        //                TextAlign = HorizontalAlignment.Center,
        //            };

        //            // TODO: подлежит изменению
        //            //if (RowIndex == 2 && SubjectAndTeacherColumnIndexesArray.Contains(ColumnIndex))
        //            //{
        //            //    GroupScheduleTextBox.Text = "Классный час";
        //            //}

        //            if (RowIndex == 0 && OddWeekColumnIndexArray.Contains(ColumnIndex))
        //            {
        //                GroupScheduleTextBox.Text = "НЧ";
        //                GroupsScheduleTableLayoutPanel.SetColumnSpan(GroupScheduleTextBox, 2);

        //                goto CreateGroupScheduleTextBox;
        //            }

        //            else if (RowIndex == 0 && EvenWeekColumnIndexArray.Contains(ColumnIndex))
        //            {
        //                GroupScheduleTextBox.Text = "Ч";
        //                GroupsScheduleTableLayoutPanel.SetColumnSpan(GroupScheduleTextBox, 2);

        //                goto CreateGroupScheduleTextBox;
        //            }

        //            // Подпись номера и времени пары //
        //            switch (RowIndex)
        //            {
        //                case 2:

        //                    if (ColumnIndex == 1)
        //                    {
        //                        TextBoxElements.Add("09:00 - 09:45");
        //                        GroupScheduleTextBox.Text = TextBoxElements[0].ToString();

        //                        GroupsScheduleTableLayoutPanel.SetColumnSpan(GroupScheduleTextBox, 2);
        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);

        //                        goto CreateGroupScheduleTextBox;
        //                    }

        //                    break;

        //                case 4:
        //                case 13:
        //                case 22:
        //                case 31:
        //                case 40:

        //                    if (ColumnIndex == 1)
        //                    {
        //                        GroupScheduleTextBox.Text = "1";
        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);
        //                    }

        //                    else if (ColumnIndex == 2)
        //                    {
        //                        if (RowIndex == 4)
        //                        {
        //                            TextBoxElements = ConstantsClass.MondayTimeSlots.ToList();
        //                        }

        //                        else
        //                        {
        //                            TextBoxElements = ConstantsClass.StandardTimeSlots.ToList();
        //                        }

        //                        GroupScheduleTextBox.Text = TextBoxElements[0].ToString();

        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);
        //                    }

        //                    goto CreateGroupScheduleTextBox;

        //                case 6:
        //                case 15:
        //                case 24:
        //                case 33:
        //                case 42:

        //                    if (ColumnIndex == 1)
        //                    {
        //                        GroupScheduleTextBox.Text = "2";
        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);
        //                    }

        //                    else if (ColumnIndex == 2)
        //                    {
        //                        if (RowIndex == 6)
        //                        {
        //                            TextBoxElements = ConstantsClass.MondayTimeSlots.ToList();
        //                        }

        //                        else
        //                        {
        //                            TextBoxElements = ConstantsClass.StandardTimeSlots.ToList();
        //                        }

        //                        GroupScheduleTextBox.Text = TextBoxElements[1].ToString();

        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);
        //                    }

        //                    goto CreateGroupScheduleTextBox;

        //                case 8:
        //                case 17:
        //                case 26:
        //                case 35:
        //                case 44:

        //                    if (ColumnIndex == 1)
        //                    {
        //                        GroupScheduleTextBox.Text = "3";
        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);
        //                    }

        //                    else if (ColumnIndex == 2)
        //                    {
        //                        if (RowIndex == 8)
        //                        {
        //                            TextBoxElements = ConstantsClass.MondayTimeSlots.ToList();
        //                        }

        //                        else
        //                        {
        //                            TextBoxElements = ConstantsClass.StandardTimeSlots.ToList();
        //                        }

        //                        GroupScheduleTextBox.Text = TextBoxElements[2].ToString();

        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);
        //                    }

        //                    goto CreateGroupScheduleTextBox;

        //                case 10:
        //                case 19:
        //                case 28:
        //                case 37:
        //                case 46:

        //                    if (ColumnIndex == 1)
        //                    {
        //                        GroupScheduleTextBox.Text = "4";
        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);
        //                    }

        //                    else if (ColumnIndex == 2)
        //                    {
        //                        if (RowIndex == 10)
        //                        {
        //                            TextBoxElements = ConstantsClass.MondayTimeSlots.ToList();
        //                        }

        //                        else
        //                        {
        //                            TextBoxElements = ConstantsClass.StandardTimeSlots.ToList();
        //                        }

        //                        GroupScheduleTextBox.Text = TextBoxElements[3].ToString();

        //                        GroupsScheduleTableLayoutPanel.SetRowSpan(GroupScheduleTextBox, 2);
        //                    }

        //                    goto CreateGroupScheduleTextBox;
        //            }

        //            if (ColumnIndex <= 2)
        //            {
        //                continue;
        //            }

        //        CreateGroupScheduleTextBox:

        //            if ((OddWeekColumnIndexArray.Contains(ColumnIndex) || EvenWeekColumnIndexArray.Contains(ColumnIndex)) && RowIndex == 0 || SubjectAndTeacherColumnIndexesArray.Contains(ColumnIndex) && SubjectRowIndexArray.Contains(RowIndex))
        //            {
        //                GroupsScheduleTableLayoutPanel.SetColumnSpan(GroupScheduleTextBox, 2);
        //            }

        //            if (GroupScheduleTextBox.Text == string.Empty)
        //            {
        //                GroupScheduleTextBox.BackColor = Color.MistyRose;
        //            }

        //            GroupsScheduleTableLayoutPanel.Controls.Add(GroupScheduleTextBox, ColumnIndex, RowIndex);
        //        }
        //    }
        //}

        //private void SetMainWindowDefaultGridStyles()
        //{
        //    // Установка размеров SeparateLabel (нулевой стиль - его не считаем)
        //    GroupsScheduleTableLayoutPanel.ColumnStyles.Add(new(SizeType.Absolute, 50));
        //    GroupsScheduleTableLayoutPanel.RowStyles.Add(new(SizeType.Absolute, 20));

        //    // Создание ячейки под стиль № 1
        //    GroupsScheduleTableLayoutPanel.ColumnCount++;
        //    GroupsScheduleTableLayoutPanel.RowCount++;

        //    // Установка размеров для ключевых полей (номер пары и номер группы) - стиль № 1
        //    GroupsScheduleTableLayoutPanel.ColumnStyles.Add(new(SizeType.Absolute, 20));
        //    GroupsScheduleTableLayoutPanel.RowStyles.Add(new(SizeType.Absolute, 40));

        //    // Создание ячейки под стиль № 2
        //    GroupsScheduleTableLayoutPanel.ColumnCount++;

        //    // Установка размеров для ключевых полей (время пары) - стиль № 2
        //    GroupsScheduleTableLayoutPanel.ColumnStyles.Add(new(SizeType.Absolute, 85));

        //    for (int ColumnIndex = 0; ColumnIndex < ConstantsClass.NumberOfGroups * 5 - 1; ColumnIndex++)
        //    {
        //        GroupsScheduleTableLayoutPanel.ColumnCount++;

        //        // Отступ между группами
        //        if (IndentColumnIndexArray.Contains(ColumnIndex + 3))
        //        {
        //            GroupsScheduleTableLayoutPanel.ColumnStyles.Add(new(SizeType.Absolute, 10));
        //        }

        //        else
        //        {
        //            GroupsScheduleTableLayoutPanel.ColumnStyles.Add(new(SizeType.Absolute, /*100*/110));
        //        }
        //    }

        //    for (int RowIndex = 0; RowIndex < (ConstantsClass.NumberOfDaysOfWeek * 4 + 1) * 2 + ConstantsClass.NumberOfDaysOfWeek - 1; RowIndex++)
        //    {
        //        GroupsScheduleTableLayoutPanel.RowCount++;

        //        // Отступ между днями недели
        //        if (IndentRowIndexArray.Contains(RowIndex + 2))
        //        {
        //            GroupsScheduleTableLayoutPanel.RowStyles.Add(new(SizeType.Absolute, 10));
        //        }

        //        // Высота окна предмета
        //        else if (SubjectRowIndexArray.Contains(RowIndex + 2))
        //        {
        //            GroupsScheduleTableLayoutPanel.RowStyles.Add(new(SizeType.Absolute, /*50*/60));
        //        }

        //        // Высота окна преподавателя и кабинета
        //        else
        //        {
        //            GroupsScheduleTableLayoutPanel.RowStyles.Add(new(SizeType.Absolute, /*30*/40));
        //        }
        //    }
        //}

        //// Метод загрузки данных каждой группы
        //private void LoadGroupsDataAndGrid()
        //{
        //    bool DataSuccessfullyLoaded = false;
        //    int ColumnIndex = 0;
        //    object GroupListVariable;

        //    if (MainData.GroupList != null)
        //    {
        //        GroupListVariable = MainData.GroupList;
        //        DataSuccessfullyLoaded = true;
        //    }

        //    else // загрузка данных в автономном режиме
        //    {
        //        GroupListVariable = ConstantsClass.GroupNames.ToList();
        //    }

        //    if (GroupListVariable is List<string> GroupList)
        //    {
        //        //if (MainData.GroupList != null && DataSuccessfullyLoaded == true)
        //        //{
        //        //    while (GroupsScheduleTableLayoutPanel.ColumnCount - 1 != MainData.GroupList.Count * 2)
        //        //    {
        //        //        if (GroupsScheduleTableLayoutPanel.ColumnCount - 1 < MainData.GroupList.Count * 2)
        //        //        {
        //        //            GroupsScheduleTableLayoutPanel.ColumnCount++;
        //        //            GroupsScheduleTableLayoutPanel.ColumnStyles.Add(new(SizeType.Absolute, 100));
        //        //        }

        //        //        else if (GroupsScheduleTableLayoutPanel.ColumnCount - 1 > MainData.GroupList.Count * 2)
        //        //        {
        //        //            GroupsScheduleTableLayoutPanel.ColumnCount--;
        //        //            GroupsScheduleTableLayoutPanel.ColumnStyles.RemoveAt(GroupsScheduleTableLayoutPanel.ColumnStyles.Count - 1);
        //        //        }
        //        //    }
        //        //}

        //        foreach (string Group in GroupList)
        //        {
        //            GroupData = new()
        //            {
        //                GroupName = Group
        //            };

        //            GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group); // переменная загруженных данных проекта

        //            //if (GroupData.GroupName != null)
        //            {
        //                GroupDataList.Add(GroupData);
        //            }

        //            int[] array = { 1, 3, 2 };
        //            Bitmap bitmap = GraphicsClass.DrawPencil(30, 30);
        //            LabelWithButtons GroupLabelWithButtons = new(array, bitmap)
        //            {
        //                BackColor = Color.LightGray,
        //                BorderStyle = BorderStyle.None,
        //                Dock = DockStyle.Fill,
        //                Margin = new(1),
        //                Text = Group,
        //                TextAlign = ContentAlignment.MiddleCenter
        //            };

        //            LabelWithButtons.ClickHandler? AddButtonClickHandler = null;
        //            LabelWithButtons.ClickHandler? CustomButtonClickHandler = null;

        //            AddButtonClickHandler = (sender, e) =>
        //            {
        //                EditGroupScheduleWindow EditGroupScheduleWindow = new(string.Empty)
        //                {
        //                    GroupInTitle = Group,
        //                    Text = $"«Электронный редактор расписания» — Окно редактирования расписания группы ({Group})"
        //                };

        //                // Подписка на событие изменения данных
        //                EditGroupScheduleWindow.OnDataChanged += () =>
        //                {
        //                    GroupData.GroupName = Group;
        //                    GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group);
        //                    LoadGroupSchedule(GroupData, GroupLabelWithButtons);
        //                };

        //                EditGroupScheduleWindow.FormClosed += (sender, e) =>
        //                {
        //                    //GroupData.GroupName = Group;
        //                    //GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group);
        //                    //LoadGroupSchedule(GroupData, GroupLabelWithButtons);
        //                    GroupLabelWithButtons.AddButtonClick += AddButtonClickHandler;
        //                    GroupLabelWithButtons.CustomButtonClick += CustomButtonClickHandler;
        //                };

        //                GroupLabelWithButtons.AddButtonClick -= AddButtonClickHandler;
        //                GroupLabelWithButtons.CustomButtonClick -= CustomButtonClickHandler;
        //                EditGroupScheduleWindow.Show();
        //            };

        //            CustomButtonClickHandler += (sender, e) =>
        //            {
        //                EditGroupScheduleWindow EditGroupScheduleWindow = new(Group);

        //                // Подписка на событие изменения данных
        //                EditGroupScheduleWindow.OnDataChanged += () =>
        //                {
        //                    GroupData.GroupName = Group;
        //                    GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group);
        //                    LoadGroupSchedule(GroupData, GroupLabelWithButtons);
        //                };

        //                EditGroupScheduleWindow.FormClosed += (sender, e) =>
        //                {
        //                    //GroupData.GroupName = Group;
        //                    //GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group);
        //                    //LoadGroupSchedule(GroupData, GroupLabelWithButtons);
        //                    GroupLabelWithButtons.CustomButtonClick += CustomButtonClickHandler;
        //                    GroupLabelWithButtons.AddButtonClick += AddButtonClickHandler;
        //                };

        //                GroupLabelWithButtons.CustomButtonClick -= CustomButtonClickHandler;
        //                GroupLabelWithButtons.AddButtonClick -= AddButtonClickHandler;
        //                EditGroupScheduleWindow.Show();
        //            };

        //            if (DataSuccessfullyLoaded)
        //            {
        //                GroupLabelWithButtons.AddButtonClick += AddButtonClickHandler;
        //                GroupLabelWithButtons.CustomButtonClick += CustomButtonClickHandler;
        //            }

        //            else
        //            {
        //                // TODO: в случае незагрузки данных убрать кнопку редакции
        //                LabelWithButtons.ClickHandler? AddButtonClickHandlerWithoutMainData = null;

        //                AddButtonClickHandlerWithoutMainData = (sender, e) =>
        //                {
        //                    DialogResult = MessageBox.Show("Внимание, данные не были загружены, вы не сможете сохранить данные для группы. Будет загружен пустой макет.\n\nВы уверены, что хотите продолжить?", "Работа без данных", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);

        //                    if (DialogResult == DialogResult.Yes)
        //                    {
        //                        EditGroupScheduleWindow EditGroupScheduleWindow = new(Group);

        //                        EditGroupScheduleWindow.FormClosed += (sender, e) =>
        //                        {
        //                            GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>();
        //                            LoadGroupSchedule(GroupData, GroupLabelWithButtons);
        //                            GroupLabelWithButtons.AddButtonClick += AddButtonClickHandlerWithoutMainData;
        //                        };

        //                        GroupLabelWithButtons.AddButtonClick -= AddButtonClickHandlerWithoutMainData;
        //                        EditGroupScheduleWindow.Show();
        //                    }
        //                };

        //                GroupLabelWithButtons.AddButtonClick += AddButtonClickHandlerWithoutMainData;
        //            }

        //            // TODO: Понять, зачем оно
        //            //Control? DefaultGroupLabelWithButtonsControl = null;

        //            //if (GroupsScheduleTableLayoutPanel.GetControlFromPosition(ColumnIndex + 3, 1) != null)
        //            //{
        //            //    DefaultGroupLabelWithButtonsControl = GroupsScheduleTableLayoutPanel.GetControlFromPosition(ColumnIndex + 3, 1);
        //            //    GroupsScheduleTableLayoutPanel.Controls.Remove(DefaultGroupLabelWithButtonsControl);
        //            //}

        //            GroupsScheduleTableLayoutPanel.Controls.Add(GroupLabelWithButtons, ColumnIndex + 3, 1);
        //            GroupsScheduleTableLayoutPanel.SetColumnSpan(GroupLabelWithButtons, 4);

        //            ColumnIndex += 5;
        //        }
        //    }
        //}

        //private void ErrorProvider()
        //{
        //    //MainData.LoadData<MainDataClass>();

        //    if (MainData.ErrorMessage != null)
        //    {
        //        MessageBox.Show(MainData.ErrorMessage + "\n\nВнимание, основные данные не были загружены!", "Файл хранимых данных повреждён!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }

        //    string ErrorMessageMainPart = string.Empty;
        //    List<string> GroupFileWithErrorList = new();

        //    IEnumerator<string>? MainDataGroupListEnumerator = null;

        //    if (MainData.GroupList != null)
        //    {
        //        MainDataGroupListEnumerator = MainData.GroupList.GetEnumerator();
        //    }

        //    else
        //    {
        //        MessageBox.Show("Внимание, невозможно проверить на корректность файлы хранимых данных групп, поскольку файл хранимых основных данных повреждён!", "Ошибка анализа файлов хранимых данных групп!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }

        //    foreach (GroupDataClass GroupData in GroupDataList)
        //    {
        //        if (MainDataGroupListEnumerator != null)
        //        {
        //            MainDataGroupListEnumerator.MoveNext();
        //            GroupData.GroupName = MainDataGroupListEnumerator.Current;
        //            //GroupData.LoadData<GroupDataClass>();

        //            if (GroupData.ErrorMessage != null)
        //            {
        //                GroupFileWithErrorList.Add($"{GroupData.GroupName}");
        //                ErrorMessageMainPart = $"Внимание! Количество повреждённых файлов: {GroupFileWithErrorList.Count}.\n\nБыли повреждены следующие файлы хранимых данных групп:";
        //            }
        //        }
        //    }

        //    if (ErrorMessageMainPart != string.Empty)
        //    {
        //        string NumberedGroupFilesWithError = string.Empty;

        //        for (int i = 0; i < GroupFileWithErrorList.Count; i++)
        //        {
        //            if (i != GroupFileWithErrorList.Count - 1)
        //            {
        //                NumberedGroupFilesWithError += $"{i + 1}) {GroupFileWithErrorList[i]};\n";
        //            }

        //            else
        //            {
        //                NumberedGroupFilesWithError += $"{i + 1}) {GroupFileWithErrorList[i]}.";
        //            }
        //        }

        //        MessageBox.Show($"{ErrorMessageMainPart}\n\n{NumberedGroupFilesWithError}", "Файлы хранимых данных групп повреждены!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        //}

        //private void LoadGroupSchedule(GroupDataClass GroupData, LabelWithButtons? GroupLabelWithButtons)
        //{
        //    if (GroupData.GroupName == null)
        //    {
        //        return;
        //    }
        //    //GroupData.GroupName = Group;
        //    //GroupData = new();
        //    //GroupData.GroupName = Group;
        //    //GroupData = GroupData.LoadData<GroupDataClass>();

        //    if (GroupData./*MainWindow*/DockableComboBoxesInfoList != null)
        //    {
        //        GroupTextBoxesInfoList = GroupData./*MainWindow*/DockableComboBoxesInfoList.ToList();
        //    }

        //    // TODO: если в сохранённых данных нет сведений о "" - то есть если в списке группы не была назначена
        //    // 4-я пара - не было сохранено это, то нумерация сбивается (ведь "" и отсутствие данных отличается!)

        //    TableLayoutPanelCellPosition CurrentGroupLabelWithButtonsPosition = new();

        //    if (GroupLabelWithButtons != null)
        //    {
        //        CurrentGroupLabelWithButtonsPosition = GroupsScheduleTableLayoutPanel.GetPositionFromControl(GroupLabelWithButtons);
        //    }

        //    else
        //    {
        //        foreach (Control Control in GroupsScheduleTableLayoutPanel.Controls)
        //        {
        //            if (Control.Text == GroupData?.GroupName)
        //            {
        //                Control? CurrentGroupLabelWithButtons = Control;
        //                CurrentGroupLabelWithButtonsPosition = GroupsScheduleTableLayoutPanel.GetPositionFromControl(CurrentGroupLabelWithButtons);

        //                break;
        //            }
        //        }
        //    }

        //    //System.ArgumentNullException!!!
        //    //ElementPosition = GroupsScheduleTableLayoutPanel.GetCellPosition(SerachingControl);
        //    //DockableComboBoxDay = GroupScheduleEditorTableLayoutPanel.GetControlFromPosition(ElementPosition.Column, 0).Text;

        //    foreach ((int Column, int Row, string Day, string Week, string Text) in GroupTextBoxesInfoList)
        //    {
        //        if (Text == "")
        //        {
        //            continue;
        //        }

        //        // Получаем контрол из позиции
        //        Control? Control = null;
        //        switch (Day)
        //        {
        //            case "Понедельник":

        //                if (Week == "НЧ")
        //                {
        //                    if (Row == 3 || Row % 4 == 3)
        //                    {
        //                        if (Column % 2 != 0)
        //                        {
        //                            Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column, Row - 1);
        //                        }

        //                        else if (Column % 2 == 0)
        //                        {
        //                            Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 1, Row);
        //                        }
        //                    }

        //                    else if (Row == 4 || Row % 4 == 4)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column, Row - 1);
        //                    }
        //                }

        //                else
        //                {
        //                    if (Row == 3 || Row % 4 == 3)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 3, Row + 1);
        //                    }

        //                    else if (Row == 4 || Row % 4 == 4)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 2, Row + 1);
        //                    }
        //                }

        //                break;

        //            case "Вторник":

        //                if (Week == "НЧ")
        //                {
        //                    if (Row == 3 || Row % 4 == 3)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 1, Row + 12);
        //                    }

        //                    else if (Row == 4 || Row % 4 == 4)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column, Row + 11);
        //                    }
        //                }

        //                else
        //                {
        //                    if (Row == 3 || Row % 4 == 3)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 3, Row + 12);
        //                    }

        //                    else if (Row == 4 || Row % 4 == 4)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 2, Row + 11);
        //                    }
        //                }

        //                break;

        //            case "Среда":
        //            case "Четверг":
        //            case "Пятница":

        //                if (Week == "НЧ")
        //                {
        //                    if (Row == 3 || Row % 4 == 3)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 1, Row + 10);
        //                    }

        //                    else if (Row == 4 || Row % 4 == 4)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column, Row + 9);
        //                    }
        //                }

        //                else
        //                {
        //                    if (Row == 3 || Row % 4 == 3)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 3, Row + 10);
        //                    }

        //                    else if (Row == 4 || Row % 4 == 4)
        //                    {
        //                        Control = GroupsScheduleTableLayoutPanel.GetControlFromPosition(CurrentGroupLabelWithButtonsPosition.Column + 2, Row + 9);
        //                    }
        //                }

        //                break;
        //        }

        //        if (Control != null)
        //        {
        //            Control.Text = Text;
        //            Control.BackColor = Color.White;
        //        }
        //    }
        //}

        //private void SetWindowDefaults()
        //{
        //    //Shown += (sender, e) =>
        //    //{
        //    //    GroupsScheduleTablePanel.HorizontalScroll.Value = 0;
        //    //    GroupsScheduleTablePanel.VerticalScroll.Value = 0;
        //    //};

        //    int ColumnWidthSum = 40 + GroupsScheduleTableLayoutPanel.Margin.Left + GroupsScheduleTableLayoutPanel.Margin.Right + EditMainDataButtonAndSettingsButtonSplitContainer.Width;
        //    int RowHeightSum = 60 + GroupsScheduleTableLayoutPanel.Margin.Top + GroupsScheduleTableLayoutPanel.Margin.Bottom;

        //    for (int i = 0; i < 12 && i < GroupsScheduleTableLayoutPanel.ColumnStyles.Count; i++)
        //    {
        //        ColumnWidthSum += Convert.ToInt16(GroupsScheduleTableLayoutPanel.ColumnStyles[i].Width);

        //        if (i == 6)
        //        {
        //            MinimumSize = new(ColumnWidthSum, 0);
        //        }
        //    }

        //    for (int i = 0; i < 12 && i < GroupsScheduleTableLayoutPanel.RowStyles.Count; i++)
        //    {
        //        RowHeightSum += Convert.ToInt16(GroupsScheduleTableLayoutPanel.RowStyles[i].Height);
        //    }

        //    MinimumSize = new(MinimumSize.Width, RowHeightSum);

        //    Size = new(ColumnWidthSum, RowHeightSum);

        //    int PositionX = 0;
        //    int PositionY = 0;

        //    // Рассчитываем новые координаты для центрирования формы на экране
        //    if (Screen.PrimaryScreen != null)
        //    {
        //        PositionX = Screen.PrimaryScreen.Bounds.Width / 2 - Width / 2;
        //        PositionY = Screen.PrimaryScreen.Bounds.Height / 2 - Height / 2;
        //    }

        //    // Устанавливаем новое положение формы
        //    Location = new(PositionX, PositionY);
        //}
    }
}