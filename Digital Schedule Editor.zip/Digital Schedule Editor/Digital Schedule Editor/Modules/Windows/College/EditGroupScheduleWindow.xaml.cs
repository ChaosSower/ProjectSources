﻿/* TODO: сделать программное добавление/удаление второго столбца таблицы (если чекбокс на особый понедельник не стоит,
то и время не нужно -> и столбец)*/

// TODO: реализовать ручное ограничение кол-ва часов в неделю -> на EditMainDataWindow
// TODO: разрешить автоподбор в поиске по названию дисциплины (и её сокращению (ОКФКС)) или преподавателю (наработки из BeautySalon)
// TODO: разрешить drag n' drop
// TODO: разрешить мультивыделение и мультивставку значения (как в excel)
// TODO: разрешить мультиввод (ctrl + alt) как в Visual Studio
// TODO: понять, как сделать объединение нечётной/чётной пары ячеек (как в excel) ->
// пара 4 (деление по ч/нч дням) + статистика (добавить нч/ч в TextBox)
// многопоточность - https://www.codeproject.com/Questions/1195460/Windows-form-is-freezing-when-trying-to-update-use
// https://www.c-sharpcorner.com/UploadFile/27c648/making-a-simple-non-freezing-window-forms-application/
// https://grantwinney.com/using-async-await-and-task-to-keep-the-winforms-ui-more-responsive/

//https://bureau.ru/bb/soviet/20110323/
//https://rector.spb.ru/rector3/manual/eloadd.html
//https://rasp.rea.ru/?q=15.26%D0%B4-%D0%B3%D0%B401%D0%B0%2F22%D0%B1
//https://lks.bmstu.ru/schedule/83573a78-b8ff-11ed-a3ad-272ac9bbc1e7
//https://help.syncfusion.com/cr/windowsforms/Syncfusion.Windows.Forms.Tools.TextBoxExt.html
//https://metanit.com/sharp/wpf/5.3.php

// TODO: вывести сообщение при сохранении расписания с новыми данными: "Добавить введённые вами новые данные в основные данные?"
// (задача максимум - показать также список этих данных - предметы:... преподаватели:...)
// TODO: при сохранении расписания объединять автоматически НЧ и Ч недели, если Ч недели не востребованы (пусты и занимают место) - только
// при включении соответствующего параметра в настройках

using System.Data;
using System.Text.RegularExpressions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Collections.ObjectModel;

using Digital_Schedule_Editor.Classes;
using Digital_Schedule_Editor.Classes.AbstractClasses;
using Digital_Schedule_Editor.Classes.SerializingClasses;
using Digital_Schedule_Editor.Controls.CustomControls;
using Digital_Schedule_Editor.Extensions.CommonComponents;
using Digital_Schedule_Editor.Modules.Windows.Common;
using Digital_Schedule_Editor.Controls.StaticControls;
using static Digital_Schedule_Editor.Controls.CustomControls.SeparateLabelClass;
using static Digital_Schedule_Editor.Classes.LessonClass;
using Digital_Schedule_Editor.Controls.CustomControls.EditGroupScheduleWindowControls;

namespace Digital_Schedule_Editor.Modules.Windows.College
{
    /// <summary>
    /// Логика окна редактирования расписания группы EditGroupScheduleWindow.xaml
    /// </summary>
    public partial class EditGroupScheduleWindow : Window
    {
        // Переменные хранимых данных проекта //
        public MainDataClass MainData;
        private GroupDataClass GroupData;
        private readonly bool IsDataRecreating;

        private int GroupScheduleTableLayoutGridCurrentMaxRowIndex;
        public int NumberOfLessonIndex = 0;
        private MessageBoxResult MessageBoxResult;

        private readonly SeparateLabelWithButtons SeparateLabelWithButtons;

        //private List<string>? ComboBoxElements;
        private readonly bool SetHomeroomsOnMondays;
        public string GroupInTitle = string.Empty;
        private bool ChangesHasBeenMade;
        public static Action? ChangesHasBeenMadeAction;

        private readonly Dictionary<string, (List<(string OddWeekSubject, int OddWeekSubjectHours)>, List<(string EvenWeekSubject, int EvenWeekSubjectHours)>?)> GroupSubjectsDictionary = new();

        private List<(int Column, int Row, string Day, string Week, string Text)>? ComboBoxesInfoList;
        private List<(int Column, int Row, string Day, string Week, string Text)>? MainWindowComboBoxesInfoList;

        // Списки предметов для каждой недели со всеми дисциплинами и их часами
        //private (List<(string OddSubject, float OddHours)>, List<(string EvenSubject, float EvenHours)>) SubjectsPerMondayList = new();
        //private (List<(string OddSubject, float OddHours)>, List<(string EvenSubject, float EvenHours)>) SubjectsPerTuesdayList = new();
        //private (List<(string OddSubject, float OddHours)>, List<(string EvenSubject, float EvenHours)>) SubjectsPerWednesdayList = new();
        //private (List<(string OddSubject, float OddHours)>, List<(string EvenSubject, float EvenHours)>) SubjectsPerThursdayList = new();
        //private (List<(string OddSubject, float OddHours)>, List<(string EvenSubject, float EvenHours)>) SubjectsPerFridayList = new();
        //private List<(string, (List<(string OddSubject, float OddHours)>, List<(string EvenSubject, float EvenHours)>))> SubjectsPerWeekDayList = new();
        //public List<(string, List<(string, (List<(string OddSubject, float OddHours)>, List<(string EvenSubject, float EvenHours)>))>)>? GroupsSubjectsPerWeekDayList;

        private readonly List<(string Subject, float Hours)> SubjectsPerMondayList = new();
        private readonly List<(string Subject, float Hours)> SubjectsPerTuesdayList = new();
        private readonly List<(string Subject, float Hours)> SubjectsPerWednesdayList = new();
        private readonly List<(string Subject, float Hours)> SubjectsPerThursdayList = new();
        private readonly List<(string Subject, float Hours)> SubjectsPerFridayList = new();
        private readonly List<(string DayOfWeek, List<(string Subject, float Hours)>)> SubjectsPerWeekDayList = new();

        private List<string>? CurrentSubjectList;
        private List<string>? CurrentTeacherList;
        private List<string>? CurrentClassroomList;
        private List<(string Subject, string Teacher)>? CurrentSubjectAndTeacherList = new();
        private List<(string Subject, string Classroom)>? CurrentSubjectAndClassroomList = new();
        private List<(string Teacher, string Classroom)>? CurrentTeacherAndClassroomList = new();

        private bool? DisableMappingWithDatabase = null;

        private readonly List<LessonsControl> Lessons = new();

        public EditGroupScheduleWindow(string Group)
        {
            InitializeComponent();

            SaveChangesButton.IsEnabled = false;
            SaveChangesButton.Foreground = Brushes.Gray;

            ChangesHasBeenMadeAction += () =>
            {
                ChangesHasBeenMade = true;
                SaveChangesButton.IsEnabled = true;
                SaveChangesButton.Foreground = Brushes.White;
            };

            Closing += (sender, e) =>
            {
                if (ChangesHasBeenMade)
                {
                    MessageBoxResult MessageBoxResult = MessageBox.Show("Вы внесли изменения, но не сохранили их!\nВы уверены, что закрыть окно группы без сохранения?", string.Empty, MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);

                    if (MessageBoxResult == MessageBoxResult.No)
                    {
                        e.Cancel = true;
                    }
                }
            };

            Title += $" ({Group})";

            SeparateLabelWithButtons = new()
            {
                //DiagonalFromTopLeftToBottomRight = true,
                LeftLabelFontSize = 11,
                RightLabelFontSize = 12,
                RightTriangleBrush = Brushes.LightSteelBlue,
                RightLabelTextBrush = Brushes.Black,
                LeftLabelText = "№ пары",
                RightLabelText = "Пара",
                LeftLabelFontFamily = new("Segoe UI"),
                RightLabelFontFamily = new("Segoe UI"),
                //BorderStyle = BorderStyle.None,
                //BorderBrush = null,
                Margin = new(1),
                NumberOfButtons = 2
            };

            Border SeparateLabelWithButtonsBorder = new()
            {
                BorderBrush = Brushes.Black,
                BorderThickness = new(1),
                Child = SeparateLabelWithButtons
            };

            SeparateLabelWithButtonsBorder.SetValue(Grid.ColumnProperty, 0);
            SeparateLabelWithButtonsBorder.SetValue(Grid.RowProperty, 0);
            GroupScheduleEditorTableLayoutGrid.Children.Add(SeparateLabelWithButtonsBorder); // Параметры: контрол, столбец, строка

            SeparateLabelWithButtons.AddButtonClick += ВКонецToolStripMenuItem_Click;
            SeparateLabelWithButtons.DeleteButtonClick += ВКонцеToolStripMenuItem1_Click;

            if (Group != string.Empty)
            {
                GroupInTitle = Group;
            }

            MainData = LoadData<MainDataClass>();

            CurrentSubjectList = MainData.SubjectList;
            CurrentTeacherList = MainData.TeacherList;
            CurrentClassroomList = MainData.ClassroomList;
            CurrentSubjectAndTeacherList = MainData.SubjectAndTeacherList;
            CurrentSubjectAndClassroomList = MainData.SubjectAndClassroomList;
            CurrentTeacherAndClassroomList = MainData.TeacherAndClassroomList;

            // Подписка на событие изменения данных
            EditMainDataWindow.OnDataChanged += () =>
            {
                MainData = LoadData<MainDataClass>();
            };

            GroupData = new()
            {
                GroupName = Group
            };

            GroupData = LoadData<GroupDataClass>(Group);

            if (GroupData.GroupName == null)
            {
                GroupData.GroupName = Group;
            }

            SettingsWindow? SettingsWindow = new();
            SetHomeroomsOnMondays = SettingsWindow.SetHomeroomsOnMondays;
            SettingsWindow = null;

            //// Воссоздание строк по существующим данным
            //if (GroupData.ComboBoxesInfoList != null && GroupData.ComboBoxesInfoList.Count != 0)
            //{
            //    ComboBoxesInfoList = GroupData.ComboBoxesInfoList.ToList();

            //    if (ComboBoxesInfoList != default)
            //    {
            //        int MaxColumnIndex = ComboBoxesInfoList.Max(ComboBoxesInfoListItem => ComboBoxesInfoListItem.Column);
            //        int MaxRowIndex = ComboBoxesInfoList.Max(ComboBoxesInfoListItem => ComboBoxesInfoListItem.Row);

            //        if (MaxRowIndex < 4)
            //        {
            //            ВКонецToolStripMenuItem_Click(this, EventArgs.Empty);
            //        }

            //        else
            //        {
            //            for (int i = 0; i < MaxRowIndex / 4; i++)
            //            {
            //                ВКонецToolStripMenuItem_Click(this, EventArgs.Empty);
            //            }
            //        }

            //        IsDataRecreating = true;

            //        foreach ((int Column, int Row, string Day, string Week, string Text) in ComboBoxesInfoList)
            //        {
            //            // Получаем контрол из позиции
            //            Control? Control = GroupScheduleEditorTableLayoutGrid.Children.OfType<Control>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == Column && Grid.GetRow(ChildControl) == Row);

            //            // Проверяем, является ли контрол ComboBox
            //            if (Control is ComboBox ComboBox)
            //            {
            //                // Устанавливаем текст
            //                ComboBox.Text = Text;
            //            }
            //        }

            //        IsDataRecreating = false;
            //    }
            //}

            //else
            {
                if (SetHomeroomsOnMondays)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        ВКонецToolStripMenuItem_Click(this, EventArgs.Empty);
                    }
                }

                else
                {
                    for (int i = 0; i < 4; i++)
                    {
                        ВКонецToolStripMenuItem_Click(this, EventArgs.Empty);
                    }
                }
            }

            GroupScheduleTableLayoutGridCurrentMaxRowIndex = GroupScheduleEditorTableLayoutGrid.RowDefinitions.Count - 1;

            //GroupScheduleEditorTableLayoutPanel.ColumnStyles[0].Width = 200; // Новая ширина в пикселях
            //GroupScheduleEditorTableLayoutPanel.RowStyles[0].Height += 10; // Новая ширина в пикселях
            //GroupScheduleEditorTableLayoutPanel.Height += 10;

            SetWindowDefaults();

            if (GroupData.ComboBoxesInfoList != null /*&& GroupData.SubjectsPerWeekDayList.Count != 0*/)
            {
                //// Наполнение списков предметов для каждой недели всеми дисциплинами и их часами
                //foreach ((string GruopName, List<(string WeekDay, List<(string Subject, float SubjectHours)>)>) GroupSubjectsPerWeekDayList in CurrentData.GroupsSubjectsPerWeekDayList.Where(x => x.Item1 == GroupInTitle))
                //{
                //    foreach ((string WeekDay, List<(string Subject, float SubjectHours)> SubjectAndHourList) SubjectsPerWeekDayList in GroupSubjectsPerWeekDayList.Item2)
                //    {
                //        switch (SubjectsPerWeekDayList.WeekDay)
                //        {
                //            case "Понедельник":

                //                foreach ((string Subject, float SubjectHours) in SubjectsPerWeekDayList.SubjectAndHourList)
                //                {
                //                    SubjectsPerMondayList.Add((Subject, SubjectHours));
                //                }

                //                break;

                //            case "Вторник":

                //                foreach ((string Subject, float SubjectHours) in SubjectsPerWeekDayList.SubjectAndHourList)
                //                {
                //                    SubjectsPerMondayList.Add((Subject, SubjectHours));
                //                }

                //                break;

                //            case "Среда":

                //                foreach ((string Subject, float SubjectHours) in SubjectsPerWeekDayList.SubjectAndHourList)
                //                {
                //                    SubjectsPerMondayList.Add((Subject, SubjectHours));
                //                }

                //                break;

                //            case "Четверг":

                //                foreach ((string Subject, float SubjectHours) in SubjectsPerWeekDayList.SubjectAndHourList)
                //                {
                //                    SubjectsPerMondayList.Add((Subject, SubjectHours));
                //                }

                //                break;

                //            case "Пятница":

                //                foreach ((string Subject, float SubjectHours) in SubjectsPerWeekDayList.SubjectAndHourList)
                //                {
                //                    SubjectsPerMondayList.Add((Subject, SubjectHours));
                //                }

                //                break;
                //        }
                //    }
                //}

                // TODO: оптимизировать -> раскомментировать строку в SaveData, но здесь каждому отсутствующему предмету присваивать часы = 0
                //SubjectsPerWeekDayList = GroupData.SubjectsPerWeekDayList.ToList();

                if (SubjectsPerWeekDayList != default)
                {
                    // Список с днями недели, а также с текстом дисциплин и их часами
                    List<(string, string?)> SubjectsAndHoursPerWeekList = new()
                    {
                        { ("Понедельник", null) },
                        { ("Вторник", null) },
                        { ("Среда", null) },
                        { ("Четверг", null) },
                        { ("Пятница", null) }
                    };

                    int i = 1;
                    string LabelOriginalText = "1) Количество распределений на неделю:\r\n\r\n1. Общее количество часов дисциплин - [0] ч / 36 ч\r\n\r\n2. Количество распределённых дисциплин:\r\n\r\n2) Количество распределений по дням:\r\n\r\n1. Понедельник - [0] ч:\r\n\r\n2. Вторник - [0] ч:\r\n\r\n3. Среда - [0] ч:\r\n\r\n4. Четверг - [0] ч:\r\n\r\n5. Пятница - [0] ч:\r\n";
                    //WeekInfoOfGroupTextBlock.Text = LabelOriginalText;

                    foreach ((string, List<(string, float)>) SubjectPerWeekDayList in SubjectsPerWeekDayList)
                    {
                        float TotalHoursPerDay = 0;
                        string? SubjectText = null;

                        foreach ((string, float) SubjectPerWeekDay in SubjectPerWeekDayList.Item2)
                        {
                            TotalHoursPerDay += SubjectPerWeekDay.Item2;

                            if (SubjectPerWeekDay.Item2 > 0)
                            {
                                SubjectText += $"\r\n{SubjectPerWeekDay.Item1} - {SubjectPerWeekDay.Item2} ч";
                            }
                        }

                        //ReplaceNthOccurrence(WeekInfoOfGroupTextBlock, i + 1, TotalHoursPerDay.ToString()); // заменяет общее часы для дня недели

                        if (SubjectText != null)
                        {
                            SubjectsAndHoursPerWeekList[i - 1] = (SubjectsPerWeekDayList[i - 1].Item1, SubjectText);

                            //InsertAfterNthOccurrence(WeekInfoOfGroupTextBlock, i + 1, "\r\n" + SubjectsAndHoursPerWeekList[i - 1].Item2, 3);
                        }

                        i++;
                    }

                    float TotalSubjectHoursPerWeek = 0;

                    foreach ((string, List<(string, float)>) SubjectPerWeekDayList in SubjectsPerWeekDayList)
                    {
                        foreach ((string, float) SubjectPerWeekDay in SubjectPerWeekDayList.Item2)
                        {
                            TotalSubjectHoursPerWeek += SubjectPerWeekDay.Item2;
                        }
                    }

                    //ReplaceNthOccurrence(WeekInfoOfGroupTextBlock, 1, TotalSubjectHoursPerWeek.ToString()); // заменяет общую сумму часов
                }

                else
                {
                    ////SubjectsPerMondayList = new();
                    ////SubjectsPerTuesdayList = new();
                    ////SubjectsPerWednesdayList = new();
                    ////SubjectsPerThursdayList = new();
                    ////SubjectsPerFridayList = new();
                    ////SubjectsPerWeekDayList = new();
                    ////ComboBoxesInfoList = new();

                    // Наполнение списков предметов для каждой недели всеми дисциплинами и их часами
                    if (MainData.SubjectList != null)
                    {
                        foreach (string Subject in MainData.SubjectList)
                        {
                            SubjectsPerMondayList.Add((Subject, 0));
                            SubjectsPerTuesdayList.Add((Subject, 0));
                            SubjectsPerWednesdayList.Add((Subject, 0));
                            SubjectsPerThursdayList.Add((Subject, 0));
                            SubjectsPerFridayList.Add((Subject, 0));
                        }
                    }

                    // Наполнение итогового списка предметов списками дисциплин и их часов для каждого дня недели
                    SubjectsPerWeekDayList?.Add(("Понедельник", SubjectsPerMondayList));
                    SubjectsPerWeekDayList?.Add(("Вторник", SubjectsPerTuesdayList));
                    SubjectsPerWeekDayList?.Add(("Среда", SubjectsPerWednesdayList));
                    SubjectsPerWeekDayList?.Add(("Четверг", SubjectsPerThursdayList));
                    SubjectsPerWeekDayList?.Add(("Пятница", SubjectsPerFridayList));
                }
            }

            else
            {
                if (MainData.SubjectList != null)
                {
                    // Наполнение списков предметов для каждой недели всеми дисциплинами и их часами
                    foreach (string Subject in MainData.SubjectList)
                    {
                        SubjectsPerMondayList.Add((Subject, 0));
                        SubjectsPerTuesdayList.Add((Subject, 0));
                        SubjectsPerWednesdayList.Add((Subject, 0));
                        SubjectsPerThursdayList.Add((Subject, 0));
                        SubjectsPerFridayList.Add((Subject, 0));
                    }
                }

                // Наполнение итогового списка предметов списками дисциплин и их часов для каждого дня недели
                SubjectsPerWeekDayList.Add(("Понедельник", SubjectsPerMondayList));
                SubjectsPerWeekDayList.Add(("Вторник", SubjectsPerTuesdayList));
                SubjectsPerWeekDayList.Add(("Среда", SubjectsPerWednesdayList));
                SubjectsPerWeekDayList.Add(("Четверг", SubjectsPerThursdayList));
                SubjectsPerWeekDayList.Add(("Пятница", SubjectsPerFridayList));
            }

            // [Отладка] //
            //List<string> subjects = new List<string>();

            //foreach (var pair in SubjectsPerWeekDayList)
            //{
            //    subjects.Add($"{pair.Item1} - {pair.Item2.Count}");
            //}

            //string result = string.Join("\n", subjects);

            //MessageBox.Show(result);
        }

        private void SetWindowDefaults()
        {
            //Shown += (sender, e) =>
            //{
            //    flowLayoutPanel1.HorizontalScroll.Value = 0;
            //    flowLayoutPanel1.VerticalScroll.Value = 0;
            //};

            int ColumnWidthSum = 25;
            int RowHeightSum = 50 /*+ (int)SpecialRuleForMondayCheckBox.ActualHeight*/ /*SpecialRuleForLessonsCheckBoxesSplitContainer.Height + SpecialRuleForLessonsCheckBoxesSplitContainer.Margin.Top + SpecialRuleForLessonsCheckBoxesSplitContainer.Margin.Bottom*/;

            for (int i = 0; i < 9 && i < GroupScheduleEditorTableLayoutGrid.ColumnDefinitions.Count; i++)
            {
                ColumnWidthSum += (int)GroupScheduleEditorTableLayoutGrid.ColumnDefinitions[i].Width.Value;

                if (i == 4)
                {
                    MinWidth = ColumnWidthSum;
                }
            }

            //for (int i = 0; i < GroupScheduleEditorTableLayoutPanel.RowStyles.Count; i++)
            //{
            //    Control? Control = GroupScheduleEditorTableLayoutPanel.GetControlFromPosition(1, i);

            //    if (Control != null)
            //    {
            //        RowHeightSum += Control.Height;
            //    }
            //}

            RowHeightSum += (int)GroupScheduleEditorTableLayoutGrid.ActualHeight;

            MinHeight = RowHeightSum;

            Width = /*ColumnWidthSum*/1000;
            Height = /*RowHeightSum*/750;

            // Рассчитываем новые координаты для центрирования формы на экране

            // Устанавливаем новое положение формы
            Left = SystemParameters.PrimaryScreenWidth / 2 - Width / 2;
            Top = SystemParameters.PrimaryScreenHeight / 2 - Height / 2;
        }

        // TODO: переделать в общие методы, а не тут???
        public static T LoadData<T>(string? GroupName = null) where T : new()
        {
            XMLSerializingDataClass? SerializingDataClass = new T() as XMLSerializingDataClass;

            (T, bool) LoadedData = new();

            if (SerializingDataClass != null)
            {
                if (SerializingDataClass is GroupDataClass GroupDataClass)
                {
                    GroupDataClass.GroupName = GroupName;
                    LoadedData = GroupDataClass.LoadData<T>();
                }

                else
                {
                    LoadedData = SerializingDataClass.LoadData<T>();
                }

                if (LoadedData.Item2 == false)
                {
                    if (SerializingDataClass?.ErrorMessage != null)
                    {
                        if (SerializingDataClass is MainDataClass)
                        {
                            MessageBox.Show("Внимание, документ хранения основных данных был повреждён!", "Ошибка загрузки основных данных", MessageBoxButton.OK, MessageBoxImage.Error);
                        }

                        else if (SerializingDataClass is GroupDataClass)
                        {
                            MessageBox.Show($"Внимание, документ хранения данных группы [{GroupName}] был повреждён!", $"Ошибка загрузки данных группы [{GroupName}]", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }

                    // TODO: сделать не MessageBox, а в виде предупреждающего окна в углу приложения (значок предупреждения), исчезающего спустя несколько секунд
                    else
                    {
                        //if (SerializingDataClass is MainDataClass)
                        //{
                        //    MessageBox.Show("Внимание, не удалось загрузить основные данные!", "Ошибка загрузки основных данных", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //}

                        //else if (SerializingDataClass is GroupDataClass)
                        //{
                        //    MessageBox.Show($"Внимание, не удалось загрузить данные группы [{GroupInTitle}]!", $"Ошибка загрузки основных данных группы [{GroupInTitle}]", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        //}
                    }
                }
            }

            return LoadedData.Item1;
        }

        //Событие добавления строки в начало
        private void ВНачалоToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        // Событие добавления строки в конец
        private void ВКонецToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (NumberOfLessonIndex == 5)
            {
                MessageBoxResult = MessageBox.Show("Вы уверены, что хотите добавить больше 4 пар?", "Добавление пар свыше допустимого значения", MessageBoxButton.YesNo, MessageBoxImage.Exclamation, MessageBoxResult.No);

                if (MessageBoxResult == MessageBoxResult.No)
                {
                    return;
                }
            }

            // TODO: данное ограничение должно быть выставлено в настройках, а не вручную
            else if (NumberOfLessonIndex == 7)
            {
                return;
            }

            //MessageBox.Show($"[{GroupScheduleEditorTableLayoutPanel.ColumnCount} ; {GroupScheduleEditorTableLayoutPanel.RowCount}]");

            ModifyTableLayoutGridRows();

            //MessageBox.Show($"[{GroupScheduleEditorTableLayoutPanel.ColumnCount} ; {GroupScheduleEditorTableLayoutPanel.RowCount}]");
        }

        private void ModifyTableLayoutGridRows(/*TableLayoutPanel TableLayoutPanel,*/ bool IsAddRow = true)
        {
            if (IsAddRow)
            {
                CreateLessonRow();
            }

            else
            {
                if (GroupScheduleTableLayoutGridCurrentMaxRowIndex > 0)
                {
                    DeleteLessonRow();
                }
            }
        }

        /// <summary>
        /// Метод создания строки пар в расписании для группы
        /// </summary>
        private void CreateLessonRow()
        {
            // заменить на обработку события нажатия CheckBox
            if (SetHomeroomsOnMondays)
            {
                // Добавление новой строки под блок НЧ/Ч пары за день недели
                GroupScheduleEditorTableLayoutGrid.RowDefinitions.Add(new() { Height = GridLength.Auto });

                // Индекс строки, которую вы хотите заменить
                GroupScheduleTableLayoutGridCurrentMaxRowIndex++;

                if (GroupScheduleTableLayoutGridCurrentMaxRowIndex > 1)
                {
                    Label NumberOfLessonLabel = new()
                    {
                        Content = NumberOfLessonIndex.ToString(),
                        Background = Brushes.White,
                        BorderBrush = Brushes.Black,
                        BorderThickness = new(1),
                        Margin = new(1),
                        HorizontalContentAlignment = HorizontalAlignment.Center,
                        VerticalContentAlignment = VerticalAlignment.Center
                    };

                    // TODO: сделать не просто цветом, а проверкой:
                    // Если последнее время в списке элементов - оранжевый,
                    // если вообще нет (и больше оранжевого) - то красный
                    if (NumberOfLessonIndex == 5)
                    {
                        NumberOfLessonLabel.Background = Brushes.DarkOrange;
                        NumberOfLessonLabel.Foreground = Brushes.White;
                    }

                    else if (NumberOfLessonIndex >= 6)
                    {
                        NumberOfLessonLabel.Background = Brushes.LightCoral;
                        NumberOfLessonLabel.Foreground = Brushes.White;
                    }

                    NumberOfLessonLabel.SetValue(Grid.ColumnProperty, 0);
                    NumberOfLessonLabel.SetValue(Grid.RowProperty, GroupScheduleTableLayoutGridCurrentMaxRowIndex);
                    GroupScheduleEditorTableLayoutGrid.Children.Add(NumberOfLessonLabel);
                }

                for (int ColumnIndex = 1; ColumnIndex < GroupScheduleEditorTableLayoutGrid.ColumnDefinitions.Count; ColumnIndex++)
                {
                    string DayOfWeek = string.Empty;
                    Label? DayOfWeekLabel = GroupScheduleEditorTableLayoutGrid.Children.OfType<Label>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == ColumnIndex && Grid.GetRow(ChildControl) == 0);

                    if (DayOfWeekLabel?.Content is string DayOfWeekLabelString)
                    {
                        DayOfWeek = DayOfWeekLabelString;
                    }

                    bool DivideLessonIntoOddAndEvenWeek = false;
                    (bool IsOddWeekTeacherReplacementModeActive, bool? IsEvenWeekTeacherReplacementModeActive) = (false, true);
                    (bool IsOddWeekLectureModeActive, bool? IsEvenWeekLectureModeActive) = (true, false);

                    LessonsControl? LessonsControl = new(DayOfWeek, NumberOfLessonIndex, DivideLessonIntoOddAndEvenWeek, "Русский", null, null, false, false, "Химия", null, null, null, null)
                    {
                        MaxWidth = 361.5,
                        //DayOfWeek = DayOfWeek,
                        //NumberOfLesson = NumberOfLessonIndex,
                        //DivideLessonIntoOddAndEvenWeek = DivideLessonIntoOddAndEvenWeek,
                        //Subject = "Русский",
                        //Teacher = null,
                        //Classroom = null,
                        //IsTeacherReplacementModeActivated = false,
                        //IsLectureModeActivated = false,
                        //EvenWeekSubject = "Химия",
                        //EvenWeekTeacher = null,
                        //EvenWeekClassroom = null,
                        //IsEvenWeekTeacherReplacementModeActivated = null,
                        //IsEvenWeekLectureModeActivated = null
                    };

                    Lessons.Add(LessonsControl);

                    Grid.SetRow(LessonsControl, GroupScheduleTableLayoutGridCurrentMaxRowIndex);
                    Grid.SetColumn(LessonsControl, ColumnIndex);

                    // дизайн "шахматка"
                    if (Grid.GetColumn(LessonsControl) % 2 == 0 && Grid.GetRow(LessonsControl) % 2 != 0 || Grid.GetColumn(LessonsControl) % 2 != 0 && Grid.GetRow(LessonsControl) % 2 == 0)
                    {
                        LessonsControl!.LessonControlGrid.Background = Brushes.LightGray;
                    }

                    GroupScheduleEditorTableLayoutGrid.Children.Add(LessonsControl);

                    if (GroupScheduleTableLayoutGridCurrentMaxRowIndex == 1) // не заполнять нулевые пары за ВТ-ПТ
                    {
                        break;
                    }
                }
            }

            else
            {

            }

            NumberOfLessonIndex++;
        }

        private void HandleComboBox(ComboBox ComboBox)
        {
            Dispatcher.BeginInvoke(() =>
            {
                if (ComboBox.Template.FindName("PART_EditableTextBox", ComboBox) is TextBox ComboBoxEditableTextBox)
                {
                    ComboBoxEditableTextBox.TextChanged += (sender, e) =>
                    {
                        if (IsDataRecreating)
                        {
                            return;
                        }

                        else
                        {
                            if (ComboBoxesInfoList == null)
                            {
                                if (ComboBox.Text != "")
                                {
                                    ComboBoxesInfoList = new();
                                }

                                else
                                {
                                    return;
                                }
                            }

                            if (MainWindowComboBoxesInfoList == null)
                            {
                                if (ComboBox.Text != "")
                                {
                                    MainWindowComboBoxesInfoList = new();
                                }

                                else
                                {
                                    return;
                                }
                            }
                        }

                        ChangesHasBeenMade = true;

                        // TODO: сделать проверку на ColumnSpan = 2 => индекс ComboBoxWeek будет другим
                        // Получение позиции контрола в TableLayoutPanel
                        (int Column, int Row) ComboBoxPosition = (Grid.GetColumn(ComboBox), Grid.GetRow(ComboBox));

                        string? ComboBoxDay = null;

                        if (GroupScheduleEditorTableLayoutGrid.Children.OfType<Control>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == ComboBoxPosition.Column && Grid.GetRow(ChildControl) == 0) is TextBox ComboBoxDayTextBox)
                        {
                            ComboBoxDay = ComboBoxDayTextBox.Text;
                        }

                        string? ComboBoxWeek = null;

                        if (GroupScheduleEditorTableLayoutGrid.Children.OfType<Control>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == ComboBoxPosition.Column && Grid.GetRow(ChildControl) == ComboBoxPosition.Row - 2) is TextBox ComboBoxOddWeekTextBox)
                        {
                            ComboBoxWeek = ComboBoxOddWeekTextBox.Text;
                        }

                        else if (GroupScheduleEditorTableLayoutGrid.Children.OfType<Control>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == ComboBoxPosition.Column && Grid.GetRow(ChildControl) == ComboBoxPosition.Row - 2) is TextBox ComboBoxEvenWeekTextBox)
                        {
                            ComboBoxWeek = ComboBoxEvenWeekTextBox.Text;
                        }

                        string ComboBoxText = ComboBox.Text;
                        int ComboBoxColumnSpan = Grid.GetColumnSpan(ComboBox);
                        int ComboBoxRowSpan = Grid.GetRowSpan(ComboBox);

                        List<(int Column, int Row, string Day, string Week, string Text)> ComboBoxInfo = new()
                        {
                        (ComboBoxPosition.Column, ComboBoxPosition.Row, ComboBoxDay ?? string.Empty, ComboBoxWeek ?? string.Empty, ComboBoxText)
                        };

                        string PreviousComboBoxText;

                        (int Column, int Row, string Day, string Week, string Text) ExistingComboBox = ComboBoxesInfoList.FirstOrDefault(ComboBox => (ComboBox.Column, ComboBox.Row) == (ComboBoxPosition.Column, ComboBoxPosition.Row));

                        // Элемент найден, обновляем текст
                        if (!ExistingComboBox.Equals(default))
                        {
                            int ExistingComboBoxIndex = ComboBoxesInfoList.IndexOf(ExistingComboBox);
                            PreviousComboBoxText = ComboBoxesInfoList[ExistingComboBoxIndex].Text;

                            // Удаляем информацию об элементе из данных на сохранение
                            if (ComboBox.Text == "")
                            {
                                ComboBoxesInfoList.Remove(ComboBoxesInfoList[ExistingComboBoxIndex]);
                                ComboBoxesInfoList = ComboBoxesInfoList.OrderBy(tuple => tuple.Column).ThenBy(tuple => tuple.Row).ToList();

                                MainWindowComboBoxesInfoList?.Remove(ComboBoxesInfoList[ExistingComboBoxIndex]);
                                MainWindowComboBoxesInfoList = MainWindowComboBoxesInfoList?.OrderBy(tuple => tuple.Column).ThenBy(tuple => tuple.Row).ToList();

                                if (ComboBoxesInfoList?.Count == 0)
                                {
                                    ComboBoxesInfoList = null;
                                }

                                if (MainWindowComboBoxesInfoList?.Count == 0)
                                {
                                    MainWindowComboBoxesInfoList = null;
                                }
                            }

                            else
                            {
                                ComboBoxesInfoList[ExistingComboBoxIndex] = ComboBoxInfo[0];
                                ComboBoxesInfoList = ComboBoxesInfoList.OrderBy(tuple => tuple.Column).ThenBy(tuple => tuple.Row).ToList();

                                // возникает исключение, если открывать редактирование уже существующего расписания группы
                                // TODO: изменится, если ячейки будут объединены
                                MainWindowComboBoxesInfoList[ExistingComboBoxIndex] = (ComboBoxInfo[0].Column, ComboBoxInfo[0].Row - 2, ComboBoxInfo[0].Day, ComboBoxInfo[0].Week, ComboBoxInfo[0].Text);
                                MainWindowComboBoxesInfoList = MainWindowComboBoxesInfoList?.OrderBy(tuple => tuple.Column).ThenBy(tuple => tuple.Row).ToList();
                            }
                        }

                        // Элемент не найден, добавляем новый
                        else
                        {
                            ComboBoxesInfoList.Add(ComboBoxInfo[0]);
                            ComboBoxesInfoList = ComboBoxesInfoList.OrderBy(tuple => tuple.Column).ThenBy(tuple => tuple.Row).ToList();

                            MainWindowComboBoxesInfoList.Add((ComboBoxInfo[0].Column, ComboBoxInfo[0].Row - 2, ComboBoxInfo[0].Day, ComboBoxInfo[0].Week, ComboBoxInfo[0].Text));
                            MainWindowComboBoxesInfoList = MainWindowComboBoxesInfoList?.OrderBy(tuple => tuple.Column).ThenBy(tuple => tuple.Row).ToList();

                            PreviousComboBoxText = ComboBoxInfo[0].Text;
                        }

                        if (MainData.SubjectList != null)
                        {
                            //ProcessSubjectsPerWeekDay(ComboBox);
                            if (ComboBox.Items.Cast<string>().SequenceEqual(MainData.SubjectList))
                            {
                                // Если была выбрана другая дисциплина - уменьшить количество часов для предыдущей дисциплины
                                if (ComboBoxText != PreviousComboBoxText)
                                {
                                    ModifySubjectHoursPerDayList(ComboBoxDay, PreviousComboBoxText, IsAddHours: false);
                                }

                                bool Success = ModifySubjectHoursPerDayList(ComboBoxDay, ComboBoxText: ComboBoxText);

                                float TotalHoursPerSubject = 0;
                                float TotalSubjectHoursPerDay = 0;
                                float TotalSubjectHoursPerWeek = 0;

                                foreach ((string, List<(string, float)>) SubjectPerWeekDayList in SubjectsPerWeekDayList)
                                {
                                    foreach ((string, float) SubjectPerWeekDay in SubjectPerWeekDayList.Item2)
                                    {
                                        if (SubjectPerWeekDay.Item1 == ComboBoxText)
                                        {
                                            TotalHoursPerSubject += SubjectPerWeekDay.Item2;

                                            if (SubjectPerWeekDayList.Item1 == ComboBoxDay)
                                            {
                                                TotalSubjectHoursPerDay += SubjectPerWeekDay.Item2;
                                            }
                                        }

                                        TotalSubjectHoursPerWeek += SubjectPerWeekDay.Item2;
                                    }
                                }

                                if (Success)
                                {
                                    // Вывести значение добавляемого элемента в MessageBox
                                    //MessageBox.Show($"[День]: {SubjectsPerWeekDayList.FirstOrDefault(SubjectsPerWeekDayListItem => SubjectsPerWeekDayListItem.Item1 == ComboBoxDay).Item1}, [Дисциплина]: {ComboBox.Text}");
                                }

                                // Вывести общее количество часов для выбранного дня и выбранной дисциплины за неделю
                                //MessageBox.Show($"Общее количество часов за день: {TotalSubjectHoursPerDay}", $"{ComboBox.Text}");
                                //MessageBox.Show($"Общее количество часов по дисциплине за неделю: {TotalHoursPerSubject}", $"{ComboBox.Text}");

                                // Список с днями недели, а также с текстом дисциплин и их часами
                                List<(string, string?)> SubjectsAndHoursPerWeekList = new()
                                {
                                    { ("Понедельник", null) },
                                    { ("Вторник", null) },
                                    { ("Среда", null) },
                                    { ("Четверг", null) },
                                    { ("Пятница", null) }
                                };

                                int i = 1;
                                string LabelOriginalText = "1) Количество распределений на неделю:\r\n\r\n1. Общее количество часов дисциплин - [0] ч / 36 ч\r\n\r\n2. Количество распределённых дисциплин:\r\n\r\n2) Количество распределений по дням:\r\n\r\n1. Понедельник - [0] ч:\r\n\r\n2. Вторник - [0] ч:\r\n\r\n3. Среда - [0] ч:\r\n\r\n4. Четверг - [0] ч:\r\n\r\n5. Пятница - [0] ч:\r\n";
                                //WeekInfoOfGroupTextBlock.Text = LabelOriginalText;

                                foreach ((string, List<(string, float)>) SubjectPerWeekDayList in SubjectsPerWeekDayList)
                                {
                                    float TotalHoursPerDay = 0;
                                    string? SubjectText = null;

                                    foreach ((string, float) SubjectPerWeekDay in SubjectPerWeekDayList.Item2)
                                    {
                                        TotalHoursPerDay += SubjectPerWeekDay.Item2;

                                        if (SubjectPerWeekDay.Item2 > 0)
                                        {
                                            SubjectText += $"\r\n{SubjectPerWeekDay.Item1} - {SubjectPerWeekDay.Item2} ч";
                                        }
                                    }

                                    //ReplaceNthOccurrence(WeekInfoOfGroupTextBlock, i + 1, TotalHoursPerDay.ToString()); // заменяет общее часы для дня недели

                                    if (SubjectText != null)
                                    {
                                        // TODO: обработать нормально
                                        SubjectsAndHoursPerWeekList[i - 1] = (SubjectsPerWeekDayList[i - 1].Item1, SubjectText);

                                        //InsertAfterNthOccurrence(WeekInfoOfGroupTextBlock, i + 1, "\r\n" + SubjectsAndHoursPerWeekList[i - 1].Item2, 3);
                                    }

                                    i++;
                                }

                                // [Отладка] //
                                /*List<string> subjects = new List<string>();

                                foreach (var pair in SubjectsAndHoursPerWeekList.Where(SubjectsAndHoursPerWeekListItem => SubjectsAndHoursPerWeekListItem.Item2 != null))
                                {
                                    //subjects.Add($"{pair.Item1} - {pair.Item2}");
                                    subjects.Add($"\r\n{pair.Item2}");
                                }

                                string result = string.Join("\n", subjects);*/
                                //MessageBox.Show(result);
                                //MessageBox.Show(SubjectsAndHoursPerWeekList[i - 1].ToString());
                                // TODO: доделать вывод дисциплины за неделю (с сумами их часов)
                                //ReplaceNthOccurrence(label13, i + 1, TotalHoursPerDay.ToString());*/

                                //ReplaceNthOccurrence(WeekInfoOfGroupTextBlock, 1, TotalSubjectHoursPerWeek.ToString()); // заменяет общую сумму часов
                                //InsertAfterNthOccurrence(textBox1, 1, result, 52);
                            }
                        }

                        //ComboBoxPositionAndTheirTextList.Sort();
                    };
                }
            });
        }

        private string ProcessSubjectsPerWeekDay(ComboBox ComboBox)
        {
            return "";
        }

        private bool ModifySubjectHoursPerDayList(string? ComboBoxDay, string? PreviousComboBoxText = null, string? ComboBoxText = null, bool IsAddHours = true)
        {
            if (IsAddHours)
            {
                (string, List<(string, float)>) DaySubjectList = SubjectsPerWeekDayList.FirstOrDefault(DaySubjectListItem => DaySubjectListItem.Item1 == ComboBoxDay);

                if (DaySubjectList.Item1 != null)
                {
                    // Найти список, соответствующий дню элемента ComboBox
                    (string, List<(string, float)>) ComboBoxDaySubjectList = SubjectsPerWeekDayList.FirstOrDefault(ComboBoxDaySubjectListItem => ComboBoxDaySubjectListItem.Item1 == ComboBoxDay);

                    if (ComboBoxDaySubjectList.Item1 != null)
                    {
                        // Найти соответствующую дисциплину в списке дисциплин для этого дня
                        int DaySubjectListItemIndex = ComboBoxDaySubjectList.Item2.FindIndex(ComboBoxDaySubjectListItem => ComboBoxDaySubjectListItem.Item1 == ComboBoxText);

                        if (DaySubjectListItemIndex != -1)
                        {
                            ComboBoxDaySubjectList.Item2[DaySubjectListItemIndex] = (ComboBoxDaySubjectList.Item2[DaySubjectListItemIndex].Item1, ComboBoxDaySubjectList.Item2[DaySubjectListItemIndex].Item2 + /*1.5f*/2);

                            return true;
                        }

                        else
                        {
                            return false;
                        }
                    }

                    else
                    {
                        return false;
                    }
                }

                else
                {
                    return false;
                }
            }

            else
            {
                (string, List<(string, float)>) PreviousDaySubjectList = SubjectsPerWeekDayList.FirstOrDefault(PreviousDaySubjectListItem => PreviousDaySubjectListItem.Item1 == ComboBoxDay);

                if (PreviousDaySubjectList.Item1 != null)
                {
                    int PreviousDaySubjectListItemIndex = PreviousDaySubjectList.Item2.FindIndex(PreviousDaySubjectListItem => PreviousDaySubjectListItem.Item1 == PreviousComboBoxText);

                    if (PreviousDaySubjectListItemIndex != -1)
                    {
                        PreviousDaySubjectList.Item2[PreviousDaySubjectListItemIndex] = (PreviousDaySubjectList.Item2[PreviousDaySubjectListItemIndex].Item1, PreviousDaySubjectList.Item2[PreviousDaySubjectListItemIndex].Item2 - /*1.5f*/2);

                        return true;
                    }

                    else
                    {
                        return false;
                    }
                }

                else
                {
                    return false;
                }
            }
        }

        private void DeleteLessonRow()
        {
            // Удаление всех элементов из колонок
            for (int ColumnIndex = GroupScheduleEditorTableLayoutGrid.ColumnDefinitions.Count - 1; ColumnIndex >= 0; ColumnIndex--)
            {
                if (ColumnIndex == 0)
                {
                    Label? LabelOnDelete = GroupScheduleEditorTableLayoutGrid.Children.OfType<Label>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == 0 && Grid.GetRow(ChildControl) == GroupScheduleTableLayoutGridCurrentMaxRowIndex);
                    GroupScheduleEditorTableLayoutGrid.Children.Remove(LabelOnDelete);
                }

                else
                {
                    LessonsControl? LessonsControl = GroupScheduleEditorTableLayoutGrid.Children.OfType<LessonsControl>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == ColumnIndex && Grid.GetRow(ChildControl) == GroupScheduleTableLayoutGridCurrentMaxRowIndex);

                    if (LessonsControl != null)
                    {
                        GroupScheduleEditorTableLayoutGrid.Children.Remove(LessonsControl);
                    }

                    // processallvisuals -> combobox;

                    if (LessonsControl != null)
                    {
                        //if (GridOnDelete is ComboBox ComboBox)
                        //{
                        //    (int Column, int Row) ComboBoxPosition = (Grid.GetColumn(ComboBox), Grid.GetRow(ComboBox));
                        //    (int Column, int Row, string Day, string Week, string Text) ExistingComboBox = new();

                        //    if (ComboBoxesInfoList != null)
                        //    {
                        //        ExistingComboBox = ComboBoxesInfoList.FirstOrDefault(ComboBox => (ComboBox.Column, ComboBox.Row) == (ComboBoxPosition.Column, ComboBoxPosition.Row));
                        //    }

                        //    // Элемент найден, удаляем хранимые данные
                        //    if (!ExistingComboBox.Equals(default))
                        //    {
                        //        int ExistingComboBoxIndex = -1;

                        //        if (ComboBoxesInfoList != null)
                        //        {
                        //            ExistingComboBoxIndex = ComboBoxesInfoList.IndexOf(ExistingComboBox);
                        //        }

                        //        ComboBoxesInfoList?.Remove(ComboBoxesInfoList[ExistingComboBoxIndex]);
                        //    }
                        //}
                    }
                }
            }

            // Удаление строки
            GroupScheduleEditorTableLayoutGrid.RowDefinitions.RemoveAt(GroupScheduleTableLayoutGridCurrentMaxRowIndex);

            GroupScheduleTableLayoutGridCurrentMaxRowIndex--;
            NumberOfLessonIndex--;

            //GC.Collect(); // уравнивает кол-во удаляемых и создаваемых элементов
        }

        public void ReplaceNthOccurrence(TextBlock TextBlock, int PatternAppearance, string newValue)
        {
            int count = 0;

            TextBlock.Text = Regex.Replace(TextBlock.Text, @"\[(.*?)\]", m =>
            {
                count++;

                if (count == PatternAppearance)
                {
                    return $"[{newValue}]";
                }

                else
                {
                    return m.Value;
                }
            });
        }

        public void InsertAfterNthOccurrence(TextBlock TextBlock, int PatternAppearance, string newValue, int Offset)
        {
            int count = 0;
            string p = "";

            TextBlock.Text = Regex.Replace(TextBlock.Text, @"\[(.*?)\]", m =>
            {
                count++;

                if (count == PatternAppearance)
                {
                    int insertPosition = m.Index + m.Length + Offset;

                    if (insertPosition > TextBlock.Text.Length)
                    {
                        p = TextBlock.Text += newValue; // Вставить в конец, если смещение выходит за пределы текста
                    }

                    else
                    {
                        p = TextBlock.Text = TextBlock.Text.Insert(insertPosition, newValue);
                    }

                    return m.Value;
                }

                else
                {
                    return m.Value;
                }
            });

            TextBlock.Text = p;
        }

        // Событие удаления строки в начале
        private void ВНачалеToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        // Событие удаления строки в конце
        private void ВКонцеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            // Удаление строки
            if (GroupScheduleEditorTableLayoutGrid.RowDefinitions.Count > 1)
            {
                ModifyTableLayoutGridRows(false);
            }
        }

        // Событие добавления столбца в начало
        private void ВНачалоToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        // Событие добавления столбца в конец
        private void ВКонецToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        // Событие удаления столбца в начале
        private void ВНачалеToolStripMenuItem3_Click(object sender, EventArgs e)
        {

        }

        // Событие удаления столбца в конце
        private void ВКонцеToolStripMenuItem3_Click(object sender, EventArgs e)
        {

        }

        private void ReplacementModeCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (true)
            {
                _ = true;

                // Добавление обработчика для всех ComboBox'ов на форме
                GroupScheduleEditorTableLayoutGrid.ProcessAllChildVisualControls(Control =>
                {
                    //if (Control is ComboBox ComboBox)
                    //{
                    //    List<string> ComboBoxElements = ComboBox.Items.Cast<string>().ToList();

                    //    if (CurrentSubjectAndTeacherList != null && MainData.SubjectAndTeacherList != null)
                    //    {
                    //        if (!CurrentSubjectAndTeacherList.SequenceEqual(MainData.SubjectAndTeacherList))
                    //        {
                    //            if (ComboBoxElements.SequenceEqual(CurrentSubjectList))
                    //            {
                    //                ComboBox.Items.Clear();
                    //                ComboBox.Items.AddRange(MainData.SubjectAndTeacherList?.Select(SubjectAndTeacherListItem => SubjectAndTeacherListItem.Item1).ToArray() ?? Array.Empty<string>());
                    //            }

                    //            else if (ComboBoxElements.SequenceEqual(CurrentSubjectList))
                    //            {
                    //                ComboBox.Items.Clear();
                    //                ComboBox.Items.AddRange(MainData.SubjectAndTeacherList?.Select(SubjectAndTeacherListItem => SubjectAndTeacherListItem.Item1).ToArray() ?? Array.Empty<string>());
                    //            }
                    //        }
                    //    }

                    //    if (CurrentTeacherList != null && MainData.TeacherList != null)
                    //    {
                    //        if (!CurrentTeacherList.SequenceEqual(MainData.TeacherList) && ComboBoxElements.SequenceEqual(CurrentTeacherList))
                    //        {
                    //            ComboBox.Items.Clear();
                    //            ComboBox.Items.AddRange(MainData.TeacherList?.ToArray() ?? Array.Empty<string>());
                    //        }
                    //    }

                    //    if (CurrentClassroomList != null && MainData.ClassroomList != null)
                    //    {
                    //        if (!CurrentClassroomList.SequenceEqual(MainData.ClassroomList) && ComboBoxElements.SequenceEqual(CurrentClassroomList))
                    //        {
                    //            ComboBox.Items.Clear();
                    //            ComboBox.Items.AddRange(MainData.ClassroomList?.ToArray() ?? Array.Empty<string>());
                    //        }
                    //    }
                    //}
                });
            }

            else
            {
                _ = false;
            }
        }

        // Событие, которое вызывается при изменении данных
        public static event Action? OnDataChanged;

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            //// Для списка предметов
            //string subjects = string.Join(", ", SubjectList);
            //MessageBox.Show(subjects, "Список предметов");

            if (DisableMappingWithDatabase == null)
            {
                MessageBoxResult MessageBoxResult = MessageBox.Show("Вы хотите сопоставлять данные c БД?", string.Empty, MessageBoxButton.YesNoCancel, MessageBoxImage.Question);

                if (MessageBoxResult == MessageBoxResult.Yes)
                {
                    MapDataWithDatabaseCheckBox.IsChecked = true;
                }

                else if (MessageBoxResult == MessageBoxResult.No)
                {
                    MapDataWithDatabaseCheckBox.IsChecked = false;
                }

                else
                {
                    if (DisableMappingWithDatabaseCheckBoxBorder.Child is not Grid)
                    {
                        Rectangle Rectangle = new()
                        {
                            Stroke = Brushes.Red,
                            StrokeThickness = 1,
                            StrokeDashArray = new() { 2, 2 }
                        };

                        Grid Grid = new();
                        Grid.Children.Add(Rectangle);

                        // Удалить CheckBox из его текущего родителя
                        if (MapDataWithDatabaseCheckBox.Parent is Border ParentBorder)
                        {
                            ParentBorder.Child = null;
                        }

                        // Добавить CheckBox в Grid
                        Grid.Children.Add(MapDataWithDatabaseCheckBox);

                        DisableMappingWithDatabaseCheckBoxBorder.Child = Grid;
                    }

                    return;
                }
            }

            //if (GroupSubjectsDictionary.Count == 0 && !ChangesHasBeenMade /*TODO: это костыль - убрать!*/)
            //{
            //    MessageBox.Show("Данные не были сохранены, поскольку вы не внесли никаких изменений", string.Empty, MessageBoxButton.OK, MessageBoxImage.Asterisk);

            //    return;
            //}

            GroupData = LoadData<GroupDataClass>();

            if (GroupData.GroupName == null)
            {
                GroupData.GroupName = GroupInTitle;
            }

            if (/*ComboBoxesInfoList != null && */GroupData?.ComboBoxesInfoList != null)
            {
                if (ComboBoxesInfoList.SequenceEqual(GroupData.ComboBoxesInfoList))
                {
                    //TODO: временная мера - изменить на Enabled = false, как в MainDataWindow
                    MessageBox.Show("Данные не были сохранены, поскольку вы не внесли никаких изменений", string.Empty, MessageBoxButton.OK, MessageBoxImage.Asterisk);

                    return;
                }
            }

            //if (GroupData?.GroupSubjectsPerWeekDayList?.Where(GroupList => GroupList.Item1 == GroupInTitle) == SubjectsPerWeekDayList)
            //{
            //    return;
            //}

            //if (CurrentData?.GroupsSubjectsPerWeekDayList?.Where(GroupList => GroupList.Item1 == GroupInTitle) != SubjectsPerWeekDayList)
            //{
            //    var GroupSubjectListToModify = CurrentData?.GroupsSubjectsPerWeekDayList?.FirstOrDefault(GroupList => GroupList.Item1 == GroupInTitle);

            //    if (GroupSubjectListToModify != (null, null))
            //    {
            //        int SubjectListItemIndex = CurrentData.GroupsSubjectsPerWeekDayList.FindIndex(SubjectListItem => SubjectListItem.Item1 == GroupInTitle);
            //        //var filteredSubjects = SubjectsPerWeekDayList.Select(x => (x.Item1, x.Item2.Where(y => y.Item2 > 0).ToList())).ToList();
            //        CurrentData.GroupsSubjectsPerWeekDayList[SubjectListItemIndex] = (GroupInTitle, SubjectsPerWeekDayList);
            //    }

            //    else
            //    {
            //        CurrentData.GroupsSubjectsPerWeekDayList.Add((GroupInTitle, SubjectsPerWeekDayList));
            //    }
            //}

            //if (GroupData?.GroupsComboBoxPositionAndTheirTextList?.Where(x => x.Item1 == GroupInTitle).Select(x => x.Item2).ToList().SequenceEqual(ComboBoxPositionAndTheirTextList))
            //List<string>? list1 = GroupData?.GroupComboBoxesPositionAndTheirTextList?.Where(x => x.Item1 == GroupInTitle).SelectMany(x => x.Item2.Select(y => y.Item3)).ToList();
            //List<string>? list2 = ComboBoxesInfoList.Select(x => x.Item3).ToList();

            //bool areEqual = false;
            //if (list1 != null)
            //{
            //    areEqual = list1.SequenceEqual(list2);
            //}

            //if (areEqual)
            //{
            //    return;
            //}

            //if (CurrentData?.ComboBoxPositionAndTheirTextList?.Where(x => x.Item1 == GroupInTitle) != ComboBoxPositionAndTheirTextList)
            //{
            //    (string, List<(string, List<(string, float)>)>)? ComboBoxPositionAndTheirTextListToReplace = CurrentData?.GroupsSubjectsPerWeekDayList?.FirstOrDefault(x => x.Item1 == GroupInTitle);

            //    if (!ComboBoxPositionAndTheirTextListToReplace.Equals(default))
            //    {
            //        int? index = CurrentData?.ComboBoxPositionAndTheirTextList?.FindIndex(x => x.Item1 == GroupInTitle);

            //        if (index != -1)
            //        {
            //            CurrentData.ComboBoxPositionAndTheirTextList[index.Value] = (GroupInTitle, ComboBoxPositionAndTheirTextList);
            //        }

            //        else
            //        {
            //            CurrentData?.ComboBoxPositionAndTheirTextList?.Add((GroupInTitle, ComboBoxPositionAndTheirTextList));
            //        }
            //    }
            //}

            //CurrentData.ComboBoxPositionAndTheirTextList.Add((GroupInTitle, ComboBoxPositionAndTheirTextList));
            //CurrentData.GroupsSubjectsPerWeekDayList.Add((GroupInTitle, SubjectsPerWeekDayList));

            // TODO: когда удаляю дисциплину / кабинет, то ячейка пустая, но появляется, т.к. сохраняются
            // её координаты
            if (GroupData != null)
            {
                GroupData.SubjectsPerWeekDayList = SubjectsPerWeekDayList;
                //GroupData.ComboBoxesInfoList = ComboBoxesInfoList;
                //GroupData.MainWindowComboBoxesInfoList = MainWindowComboBoxesInfoList;
                //GroupData.SubjectsPerWeekDayList = SubjectsPerWeekDayList;
            }

            if (GroupData?.SaveData<GroupDataClass>() == true)
            {
                ChangesHasBeenMade = false;
                OnDataChanged?.Invoke();

                MessageBox.Show("Данные успешно сохранены!", string.Empty, MessageBoxButton.OK, MessageBoxImage.Information);
            }

            // TODO: ввести логирование ошибки
            else
            {
                MessageBox.Show("Ошибка сохранения данных! Данные не были сохранены!", string.Empty, MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MapDataWithDatabaseCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            DisableMappingWithDatabase = true;
            ResetDisableMappingWithDatabaseCheckBoxBorder();
        }

        private void MapDataWithDatabaseCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            DisableMappingWithDatabase = false;
            ResetDisableMappingWithDatabaseCheckBoxBorder();
        }

        private void ResetDisableMappingWithDatabaseCheckBoxBorder()
        {
            if (DisableMappingWithDatabaseCheckBoxBorder.Child is Grid Grid)
            {
                Grid.Children.Clear();
                DisableMappingWithDatabaseCheckBoxBorder.Child = MapDataWithDatabaseCheckBox;

                DisableMappingWithDatabaseCheckBoxBorder.BorderBrush = null;
                DisableMappingWithDatabaseCheckBoxBorder.BorderThickness = default;
            }
        }
    }
}