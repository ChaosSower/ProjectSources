﻿// TODO: залочить кнопки + и редакция для группы, чьё окно расписания открыто [Готово?]
// TODO: сделать динамическое появление кнопок редактирования расписания, если оно было составлено
// https://stackoverflow.com/questions/48712590/xml-documentation-of-action-parameters-in-c-sharp
// https://stackoverflow.com/questions/3526366/wpf-what-is-the-correct-way-of-using-svg-files-as-icons-in-wpf
// https://www.youtube.com/watch?v=TXTmitKTL5Q
// https://learn.microsoft.com/en-us/answers/questions/481821/(wpf)-rounded-window-drop-shadow-problem
// https://stackoverflow.com/questions/13049/whats-the-difference-between-struct-and-class-in-net

using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Input;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

using static Digital_Schedule_Editor.Controls.CustomControls.SeparateLabelClass;
using Digital_Schedule_Editor.Extensions.CommonComponents;
using Digital_Schedule_Editor.Classes;
using Digital_Schedule_Editor.Classes.SerializingClasses;
using Digital_Schedule_Editor.Controls.CustomControls;
using Digital_Schedule_Editor.Controls.StaticControls;
using Digital_Schedule_Editor.Modules.Windows.Common;
using Digital_Schedule_Editor.Modules.Windows.College;
using System.Text.RegularExpressions;
using System.Windows.Media.Effects;
using System.Xml.Linq;
using System.Windows.Media.Animation;
using System.Diagnostics;
using Digital_Schedule_Editor.Components.CustomComponents;

namespace Digital_Schedule_Editor
{
    /// <summary>
    /// Главное окно программы
    /// </summary>
    public partial class MainWindow : Window
    {
        // Поля //

        // Поля хранимых данных проекта
        private readonly MainDataClass MainData = new();
        private EditMainDataWindow EditMainDataWindow;
        private SettingsWindow SettingsWindow;
        private GroupDataClass GroupData;
        private readonly List<GroupDataClass> GroupDataList = new();

        private MessageBoxResult MessageBoxResult;

        private int RowsInTableLayoutPanel;

        private readonly List<(string, int, int)> ElementPositionXY = new();

        private List<(int Column, int Row, string Day, string Week, string Text)> GroupTextBoxesInfoList = new();

        private readonly Grid GroupsScheduleTableLayoutGrid = StaticControlsClass.GroupsScheduleTableLayoutGrid;
        private readonly ScrollViewer GroupsScheduleTableLayoutScrollViewer = StaticControlsClass.GroupsScheduleTableLayoutScrollViewer;
        private readonly SeparateLabelWithAngledText MainWindowSeparateLabel = StaticControlsClass.MainWindowSeparateLabel;

        // TODO: автоматизировать пробелы между группами и днями недели (в долгосрочной перспективе)

        private readonly List<(string ComparedParameterName, List<int> SequencesNumbers)> ArithmeticSequencesList = new();
        private readonly List<(string ComparedParameterName, List<int> SequencesNumbers)> AlternatingSequencesList = new();
        private readonly List<(string ComparedParameterName, List<int> SequencesNumbers)> CyclicSequencesList = new();

        private List<int> TemporaryArithmeticSequenceList_0 = new();
        private List<int> TemporaryCyclicSequenceList_0 = new();
        private List<int> TemporaryCyclicSequenceList_1 = new();

        private List<string> TextBoxElements = new();

        public MainWindow()
        {
            InitializeComponent();

            //this.Hide();

            EditGroupScheduleWindow EditGroupScheduleWindow = new("ИСП 321");
            //EditGroupScheduleWindow.FormClosed += (sender, e) => UpdateSubjects();
            EditGroupScheduleWindow.Show();

            //return;

            RoutedEventHandler? EditMainDataButtonClickHandler = null;

            EditMainDataButtonClickHandler = (sender, e) =>
            {
                EditMainDataWindow = new();

                EditMainDataWindow.Closed += (sender, e) =>
                {
                    EditMainDataButton.Click += EditMainDataButtonClickHandler;
                };

                EditMainDataButton.Click -= EditMainDataButtonClickHandler;
                EditMainDataWindow.Show();
            };

            EditMainDataButton.Click += EditMainDataButtonClickHandler;

            RoutedEventHandler? SettingsButtonClickHandler = null;

            SettingsButtonClickHandler = (sender, e) =>
            {
                SettingsWindow = new();

                SettingsWindow.Closed += (sender, e) =>
                {
                    SettingsButton.Click += SettingsButtonClickHandler;

                    GroupsScheduleTableLayoutGrid.ProcessAllChildVisualControls(Control =>
                    {
                        if (Control is LabelWithButtons LabelWithButtons)
                        {
                            LabelWithButtons.IsEnabled = true;
                        }
                    });
                };

                SettingsButton.Click -= SettingsButtonClickHandler;

                GroupsScheduleTableLayoutGrid.ProcessAllChildVisualControls(Control =>
                {
                    if (Control is LabelWithButtons LabelWithButtons)
                    {
                        LabelWithButtons.IsEnabled = false;
                    }
                });

                SettingsWindow.Show();
            };

            SettingsButton.Click += SettingsButtonClickHandler;

            if (true)
            {
                // Устанавливаем высоту вертикального ползунка
                GroupsScheduleTableLayoutScrollViewer.Resources[SystemParameters.VerticalScrollBarButtonHeightKey] = 100.0;
            }

            GroupsScheduleTableLayoutScrollViewer.SetValue(Grid.RowProperty, 1);
            MainWindowGrid.Children.Add(GroupsScheduleTableLayoutScrollViewer);

            MainData = EditGroupScheduleWindow.LoadData<MainDataClass>();

            //SetMainWindowDefaults(); /*!!!!!*/
            //SetWindowDefaults(); /*!!!!!*/

            // TODO: проверить, есть ли случаи, когда файлы придётся закрывать вручную, явно
            //FormClosing += (sender, s) =>
            //{
            //    foreach (var x in SerializableDataClass.OpenedFileStreams)
            //    {
            //        x.Item2.Close();
            //    }

            //    SerializableDataClass.OpenedFileStreams.Clear();
            //};
        }

        // События //

        // Событие загрузки главного окна при запуске приложения
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GC.Collect(); // относиться с осторожностью!

            Dispatcher.BeginInvoke(() =>
            {
                ErrorProvider();

                int DialogResultCase = -1;

                if (MainData?.SubjectList?.Count == null && MainData?.TeacherList?.Count == null && MainData?.GroupList?.Count == null && MainData?.ClassroomList?.Count == null)
                {
                    DialogResultCase = 0;
                    MessageBoxResult = MessageBox.Show("Внимание, отсутствуют необходимые данные для работы с расписанием!\n\nВы уверены, что хотите продолжить работу без них?", "Отсутствуют необходимые данные!", MessageBoxButton.YesNo, MessageBoxImage.Exclamation, MessageBoxResult.No);
                }

                // TODO: проверить работу каждого условия (корректно ли оно срабатывает)
                else if (MainData?.SubjectList?.Count == 0 && MainData?.TeacherList?.Count == 0 && MainData?.GroupList?.Count == 0 && MainData?.ClassroomList?.Count == 0)
                {
                    DialogResultCase = 1;
                    MessageBoxResult = MessageBox.Show("Внимание, похоже, что необходимые данные для работы с расписанием не были корректно сохранены или были удалены!\n\nВы уверены, что хотите продолжить работу без них?", "Сохранённые данные отсутствуют!", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);
                }

                else if (MainData?.SubjectList?.Count == 0 || MainData?.TeacherList?.Count == 0 || MainData?.GroupList?.Count == 0 || MainData?.ClassroomList?.Count == 0)
                {
                    // TODO: добавить проверку на Count = 0 в EditMainDataWindow перед сохранением
                    // "вы уверены, что хотите продолжить без всех/некоторых необходимых данных?"
                    DialogResultCase = 2;
                    MessageBoxResult = MessageBox.Show("Похоже, что некоторые данные для работы с расписанием отсутствуют.\n\nЖелаете заполнить недостающие данные?", "Отсутствуют некоторые данные", MessageBoxButton.YesNo, MessageBoxImage.Information);
                }

                if (MessageBoxResult == MessageBoxResult.No && DialogResultCase != 2)
                {
                    EditMainDataWindow = new();
                    EditMainDataWindow.Closed += (object? sender, EventArgs e) =>
                    {
                        //SetMainWindowDefaults();
                        //LoadGroupsDataAndGrid();
                    };

                    EditMainDataWindow.Show();
                }

                if (MessageBoxResult == MessageBoxResult.Yes && DialogResultCase == 2)
                {
                    EditMainDataWindow = new();
                    EditMainDataWindow.Closed += (object? sender, EventArgs e) =>
                    {
                        //SetMainWindowDefaults();
                        //LoadGroupsDataAndGrid();
                    };

                    EditMainDataWindow.Show();
                }

                foreach (GroupDataClass x in GroupDataList)
                {
                    //x.GroupName = x.
                    //GroupData = new()
                    //{
                    //    GroupName = GroupDataList.
                    //};

                    //GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(); // переменная загруженных данных проекта

                    GroupDataClass p = new()
                    {
                        GroupName = x.GroupName
                    };

                    p = EditGroupScheduleWindow.LoadData<GroupDataClass>(x.GroupName);

                    if (p.ComboBoxesInfoList != null)
                    {
                        //LoadGroupSchedule(p, null);
                    }
                }

                //else
                {
                    //if (GroupData?.GroupsDockableComboBoxPositionAndTheirTextList != null && GroupData.GroupsDockableComboBoxPositionAndTheirTextList.Count != 0)
                    //{
                    //    int maxRow = 0;
                    //    int maxColumn = 0;
                    //    int GroupCount = 0;
                    //    bool IsItForFirstTime = true;

                    //    foreach (var group in MainData.GroupList)
                    //    {
                    //        if (GroupData?.GroupsDockableComboBoxPositionAndTheirTextList?.FirstOrDefault(x => x.Item1 == group).Item2 != null)
                    //        {
                    //            // TODO: foreach
                    //            GroupSubjectTextBoxesPositionAndTheirTextList = GroupData.GroupsDockableComboBoxPositionAndTheirTextList.FirstOrDefault(x => x.Item1 == group).Item2;
                    //        }

                    //        for (int i = 0; i < GroupsScheduleTableLayoutGrid.ColumnCount; i++)
                    //        {
                    //            string GroupText = GroupsScheduleTableLayoutGrid.GetControlFromPosition(i, 0).Text;

                    //            if (GroupText == group)
                    //            {
                    //                ElementPositionXY.Add((group, i, 0));
                    //                break;
                    //            }
                    //        }

                    //        if (GroupSubjectTextBoxesPositionAndTheirTextList != null && GroupSubjectTextBoxesPositionAndTheirTextList.Count != 0)
                    //        {
                    //            // TODO: код производит неверный расчёт - исправить!
                    //            maxRow = GroupSubjectTextBoxesPositionAndTheirTextList.Max(item => item.Item1);
                    //            maxColumn = GroupSubjectTextBoxesPositionAndTheirTextList.Max(item => item.Item2);

                    //            if (IsItForFirstTime)
                    //            {
                    //                IsItForFirstTime = false;
                    //                // Добавляем стили для строк и колонок
                    //                for (int i = 0; i < (maxRow - 1) * (maxColumn - 7); i++)
                    //                {
                    //                    RowsInTableLayoutPanel = GroupsScheduleTableLayoutGrid.RowCount - 1;
                    //                    //RowIndex = RowsInTableLayoutPanel;

                    //                    // Добавление новой строки
                    //                    GroupsScheduleTableLayoutGrid.RowCount++;
                    //                    // Добавление нового стиля строки
                    //                    GroupsScheduleTableLayoutGrid.RowStyles.Add(new(SizeType.AutoSize));
                    //                }
                    //            }
                    //        }

                    //        for (int i = 0; i < (5 - 1) * (12 - 7); i++)
                    //        {
                    //            GroupsScheduleTableLayoutGrid.Controls.Add(new TextBox() { ReadOnly = true }, GroupCount + 1, i + 1);
                    //        }

                    //        UpdateSubjectsForGroup(GroupData);

                    //        GroupCount++;
                    //    }

                    //for (int i = 0; i < (maxRow - 1) * (maxColumn - 7); i++)
                    //{
                    //    // TODO: переделать в создание строк
                    //    ВКонецToolStripMenuItem_Click(this, EventArgs.Empty);
                    //}

                    //for (int i = 0; i < GroupsScheduleTableLayoutGrid.RowCount; i++)
                    //{
                    //    GroupsScheduleTableLayoutGrid.RowStyles.Add(new(SizeType.Absolute, 50/*AutoSize*/));
                    //}

                    //// TODO: убрать нижнее (сделано для красоты)
                    //for (int x = 0; x < MainData.GroupList.Count; x++)
                    //{
                    //    for (int i = 0; i < (maxRow - 1) * (maxColumn - 7); i++)
                    //    {
                    //        GroupsScheduleTableLayoutGrid.Controls.Add(new TextBox() { ReadOnly = true }, x + 1, i + 1);
                    //    }
                    //}

                    //for (int i = 0; i < (maxRow - 1) * (maxColumn - 7); i++)
                    //{
                    //    GroupsScheduleTableLayoutGrid.Controls.Add(new TextBox() { ReadOnly = true }, ElementPositionXY.Item1, i + 1);
                    //}

                    //GroupsScheduleTableLayoutGrid.Height = GroupsScheduleTableLayoutGrid.GetRowHeights().Sum();

                    //foreach (GroupDataClass x in GroupDataList)
                    //{
                    //    var p = EditGroupScheduleWindow.LoadData<GroupDataClass>();

                    //    if (p.DockableComboBoxesInfoList != null)
                    //    {
                    //        LoadGroupSchedule(x, null);
                    //    }
                    //}
                }

                // Устанавливаем изображение как BackgroundImage для кнопки
                //SettingsButton.Content = GraphicsClass.DrawPencil(100, 100);

                // Устанавливаем режим масштабирования изображения
                //SettingsButton.LayoutTransform = ImageLayout.Stretch; // Растягивает изображение, чтобы оно заполнило кнопку
            });
        }

        // Методы //

        // Метод установки разметки расписания групп по умолчанию

        // TODO: 1) Модифицировать данный метод, когда можно будет управлять
        // классными часами по понедельникам (убирать их)
        private void SetMainWindowDefaults()
        {
            SetMainWindowDefaultGridStyles();

            //GroupsScheduleTableLayoutGrid.Margin = new(5);
            //GroupsScheduleTableLayoutGrid.Background = Brushes.Red;
            GroupsScheduleTableLayoutGrid.Children.Add(MainWindowSeparateLabel);

            SetMainWindowDefaultGrid();

            //// TODO: Создать Unit-тест со следующей проверкой:
            //string Test0 = string.Empty;
            //string Test1 = string.Empty;
            //string Test2 = string.Empty;
            //string Test3 = string.Empty;
            //string Test4 = string.Empty;
            //string Test5 = string.Empty;

            //// У каждой последовательности должен быть свой список!

            //List<int> TemporaryCyclicSequencesListTest0 = new();
            //List<int> TemporaryCyclicSequencesListTest1 = new();
            //List<int> TemporaryCyclicSequencesListTest2 = new();
            //List<int> TemporaryCyclicSequencesListTest3 = new();
            //List<int> TemporaryCyclicSequencesListTest4 = new();
            //List<int> TemporaryCyclicSequencesListTest5 = new();
            //List<int> TemporaryCyclicSequencesListTest6 = new();
            //List<int> TemporaryCyclicSequencesListTest7 = new();

            //for (int i = 0; i < 101; i++)
            //{
            //    if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(i, 11, out int CyclesPassed0, ref TemporaryCyclicSequencesListTest0, 2))
            //    {
            //        Test0 += i.ToString() + " " + $"[{CyclesPassed0}]";
            //    }

            //    if (StaticMethodsClass.MathMethods.IsNumberMatchesAlternatingSequence(i, 2, 4, out int CyclesPassed1, ref TemporaryCyclicSequencesListTest1, 3))
            //    {
            //        Test1 += i.ToString() + " " + $"[{CyclesPassed1}]";
            //    }

            //    if (StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(i, 2, 3, 5, out int CyclesPassed2, ref TemporaryCyclicSequencesListTest2, 4))
            //    {
            //        Test2 += i.ToString() + " " + $"[{CyclesPassed2}]";
            //    }

            //    if (StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(i, 2, 1, 6, out int CyclesPassed3, ref TemporaryCyclicSequencesListTest3, 2))
            //    {
            //        Test3 += i.ToString() + " " + $"[{CyclesPassed3}]";
            //    }

            //    if (StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(i, 2, 3, 5, out int CyclesPassed4, ref TemporaryCyclicSequencesListTest4, 2) && !StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(i, 11, out int CyclesPassed5, ref TemporaryCyclicSequencesListTest5, 2))
            //    {
            //        Test4 += $"{i} {string.Join(" ", TemporaryCyclicSequencesListTest4)} [{CyclesPassed4}]";
            //    }

            //    if (StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(i, 2, 3, 5, out int CyclesPassed6, ref TemporaryCyclicSequencesListTest6, 2))
            //    {
            //        if (!StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(i, 11, out int CyclesPassed7, ref TemporaryCyclicSequencesListTest7, 2))
            //        {
            //            Test5 += $"{i} {string.Join(" ", TemporaryCyclicSequencesListTest6)} [{CyclesPassed6}]";
            //        }
            //    }
            //}

            //MessageBox.Show(Test0);
            //MessageBox.Show(Test1);
            //MessageBox.Show(Test2);
            //MessageBox.Show(Test3);
            //MessageBox.Show(Test4);
            //MessageBox.Show(Test5);

            // Диапазон цикла равен кол-ву встречающихся условий определённого типа
            for (int TotalCountOfArithmeticSequencesConditions = 0; TotalCountOfArithmeticSequencesConditions < 8; TotalCountOfArithmeticSequencesConditions++)
            {
                ArithmeticSequencesList.Add(new());
            }

            for (int TotalCountOfAlternatingSequencesConditions = 0; TotalCountOfAlternatingSequencesConditions < 1; TotalCountOfAlternatingSequencesConditions++)
            {
                AlternatingSequencesList.Add(new());
            }

            for (int TotalCountOfCyclicSequencesConditions = 0; TotalCountOfCyclicSequencesConditions < 2; TotalCountOfCyclicSequencesConditions++)
            {
                CyclicSequencesList.Add(new());
            }

            List<int> TemporaryArithmeticSequenceList_1 = new();
            List<int> TemporaryArithmeticSequenceList_2 = new();
            List<int> TemporaryArithmeticSequenceList_3 = new();
            List<int> TemporaryArithmeticSequenceList_4 = new();
            List<int> TemporaryArithmeticSequenceList_5 = new();
            List<int> TemporaryArithmeticSequenceList_6 = new();
            List<int> TemporaryArithmeticSequenceList_7 = new();
            List<int> TemporaryArithmeticSequenceList_8 = new();

            List<int> TemporaryAlternatingSequenceList_1 = new();

            List<int> TemporaryCyclicSequenceList_2 = new();
            List<int> TemporaryCyclicSequenceList_3 = new();

            // Расчёт всей сетки //

            // разметка (первый столбец) + кол-во дней недель * (время пары + номер пары + НЧ и Ч неделя)
            for (int ColumnIndex = 1; ColumnIndex < 1 + ConstantsClass.NumberOfDaysOfWeek * (1 + 1 + 2 + 2); ColumnIndex++)
            {
                // TODO: данное число не будет "ручным" - оно будет зависеть от расписания каждой группы (3 пары или 5 пар,
                // но пока это не нужно - у всех всегда максимум 4 пары)

                // разметка (первая строка) + число групп * (разметка времени пары, № пары, НЧ/Ч неделя у группы + (в каждом дне недели 4 пары + 1 класс. час по ПН) * 2 строки [предмет, препод. с каб. и индикация])
                for (int RowIndex = 1; RowIndex < 1 + ConstantsClass.NumberOfGroups * (1 + (4 + 1) * 3); RowIndex++)
                {
                    // если уже есть разметка по ПН
                    if (ColumnIndex == 1 || ColumnIndex == 2)
                    {
                        // если уже есть разметка времени (09:00 - 09:45) по понедельникам
                        if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex - 1, 16, out _, ref TemporaryArithmeticSequenceList_1, 2) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex - 2, 16, out _, ref TemporaryArithmeticSequenceList_1, 2) || ColumnIndex == 2 && StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex, 16, out _, ref TemporaryArithmeticSequenceList_1, 2))
                        {
                            continue;
                        }

                        // если уже есть разметка времени (кроме 09:00 - 09:45) и № пары по понедельникам
                        else if (StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex - 1, 3, 4, 5, out _, ref TemporaryCyclicSequenceList_2, 5) || StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex - 2, 3, 4, 5, out _, ref TemporaryCyclicSequenceList_2, 5))
                        {
                            continue;
                        }
                    }

                    // если уже есть разметка времени и № пары за ВТ-ПТ
                    else if ((StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_2, 7) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 1, 6, out _, ref TemporaryArithmeticSequenceList_2, 7)) && (StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex - 1, 3, 4, 5, out _, ref TemporaryCyclicSequenceList_3, 2) || StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex - 2, 3, 4, 5, out _, ref TemporaryCyclicSequenceList_3, 2)))
                    {
                        continue;
                    }

                    // если уже есть разметка чётности недели
                    else if ((StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 1, 6, out _, ref TemporaryArithmeticSequenceList_3, 3) /*НЧ*/ || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 1, 6, out _, ref TemporaryArithmeticSequenceList_4, 5)) /*Ч*/ && StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex, 16, out _, ref TemporaryArithmeticSequenceList_5, 1))
                    {
                        continue;
                    }

                    // если уже добавлена ячейка предмета (на ширину в 2 стиля)
                    else if (StaticMethodsClass.MathMethods.IsNumberMatchesAlternatingSequence(ColumnIndex - 1, 2, 4, out _, ref TemporaryAlternatingSequenceList_1, 3) && StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex, 3, 1, 6, out _, ref TemporaryCyclicSequenceList_0, 2))
                    {
                        continue;
                    }

                    // если уже добавлена ячейка с кнопками (на ширину в 4 стиля)
                    else if ((StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 1, 6, out _, ref TemporaryArithmeticSequenceList_3, 3) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 2, 6, out _, ref TemporaryArithmeticSequenceList_3, 3) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 3, 6, out _, ref TemporaryArithmeticSequenceList_3, 3)) && StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex, 3, 1, 6, out _, ref TemporaryCyclicSequenceList_1, 4))
                    {
                        continue;
                    }

                    // если уже есть ячейка "пробела" 5 пары за ВТ-ПТ
                    else if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_2, 7) && (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex - 1, 16, out _, ref TemporaryArithmeticSequenceList_6, 14) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex - 2, 16, out _, ref TemporaryArithmeticSequenceList_6, 14)) || (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_7, 8) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 1, 6, out _, ref TemporaryArithmeticSequenceList_7, 8) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 2, 6, out _, ref TemporaryArithmeticSequenceList_7, 8) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 3, 6, out _, ref TemporaryArithmeticSequenceList_7, 8) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex - 4, 6, out _, ref TemporaryArithmeticSequenceList_7, 8)) && (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex, 16, out _, ref TemporaryArithmeticSequenceList_6, 14) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex - 1, 16, out _, ref TemporaryArithmeticSequenceList_6, 14) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex - 2, 16, out _, ref TemporaryArithmeticSequenceList_6, 14)))
                    {
                        continue;
                    }

                    TextBox GroupScheduleTextBox = new()
                    {
                        Margin = new(1),
                        //Multiline = true,
                        IsReadOnly = true,
                        HorizontalContentAlignment = HorizontalAlignment.Center,
                        VerticalContentAlignment = VerticalAlignment.Center
                    };

                    int CyclesPassed;

                    // разметка классного часа и его времени по ПН
                    if (ColumnIndex < 7 && StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex, 16, out _, ref TemporaryArithmeticSequenceList_1, 2))
                    {
                        ArithmeticSequencesList[1] = ("RowIndex", TemporaryArithmeticSequenceList_1);

                        // TODO: подлежит отключению
                        // предмет "Классный час" по ПН
                        if (ColumnIndex == 3 || ColumnIndex == 5)
                        {
                            GroupScheduleTextBox.Text = "Классный час";
                            GroupScheduleTextBox.SetValue(Grid.ColumnSpanProperty, 2);
                        }

                        // время классного часа по ПН
                        else if (ColumnIndex == 1)
                        {
                            TextBoxElements.Add("09:00 - 09:45");
                            GroupScheduleTextBox.Text = TextBoxElements[0].ToString();
                            GroupScheduleTextBox.SetValue(Grid.ColumnSpanProperty, 2);
                            GroupScheduleTextBox.SetValue(Grid.RowSpanProperty, 3);
                        }
                    }

                    // разметка времени (кроме 09:00 - 09:45) и № пары по понедельникам
                    else if (ColumnIndex < 3 && StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex, 3, 4, 5, out CyclesPassed, ref TemporaryCyclicSequenceList_2, 5))
                    {
                        CyclicSequencesList[2] = ("RowIndex", TemporaryCyclicSequenceList_2);

                        // время пары по ПН
                        if (ColumnIndex == 1)
                        {
                            TextBoxElements = ConstantsClass.MondayTimeSlotsArray.ToList();

                            try
                            {
                                GroupScheduleTextBox.Text = TextBoxElements[CyclesPassed].ToString();
                            }

                            catch
                            {
                                GroupScheduleTextBox.Text = "Error";
                            }

                            GroupScheduleTextBox.SetValue(Grid.RowSpanProperty, 3);
                        }

                        // номер пары по ПН
                        else if (ColumnIndex == 2)
                        {
                            GroupScheduleTextBox.Text = (CyclesPassed + 1).ToString();
                            GroupScheduleTextBox.SetValue(Grid.RowSpanProperty, 3);
                        }
                    }

                    // разметка времени и номера пары за ВТ-ПТ
                    else if ((StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_2, 7) || StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_7, 8)) && StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex, 3, 4, 5, out CyclesPassed, ref TemporaryCyclicSequenceList_3, 2))
                    {
                        ArithmeticSequencesList[2] = ("ColumnIndex", TemporaryArithmeticSequenceList_2);
                        ArithmeticSequencesList[7] = ("ColumnIndex", TemporaryArithmeticSequenceList_7);
                        CyclicSequencesList[3] = ("RowIndex", TemporaryCyclicSequenceList_3);

                        // время пары за ВТ-ПТ
                        if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_2, 7))
                        {
                            TextBoxElements = ConstantsClass.StandardTimeSlotsArray.ToList();

                            try
                            {
                                GroupScheduleTextBox.Text = TextBoxElements[CyclesPassed].ToString();
                            }

                            catch
                            {
                                GroupScheduleTextBox.Text = "Error";
                            }

                            GroupScheduleTextBox.SetValue(Grid.RowSpanProperty, 3);
                        }

                        // номер пары за ВТ-ПТ
                        else if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_7, 8))
                        {
                            GroupScheduleTextBox.Text = (CyclesPassed + 1).ToString();
                            GroupScheduleTextBox.SetValue(Grid.RowSpanProperty, 3);
                        }
                    }

                    // разметка первой строки данных группы
                    else if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex, 16, out _, ref TemporaryArithmeticSequenceList_5, 1))
                    {
                        ArithmeticSequencesList[5] = ("RowIndex", TemporaryArithmeticSequenceList_5);

                        if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_8, 1))
                        {
                            ArithmeticSequencesList[8] = ("ColumnIndex", TemporaryArithmeticSequenceList_8);

                            GroupScheduleTextBox.Text = "Время пары";
                        }

                        else if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_0, 2))
                        {
                            GroupScheduleTextBox.Text = "№";
                        }

                        else if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_3, 3))
                        {
                            ArithmeticSequencesList[3] = ("ColumnIndex", TemporaryArithmeticSequenceList_3);

                            GroupScheduleTextBox.Text = "НЧ";
                            GroupScheduleTextBox.SetValue(Grid.ColumnSpanProperty, 2);
                        }

                        else if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_4, 5))
                        {
                            ArithmeticSequencesList[4] = ("ColumnIndex", TemporaryArithmeticSequenceList_4);

                            GroupScheduleTextBox.Text = "Ч";
                            GroupScheduleTextBox.SetValue(Grid.ColumnSpanProperty, 2);
                        }
                    }

                    // разметка ячейки предмета
                    else if (StaticMethodsClass.MathMethods.IsNumberMatchesAlternatingSequence(ColumnIndex, 2, 4, out _, ref TemporaryAlternatingSequenceList_1, 3) && StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex, 3, 1, 6, out _, ref TemporaryCyclicSequenceList_0, 2))
                    {
                        AlternatingSequencesList[1] = ("ColumnIndex", TemporaryAlternatingSequenceList_1);

                        GroupScheduleTextBox.SetValue(Grid.ColumnSpanProperty, 2);
                    }

                    // разметка кнопок индикации
                    else if (StaticMethodsClass.MathMethods.IsNumberMatchesAlternatingSequence(ColumnIndex, 2, 4, out _, ref TemporaryAlternatingSequenceList_1, 3) && StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex, 3, 1, 6, out _, ref TemporaryCyclicSequenceList_1, 4))
                    {
                        Grid GroupScheduleUserUIGrid = CreateMainWindowGroupScheduleUserUIGrid();

                        GroupScheduleUserUIGrid.SetValue(Grid.ColumnProperty, ColumnIndex);
                        GroupScheduleUserUIGrid.SetValue(Grid.RowProperty, RowIndex);
                        GroupsScheduleTableLayoutGrid.Children.Add(GroupScheduleUserUIGrid);
                        GroupScheduleUserUIGrid.SetValue(Grid.ColumnSpanProperty, 4);

                        continue;
                    }

                    // разметка "пробела" 5 пары за ВТ-ПТ
                    else if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_2, 7) && StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex, 16, out _, ref TemporaryArithmeticSequenceList_6, 14))
                    {
                        ArithmeticSequencesList[2] = ("ColumnIndex", TemporaryArithmeticSequenceList_2);
                        ArithmeticSequencesList[6] = ("RowIndex", TemporaryArithmeticSequenceList_6);

                        //GroupScheduleTextBox = new CustomTextBox()
                        //{

                        //    //BottomBorderColor = Color.Black,
                        //    BottomBorderThickness = 3,
                        //    //Dock = DockStyle.Fill,
                        //    Margin = new(1, 1, 1, 0),
                        //    //Multiline = true,
                        //    IsReadOnly = true,
                        //    HorizontalContentAlignment = HorizontalAlignment.Center,
                        //    VerticalContentAlignment = VerticalAlignment.Center
                        //};

                        GroupScheduleTextBox.SetValue(Grid.ColumnProperty, ColumnIndex);
                        GroupScheduleTextBox.SetValue(Grid.RowProperty, RowIndex);
                        GroupsScheduleTableLayoutGrid.Children.Add(GroupScheduleTextBox);
                        GroupScheduleTextBox.SetValue(Grid.ColumnSpanProperty, 6);
                        GroupScheduleTextBox.SetValue(Grid.RowSpanProperty, 3);
                        GroupScheduleTextBox.Background = Brushes.LightGray;

                        continue;
                    }

                    //if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(RowIndex, 11, out _, ref TemporaryArithmeticSequenceList_, 11))
                    //{
                    //    GroupScheduleTextBox = new CustomTextBox()
                    //    {
                    //        //BottomBorderColor = Color.Black,
                    //        BottomBorderThickness = 3,
                    //        Margin = new(1, 1, 1, 0),
                    //        //Multiline = true,
                    //        IsReadOnly = true,
                    //        HorizontalContentAlignment = HorizontalAlignment.Center,
                    //        VerticalContentAlignment = VerticalAlignment.Center
                    //    };
                    //}

                    if (string.IsNullOrWhiteSpace(GroupScheduleTextBox.Text))
                    {
                        GroupScheduleTextBox.Background = Brushes.MistyRose;
                    }

                    GroupScheduleTextBox.SetValue(Grid.ColumnProperty, ColumnIndex);
                    GroupScheduleTextBox.SetValue(Grid.RowProperty, RowIndex);
                    GroupsScheduleTableLayoutGrid.Children.Add(GroupScheduleTextBox);
                }
            }

            ////!!!!! Отладка //

            //// Создаём общий список, в который будем вкладывать элементы из всех трёх списков
            //List<(string ComparedParameterName, string SequenceType, List<int> SequencesNumbers)> CombinedList = new();

            //// Добавляем элементы из каждого списка в общий список с указанием типа последовательности
            //CombinedList.AddRange(ArithmeticSequencesList.Select((seq, index) => (seq.ComparedParameterName, "Арифметическая последовательность " + index, seq.SequencesNumbers)));
            //CombinedList.AddRange(AlternatingSequencesList.Select((seq, index) => (seq.ComparedParameterName, "Последовательность с чередованием " + index, seq.SequencesNumbers)));
            //CombinedList.AddRange(CyclicSequencesList.Select((seq, index) => (seq.ComparedParameterName, "Циклическая последовательность " + index, seq.SequencesNumbers)));

            //// Используем LINQ для вывода элементов каждого списка
            //foreach ((string ComparedParameterName, string SequenceType, List<int> SequencesNumbers) in CombinedList)
            //{
            //    if (SequencesNumbers != null)
            //    {
            //        MessageBox.Show($"Список {ComparedParameterName} ({SequenceType}): {string.Join(", ", SequencesNumbers)}");
            //    }

            //    else
            //    {
            //        MessageBox.Show($"Список {ComparedParameterName} ({SequenceType}): [!] Список пуст");
            //    }
            //}
        }

        private void SetMainWindowDefaultGridStyles()
        {
            /*
            CustomTextBox OddAndEvenWeekModeTextBox = new()
            {
                 LeftBorderColor = Color.Red,
                 RightBorderColor = Color.Blue,
                 TopBorderThickness = 10,
                 //TopBorderColor = Color.Green,
                 BottomBorderThickness = 10,
                 LeftBorderThickness = 1000,
                 RightBorderThickness = 12,
                 Dock = DockStyle.Fill,
                 Margin = new(1),
                 ReadOnly = true,
                 TextAlign = HorizontalAlignment.Center
            };
            
            OddAndEvenWeekModeTextBox.Click += (_, _) =>
            {
                OddAndEvenWeekModeTextBox.Dock = DockStyle.None;
                OddAndEvenWeekModeTextBox.Width = 100;
            };
             */

            // Установка размеров SeparateLabel (нулевой стиль - его не считаем)
            GroupsScheduleTableLayoutGrid.ColumnDefinitions[0].Width = new(100);
            GroupsScheduleTableLayoutGrid.RowDefinitions[0].Height = new(50);

            ArithmeticSequencesList.Add(new());

            AlternatingSequencesList.Add(new());
            List<int> TemporaryAlternatingSequenceList_0 = new();

            // отсчёт с 1, т. к. уже создан первый стиль колонки
            for (int ColumnIndex = 1; ColumnIndex < 1 + ConstantsClass.NumberOfDaysOfWeek * (1 + 1 + 2 + 2); ColumnIndex++)
            {
                // ширина номера пары
                if (StaticMethodsClass.MathMethods.IsNumberMatchesArithmeticSequence(ColumnIndex, 6, out _, ref TemporaryArithmeticSequenceList_0, 2))
                {
                    ArithmeticSequencesList[0] = ("ColumnIndex", TemporaryArithmeticSequenceList_0);

                    GroupsScheduleTableLayoutGrid.ColumnDefinitions.Add(new() { Width = new(25) });
                }

                // ширина номера кабинета
                else if (StaticMethodsClass.MathMethods.IsNumberMatchesAlternatingSequence(ColumnIndex, 2, 4, out _, ref TemporaryAlternatingSequenceList_0, 4))
                {
                    AlternatingSequencesList[0] = ("ColumnIndex", TemporaryAlternatingSequenceList_0);

                    GroupsScheduleTableLayoutGrid.ColumnDefinitions.Add(new() { Width = new(40) });
                }

                // стандартная ширина
                else
                {
                    GroupsScheduleTableLayoutGrid.ColumnDefinitions.Add(new() { Width = new(100 /*110*/) });
                }
            }

            CyclicSequencesList.Add(new());
            CyclicSequencesList.Add(new());

            // отсчёт с 1, т. к. уже создан первый стиль строки
            for (int RowIndex = 1; RowIndex < 1 + ConstantsClass.NumberOfGroups * (1 + (4 + 1) * 3); RowIndex++)
            {
                // Высота ячейки предмета
                if (StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex, 3, 1, 6, out _, ref TemporaryCyclicSequenceList_0, 2))
                {
                    CyclicSequencesList[0] = ("RowIndex", TemporaryCyclicSequenceList_0);

                    GroupsScheduleTableLayoutGrid.RowDefinitions.Add(new() { Height = new(60) });
                }

                // Высота ячейки кнопок и изображений индикации
                else if (StaticMethodsClass.MathMethods.IsNumberMatchesCyclicSequence(RowIndex, 3, 1, 6, out _, ref TemporaryCyclicSequenceList_1, 4))
                {
                    CyclicSequencesList[1] = ("RowIndex", TemporaryCyclicSequenceList_1);

                    GroupsScheduleTableLayoutGrid.RowDefinitions.Add(new() { Height = new(50) });
                }

                // Высота ячейки преподавателя и кабинета
                else
                {
                    GroupsScheduleTableLayoutGrid.RowDefinitions.Add(new() { Height = new(40) });
                }
            }
        }

        // Метод установки дефолтной разметки Grid
        private void SetMainWindowDefaultGrid()
        {
            // загрузка дней недель
            int ColumnIndex = 0;

            // Разметка дней недели
            foreach (string DayOfWeek in ConstantsClass.DaysOfWeekArray)
            {
                Label DayOfWeekLabel = new()
                {
                    Background = Brushes.LightGray,
                    //BorderStyle = BorderStyle.None,
                    Content = DayOfWeek,
                    HorizontalContentAlignment = HorizontalAlignment.Center,
                    VerticalContentAlignment = VerticalAlignment.Center,
                    Margin = new(1)
                };

                DayOfWeekLabel.SetValue(Grid.ColumnProperty, ColumnIndex + 1);
                DayOfWeekLabel.SetValue(Grid.RowProperty, 0);
                GroupsScheduleTableLayoutGrid.Children.Add(DayOfWeekLabel);
                DayOfWeekLabel.SetValue(Grid.ColumnSpanProperty, 6); // заполнение элементом 5 соседних колонок

                ColumnIndex += 6;
            }

            // загрузка групп //
            bool DataSuccessfullyLoaded = false;
            int RowIndex = 0;
            object GroupListVariable;

            if (MainData.GroupList != null)
            {
                GroupListVariable = MainData.GroupList;
                DataSuccessfullyLoaded = true;
            }

            else // загрузка данных в автономном режиме
            {
                GroupListVariable = ConstantsClass.GroupNamesArray.ToList();
            }

            if (GroupListVariable is List<string> GroupList)
            {
                //if (MainData.GroupList != null && DataSuccessfullyLoaded == true)
                //{
                //    while (GroupsScheduleTableLayoutGrid.ColumnCount - 1 != MainData.GroupList.Count * 2)
                //    {
                //        if (GroupsScheduleTableLayoutGrid.ColumnCount - 1 < MainData.GroupList.Count * 2)
                //        {
                //            GroupsScheduleTableLayoutGrid.ColumnCount++;
                //            GroupsScheduleTableLayoutGrid.ColumnStyles.Add(new(SizeType.Absolute, 100));
                //        }

                //        else if (GroupsScheduleTableLayoutGrid.ColumnCount - 1 > MainData.GroupList.Count * 2)
                //        {
                //            GroupsScheduleTableLayoutGrid.ColumnCount--;
                //            GroupsScheduleTableLayoutGrid.ColumnStyles.RemoveAt(GroupsScheduleTableLayoutGrid.ColumnStyles.Count - 1);
                //        }
                //    }
                //}

                foreach (string Group in GroupList)
                {
                    GroupData = new()
                    {
                        GroupName = Group
                    };

                    GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group); // переменная загруженных данных проекта

                    //if (GroupData.GroupName != null)
                    {
                        GroupDataList.Add(GroupData);
                    }

                    int[] array = { 2, 3, 1 };
                    LabelWithButtons GroupLabelWithButtons = new(array, new() { Source = (ImageSource)TryFindResource("PencilImage_1") })
                    {
                        Background = Brushes.LightGray,
                        //BorderStyle = BorderStyle.None,
                        Margin = new(1),
                        Content = Group,
                        HorizontalContentAlignment = HorizontalAlignment.Center,
                        VerticalContentAlignment = VerticalAlignment.Center
                    };

                    LabelWithButtons.ClickHandler? AddButtonClickHandler = null;
                    LabelWithButtons.ClickHandler? CustomButtonClickHandler = null;

                    AddButtonClickHandler = (sender, e) =>
                    {
                        EditGroupScheduleWindow EditGroupScheduleWindow = new(string.Empty)
                        {
                            GroupInTitle = Group,
                            Title = $"«Электронный редактор расписания» — Окно редактирования расписания группы ({Group})"
                        };

                        // Подписка на событие изменения данных
                        EditGroupScheduleWindow.OnDataChanged += () =>
                        {
                            GroupData.GroupName = Group;
                            GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group);
                            LoadGroupSchedule(GroupData, GroupLabelWithButtons);
                        };

                        EditGroupScheduleWindow.Closed += (sender, e) =>
                        {
                            //GroupData.GroupName = Group;
                            //GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group);
                            //LoadGroupSchedule(GroupData, GroupLabelWithButtons);
                            GroupLabelWithButtons.AddButtonClick += AddButtonClickHandler;
                            GroupLabelWithButtons.CustomButtonClick += CustomButtonClickHandler;
                        };

                        GroupLabelWithButtons.AddButtonClick -= AddButtonClickHandler;
                        GroupLabelWithButtons.CustomButtonClick -= CustomButtonClickHandler;
                        EditGroupScheduleWindow.Show();
                    };

                    CustomButtonClickHandler += (sender, e) =>
                    {
                        EditGroupScheduleWindow EditGroupScheduleWindow = new(Group);

                        // Подписка на событие изменения данных
                        EditGroupScheduleWindow.OnDataChanged += () =>
                        {
                            GroupData.GroupName = Group;
                            GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group);
                            LoadGroupSchedule(GroupData, GroupLabelWithButtons);
                        };

                        EditGroupScheduleWindow.Closed += (sender, e) =>
                        {
                            //GroupData.GroupName = Group;
                            //GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>(Group);
                            //LoadGroupSchedule(GroupData, GroupLabelWithButtons);
                            GroupLabelWithButtons.CustomButtonClick += CustomButtonClickHandler;
                            GroupLabelWithButtons.AddButtonClick += AddButtonClickHandler;
                        };

                        GroupLabelWithButtons.CustomButtonClick -= CustomButtonClickHandler;
                        GroupLabelWithButtons.AddButtonClick -= AddButtonClickHandler;
                        EditGroupScheduleWindow.Show();
                    };

                    if (DataSuccessfullyLoaded)
                    {
                        GroupLabelWithButtons.AddButtonClick += AddButtonClickHandler;
                        GroupLabelWithButtons.CustomButtonClick += CustomButtonClickHandler;
                    }

                    else
                    {
                        // TODO: в случае незагрузки данных убрать кнопку редакции
                        LabelWithButtons.ClickHandler? AddButtonClickHandlerWithoutMainData = null;

                        AddButtonClickHandlerWithoutMainData = (sender, e) =>
                        {
                            MessageBoxResult = MessageBox.Show("Внимание, основные данные не были загружены, вы не сможете использовать автозаполнение или связи! Заполнение доступно только в ручном режиме.\n\nВы уверены, что хотите продолжить?", "Работа без данных (ручное заполнение данных)", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);

                            if (MessageBoxResult == MessageBoxResult.Yes)
                            {
                                EditGroupScheduleWindow EditGroupScheduleWindow = new(Group);

                                EditGroupScheduleWindow.Closed += (sender, e) =>
                                {
                                    GroupData = EditGroupScheduleWindow.LoadData<GroupDataClass>();
                                    LoadGroupSchedule(GroupData, GroupLabelWithButtons);
                                    GroupLabelWithButtons.AddButtonClick += AddButtonClickHandlerWithoutMainData;
                                };

                                GroupLabelWithButtons.AddButtonClick -= AddButtonClickHandlerWithoutMainData;
                                EditGroupScheduleWindow.Show();
                            }
                        };

                        GroupLabelWithButtons.AddButtonClick += AddButtonClickHandlerWithoutMainData;
                    }

                    // TODO: Понять, зачем оно
                    //Control? DefaultGroupLabelWithButtonsControl = null;

                    //if (GroupsScheduleTableLayoutGrid.GetControlFromPosition(ColumnIndex + 3, 1) != null)
                    //{
                    //    DefaultGroupLabelWithButtonsControl = GroupsScheduleTableLayoutGrid.GetControlFromPosition(ColumnIndex + 3, 1);
                    //    GroupsScheduleTableLayoutGrid.Controls.Remove(DefaultGroupLabelWithButtonsControl);
                    //}

                    GroupLabelWithButtons.SetValue(Grid.ColumnProperty, 0);
                    GroupLabelWithButtons.SetValue(Grid.RowProperty, RowIndex + 1);
                    GroupsScheduleTableLayoutGrid.Children.Add(GroupLabelWithButtons);
                    GroupLabelWithButtons.SetValue(Grid.RowSpanProperty, 16);

                    RowIndex += 16;
                }
            }
        }

        // Метод создание панели индикации
        private Grid CreateMainWindowGroupScheduleUserUIGrid()
        {
            Image TeacherReplacementModeImage = new()
            {
                Source = (ImageSource)Application.Current.Resources["SwapImage_6"]
            };

            ToolTip TeacherReplacementModeImageToolTip = new()
            {
                Content = "Был назначен преподаватель на замену.\nНажмите, чтобы открыть окно группы",
                Padding = new(10),
                Placement = PlacementMode.Mouse
            };

            ToolTipService.SetInitialShowDelay(TeacherReplacementModeImage, 0); // установка задержки перед отображением ToolTip в 0 миллисекунд

            TeacherReplacementModeImage.MouseEnter += (sender, e) =>
            {
                if (true /*TeacherReplacementModeIndicator.Fill == Brushes.Black*/ /*bool заместо проверки по цвету*/)
                {
                    TeacherReplacementModeImage.Cursor = Cursors.Hand;
                    ToolTipService.SetToolTip(TeacherReplacementModeImage, TeacherReplacementModeImageToolTip);
                    ////удаление
                    //ToolTipService.SetToolTip(TeacherReplacementModeImage, null);
                }
            };

            TeacherReplacementModeImage.MouseLeftButtonDown += (sender, e) =>
            {
                if (true)
                {
                    MessageBox.Show("Меняете преподавателя!");
                }
            };

            Border TeacherReplacementModeImageBorder = new()
            {
                BorderBrush = Brushes.Gray,
                BorderThickness = new(1),
                Child = TeacherReplacementModeImage,
                Width = 25,
                Height = 25,
                Margin = new(0, 0, 0, 5)
            };

            Ellipse TeacherReplacementModeIndicator = new()
            {
                Width = 10,
                Height = 10,
                Fill = Brushes.Black,
                Stroke = Brushes.Gray,
                StrokeThickness = 1
            };

            StackPanel TeacherReplacementModeInfoStackPanel = new()
            {
                Margin = new(0, 0, 25, 0)
            };

            TeacherReplacementModeInfoStackPanel.Children.Add(TeacherReplacementModeImageBorder);
            TeacherReplacementModeInfoStackPanel.Children.Add(TeacherReplacementModeIndicator);

            Image LectureModeImage = new()
            {
                Source = (ImageSource)Application.Current.Resources["LectureImage_1"]
            };

            ToolTip LectureModeImageToolTip = new()
            {
                Content = "Поставлен режим \"лекция\" для данной группы.\nНажмите, чтобы открыть окно группы",
                Padding = new(10),
                Placement = PlacementMode.Mouse
            };

            // жёлтый цвет, если разрешили, красный = если было так загружено

            ToolTipService.SetInitialShowDelay(LectureModeImage, 0); // установка задержки перед отображением ToolTip в 0 миллисекунд

            LectureModeImage.MouseEnter += (sender, e) =>
            {
                if (true /*TeacherReplacementModeIndicator.Fill == Brushes.Black*/ /*bool заместо проверки по цвету*/)
                {
                    LectureModeImage.Cursor = Cursors.Hand;
                    ToolTipService.SetToolTip(LectureModeImage, LectureModeImageToolTip);
                    ////удаление
                    //ToolTipService.SetToolTip(TeacherReplacementModeImage, null);
                }
            };

            LectureModeImage.MouseLeftButtonDown += (sender, e) =>
            {
                if (true)
                {
                    MessageBox.Show("Меняете режим лекции!");
                }
            };

            Border LectureModeImageBorder = new()
            {
                BorderBrush = Brushes.Gray,
                BorderThickness = new(1),
                Child = LectureModeImage,
                Width = 25,
                Height = 25,
                Margin = new(0, 0, 0, 5)
            };

            Ellipse LectureModeIndicator = new()
            {
                Width = 10,
                Height = 10,
                Fill = Brushes.Black,
                Stroke = Brushes.Gray,
                StrokeThickness = 1
            };

            StackPanel LectureModeInfoStackPanel = new()
            {
                Margin = new(0, 0, 25, 0)
            };

            LectureModeInfoStackPanel.Children.Add(LectureModeImageBorder);
            LectureModeInfoStackPanel.Children.Add(LectureModeIndicator);

            Image TeacherIsNotInDBStatusImage = new()
            {
                //жёлтый цвет, если разрешили, красный = если было так загружено
                //AllowMissingDataModeActivated
                Source = (ImageSource)Application.Current.Resources["DataBaseErrorImage_1"]
            };

            ToolTip TeacherIsNotInDBStatusImageToolTip = new()
            {
                Content = "Сопоставление данных с БД было отключено.\nНажмите, чтобы открыть окно группы",
                Background = Brushes.Yellow,
                Foreground = Brushes.Black,
                Padding = new(10),
                Placement = PlacementMode.Mouse
            };

            // жёлтый цвет, если разрешили, красный = если было так загружено

            ToolTipService.SetInitialShowDelay(TeacherIsNotInDBStatusImage, 0); // установка задержки перед отображением ToolTip в 0 миллисекунд

            TeacherIsNotInDBStatusImage.MouseEnter += (sender, e) =>
            {
                if (true /*TeacherReplacementModeIndicator.Fill == Brushes.Black*/ /*bool заместо проверки по цвету*/)
                {
                    TeacherIsNotInDBStatusImage.Cursor = Cursors.Hand;
                    ToolTipService.SetToolTip(TeacherIsNotInDBStatusImage, TeacherIsNotInDBStatusImageToolTip);
                    ////удаление
                    //ToolTipService.SetToolTip(TeacherReplacementModeImage, null);
                }
            };

            TeacherIsNotInDBStatusImage.MouseLeftButtonDown += (sender, e) =>
            {
                if (true)
                {
                    MessageBox.Show("Меняете преподавателя!");
                }
            };

            Border TeacherIsNotInDBStatusImageBorder = new()
            {
                BorderBrush = Brushes.Gray,
                BorderThickness = new(1),
                Child = TeacherIsNotInDBStatusImage,
                Width = 25,
                Height = 25,
                Margin = new(0, 0, 0, 5)
            };

            Ellipse TeacherIsNotInDBStatusIndicator = new()
            {
                Width = 10,
                Height = 10,
                Fill = Brushes.Black,
                Stroke = Brushes.Gray,
                StrokeThickness = 1
            };

            StackPanel TeacherIsNotInDBStatusInfoStackPanel = new()
            {
                Margin = new(0, 0, 0, 0)
            };

            TeacherIsNotInDBStatusInfoStackPanel.Children.Add(TeacherIsNotInDBStatusImageBorder);
            TeacherIsNotInDBStatusInfoStackPanel.Children.Add(TeacherIsNotInDBStatusIndicator);

            StackPanel GroupScheduleUserUIStackPanel = new()
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };

            GroupScheduleUserUIStackPanel.Children.Add(TeacherReplacementModeInfoStackPanel);
            GroupScheduleUserUIStackPanel.Children.Add(LectureModeInfoStackPanel);
            GroupScheduleUserUIStackPanel.Children.Add(TeacherIsNotInDBStatusInfoStackPanel);

            Grid GroupScheduleUserUIGrid = new()
            {
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment = VerticalAlignment.Stretch,
                Background = Brushes.White,
                Margin = new(1)
            };

            GroupScheduleUserUIGrid.Children.Add(GroupScheduleUserUIStackPanel);

            return GroupScheduleUserUIGrid;
        }

        private void ErrorProvider()
        {
            //MainData.LoadData<MainDataClass>();

            if (MainData.ErrorMessage != null)
            {
                MessageBox.Show(MainData.ErrorMessage + "\n\nВнимание, основные данные не были загружены!", "Файл хранимых данных повреждён!", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            string ErrorMessageMainPart = string.Empty;
            List<string> GroupFileWithErrorList = new();

            IEnumerator<string>? MainDataGroupListEnumerator = null;

            if (MainData.GroupList != null)
            {
                MainDataGroupListEnumerator = MainData.GroupList.GetEnumerator();
            }

            else
            {
                MessageBox.Show("Внимание, невозможно проверить на корректность файлы хранимых данных групп, поскольку файл хранимых основных данных не содержит в себе информацию о группах!", "Ошибка анализа файлов хранимых данных групп!", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            foreach (GroupDataClass GroupData in GroupDataList)
            {
                if (MainDataGroupListEnumerator != null)
                {
                    MainDataGroupListEnumerator.MoveNext();
                    GroupData.GroupName = MainDataGroupListEnumerator.Current;
                    //GroupData.LoadData<GroupDataClass>();

                    if (GroupData.ErrorMessage != null)
                    {
                        GroupFileWithErrorList.Add($"{GroupData.GroupName}");
                        ErrorMessageMainPart = $"Внимание! Количество повреждённых файлов: {GroupFileWithErrorList.Count}.\n\nБыли повреждены следующие файлы хранимых данных групп:";
                    }
                }
            }

            if (ErrorMessageMainPart != string.Empty)
            {
                string NumberedGroupFilesWithError = string.Empty;

                for (int i = 0; i < GroupFileWithErrorList.Count; i++)
                {
                    if (i != GroupFileWithErrorList.Count - 1)
                    {
                        NumberedGroupFilesWithError += $"{i + 1}) {GroupFileWithErrorList[i]};\n";
                    }

                    else
                    {
                        NumberedGroupFilesWithError += $"{i + 1}) {GroupFileWithErrorList[i]}.";
                    }
                }

                MessageBox.Show($"{ErrorMessageMainPart}\n\n{NumberedGroupFilesWithError}", "Файлы хранимых данных групп повреждены!", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadGroupSchedule(GroupDataClass GroupData, LabelWithButtons? GroupLabelWithButtons)
        {
            if (GroupData.GroupName == null)
            {
                return;
            }
            //GroupData.GroupName = Group;
            //GroupData = new();
            //GroupData.GroupName = Group;
            //GroupData = GroupData.LoadData<GroupDataClass>();

            if (GroupData./*MainWindow*/ComboBoxesInfoList != null)
            {
                GroupTextBoxesInfoList = GroupData./*MainWindow*/ComboBoxesInfoList.ToList();
            }

            // TODO: если в сохранённых данных нет сведений о "" - то есть если в списке группы не была назначена
            // 4-я пара - не было сохранено это, то нумерация сбивается (ведь "" и отсутствие данных отличается!)

            (int Column, int Row) CurrentGroupLabelWithButtonsPosition = new();

            if (GroupLabelWithButtons != null)
            {
                CurrentGroupLabelWithButtonsPosition = (Grid.GetColumn(GroupLabelWithButtons), Grid.GetRow(GroupLabelWithButtons));
            }

            else
            {
                foreach (TextBlock TextBlock in GroupsScheduleTableLayoutGrid.Children)
                {
                    if (TextBlock.Text == GroupData.GroupName)
                    {
                        TextBlock CurrentGroupLabelWithButtons = TextBlock;
                        CurrentGroupLabelWithButtonsPosition = (Grid.GetColumn(CurrentGroupLabelWithButtons), Grid.GetRow(CurrentGroupLabelWithButtons));

                        break;
                    }
                }
            }

            //System.ArgumentNullException!!!
            //ElementPosition = GroupsScheduleTableLayoutGrid.GetCellPosition(SerachingControl);
            //DockableComboBoxDay = GroupScheduleEditorTableLayoutPanel.GetControlFromPosition(ElementPosition.Column, 0).Text;

            foreach ((int Column, int Row, string Day, string Week, string Text) in GroupTextBoxesInfoList)
            {
                if (Text == "")
                {
                    continue;
                }

                // Получаем контрол из позиции
                TextBlock? TextBlock = null;

                switch (Day)
                {
                    case "Понедельник":

                        if (Week == "НЧ")
                        {
                            if (Row == 3 || Row % 4 == 3)
                            {
                                if (Column % 2 != 0)
                                {
                                    TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column && Grid.GetRow(ChildControl) == Row - 1);
                                }

                                else if (Column % 2 == 0)
                                {
                                    TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 1 && Grid.GetRow(ChildControl) == Row);
                                }
                            }

                            else if (Row == 4 || Row % 4 == 4)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column && Grid.GetRow(ChildControl) == Row - 1);
                            }
                        }

                        else
                        {
                            if (Row == 3 || Row % 4 == 3)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 3 && Grid.GetRow(ChildControl) == Row + 1);
                            }

                            else if (Row == 4 || Row % 4 == 4)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 2 && Grid.GetRow(ChildControl) == Row + 1);
                            }
                        }

                        break;

                    case "Вторник":

                        if (Week == "НЧ")
                        {
                            if (Row == 3 || Row % 4 == 3)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 1 && Grid.GetRow(ChildControl) == Row + 12);
                            }

                            else if (Row == 4 || Row % 4 == 4)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column && Grid.GetRow(ChildControl) == Row + 11);
                            }
                        }

                        else
                        {
                            if (Row == 3 || Row % 4 == 3)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 3 && Grid.GetRow(ChildControl) == Row + 12);
                            }

                            else if (Row == 4 || Row % 4 == 4)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 2 && Grid.GetRow(ChildControl) == Row + 11);
                            }
                        }

                        break;

                    case "Среда":
                    case "Четверг":
                    case "Пятница":

                        if (Week == "НЧ")
                        {
                            if (Row == 3 || Row % 4 == 3)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 1 && Grid.GetRow(ChildControl) == Row + 10);
                            }

                            else if (Row == 4 || Row % 4 == 4)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column && Grid.GetRow(ChildControl) == Row + 9);
                            }
                        }

                        else
                        {
                            if (Row == 3 || Row % 4 == 3)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 3 && Grid.GetRow(ChildControl) == Row + 10);
                            }

                            else if (Row == 4 || Row % 4 == 4)
                            {
                                TextBlock = GroupsScheduleTableLayoutGrid.Children.OfType<TextBlock>().FirstOrDefault(ChildControl => Grid.GetColumn(ChildControl) == CurrentGroupLabelWithButtonsPosition.Column + 2 && Grid.GetRow(ChildControl) == Row + 9);
                            }
                        }

                        break;
                }

                if (TextBlock != null)
                {
                    TextBlock.Text = Text;
                    TextBlock.Background = Brushes.White;
                }
            }
        }

        private void SetWindowDefaults()
        {
            //Shown += (sender, e) =>
            //{
            //    GroupsScheduleTablePanel.HorizontalScroll.Value = 0;
            //    GroupsScheduleTablePanel.VerticalScroll.Value = 0;
            //};

            int ColumnWidthSum = (int)(40 + GroupsScheduleTableLayoutGrid.Margin.Left + GroupsScheduleTableLayoutGrid.Margin.Right)/* + EditMainDataButtonAndSettingsButtonSplitContainer.Width*/;
            int RowHeightSum = (int)(60 + GroupsScheduleTableLayoutGrid.Margin.Top + GroupsScheduleTableLayoutGrid.Margin.Bottom);

            for (int i = 0; i < 12 && i < GroupsScheduleTableLayoutGrid.ColumnDefinitions.Count; i++)
            {
                ColumnWidthSum += (int)GroupsScheduleTableLayoutGrid.ColumnDefinitions[i].Width.Value;

                if (i == 6)
                {
                    MinWidth = ColumnWidthSum;
                }
            }

            for (int i = 0; i < 12 && i < GroupsScheduleTableLayoutGrid.RowDefinitions.Count; i++)
            {
                RowHeightSum += (int)GroupsScheduleTableLayoutGrid.RowDefinitions[i].Height.Value;
            }

            MinHeight = RowHeightSum;

            Width = ColumnWidthSum;
            Height = RowHeightSum;

            // Рассчитываем новые координаты для центрирования окна на экране
            double PositionX = SystemParameters.PrimaryScreenWidth / 2 - Width / 2;
            double PositionY = SystemParameters.PrimaryScreenHeight / 2 - Height / 2;

            // Устанавливаем новое положение окна
            Left = PositionX;
            Top = PositionY;
        }
    }
}