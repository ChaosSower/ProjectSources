﻿namespace Digital_Schedule_Editor.Classes
{
    internal class ConstantsClass
    {
        public const int NumberOfDaysOfWeek = 5;
        public static readonly string[] DaysOfWeekArray = new string[NumberOfDaysOfWeek]
        {
            "Понедельник",
            "Вторник",
            "Среда",
            "Четверг",
            "Пятница"
        };

        public const int NumberOfGroups = 23;
        public static readonly string[] GroupNamesArray = new string[NumberOfGroups]
        {
            "ИСП 111",
            "ИСП 111д",
            "ИСП 121",
            "ИСП 131",
            "ИСП 151",
            "ИСП 211",
            "ИСП 211д",
            "ИСП 221",
            "ИСП 231",
            "ИСП 231д",
            "ИСП 251",
            "ИСП 251д",
            "ИСП 271",
            "ИСП 271д",
            "ИСП 291д",
            "ИСП 311",
            "ИСП 311д",
            "ИСП 321",
            "ИСП 331",
            "ИСП 411",
            "ИСП 411д",
            "ИСП 431",
            "ИСП 431д"
        };

        public const int NumberOfLessons = 5;
        public static readonly string[] NumbersOfLessonArray = new string[NumberOfLessons]
        {
            "1",
            "2",
            "3",
            "4",
            "5"
        };

        public const int NumberOfMondayTimeSlots = 4;
        public static readonly string[] MondayTimeSlotsArray = new string[NumberOfMondayTimeSlots]
        {
            "09:55 - 11:25",
            "11:35 - 13:05",
            "14:05 - 15:35",
            "15:45 - 17:15"
        };

        public const int NumberOfStandardTimeSlots = 5;
        public static readonly string[] StandardTimeSlotsArray = new string[NumberOfStandardTimeSlots]
        {
            "09:00 - 10:30",
            "10:40 - 12:10",
            "13:10 - 14:40",
            "14:55 - 16:20",
            "16:30 - 18:00"
        };
    }
}