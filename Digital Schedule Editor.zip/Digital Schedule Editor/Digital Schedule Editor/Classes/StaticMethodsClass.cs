﻿// TODO: ознакомься с partial https://metanit.com/sharp/tutorial/3.21.php

namespace Digital_Schedule_Editor.Classes
{
    internal static partial class StaticMethodsClass
    {
        internal static partial class MathMethods
        {
            /// <summary>
            /// Статический метод проверки соответствия числа простой последовательности
            /// </summary>
            /// <param name="VerifyingNumber">Проверяемое число</param>
            /// <param name="SequenceStep">Шаг последовательности (~~сколько чисел надо пройти~~ (на сколько надо прибавить), чтобы последовательность считалась завершённой)</param>
            /// <param name="CyclesPassed">Количество пройденных циклов последовательности</param>
            /// <param name="ArithmeticSequenceList">Список чисел, удовлетворяющих заданной простой последовательности</param>
            /// <param name="InitializingIndex">Число начала отсчёта последовательности</param>
            /// <returns>Состояние соответствия указанного числа последовательности, количество пройденных циклов последовательности, список чисел, удовлетворяющих последовательности</returns>
            public static bool IsNumberMatchesArithmeticSequence(int VerifyingNumber, int SequenceStep, out int CyclesPassed, ref List<int> ArithmeticSequenceList, int InitializingIndex = 0)
            {
                // Вычисляем, сколько полных циклов прошло
                CyclesPassed = (VerifyingNumber - InitializingIndex) / SequenceStep;

                if (ArithmeticSequenceList.Contains(VerifyingNumber))
                {
                    return true;
                }

                // Если VerifiableNumber меньше начального числа, то оно не может соответствовать последовательности
                else if (VerifyingNumber < InitializingIndex)
                {
                    return false;
                }

                else if (VerifyingNumber == InitializingIndex)
                {
                    // Добавляем число в список при первом проходе, если его там еще нет
                    if (!ArithmeticSequenceList.Contains(VerifyingNumber))
                    {
                        ArithmeticSequenceList.Add(VerifyingNumber);
                    }

                    return true;
                }

                else if ((VerifyingNumber - InitializingIndex) % SequenceStep == 0)
                {
                    if (!ArithmeticSequenceList.Contains(VerifyingNumber))
                    {
                        ArithmeticSequenceList.Add(VerifyingNumber);
                    }

                    return true;
                }

                else
                {
                    return false;
                }
            }

            /// <summary>
            /// Статический метод проверки соответствия числа чередующейся последовательности
            /// </summary>
            /// <param name="VerifyingNumber">Проверяемое число</param>
            /// <param name="FirstSequenceStep">Шаг первой последовательности (~~сколько чисел надо пройти~~ (на сколько надо прибавить), чтобы последовательность считалась завершённой)</param>
            /// <param name="SecondSequenceStep">Шаг второй последовательности (~~сколько чисел надо пройти~~ (на сколько надо прибавить), чтобы последовательность считалась завершённой)</param>
            /// <param name="CyclesPassed">Количество пройденных циклов последовательности</param>
            /// <param name="AlternatingSequenceList">Список чисел, удовлетворяющих заданной чередующейся последовательности</param>
            /// <param name="InitializingIndex">Число начала отсчёта последовательности</param>
            /// <returns>Состояние соответствия указанного числа последовательности, количество пройденных циклов последовательности, список чисел, удовлетворяющих последовательности</returns>
            public static bool IsNumberMatchesAlternatingSequence(int VerifyingNumber, int FirstSequenceStep, int SecondSequenceStep, out int CyclesPassed, ref List<int> AlternatingSequenceList, int InitializingIndex = 0)
            {
                // Вычисляем, сколько полных циклов прошло
                CyclesPassed = (VerifyingNumber - InitializingIndex) / (FirstSequenceStep + SecondSequenceStep);

                // Вычисляем остаток после прохождения полных циклов
                int Remainder = (VerifyingNumber - InitializingIndex) % (FirstSequenceStep + SecondSequenceStep);

                if (VerifyingNumber < InitializingIndex)
                {
                    return false;
                }

                else if (VerifyingNumber == InitializingIndex)
                {
                    // Добавляем число в список при первом проходе, если его там еще нет
                    if (!AlternatingSequenceList.Contains(VerifyingNumber))
                    {
                        AlternatingSequenceList.Add(VerifyingNumber);
                    }

                    return true;
                }

                // Если остаток равен 0 или равен step1, то число соответствует последовательности
                else if (Remainder == 0 || Remainder == FirstSequenceStep)
                {
                    // Добавляем число в список при первом проходе, если его там еще нет
                    if (!AlternatingSequenceList.Contains(VerifyingNumber))
                    {
                        AlternatingSequenceList.Add(VerifyingNumber);
                    }

                    return true;
                }

                else
                {
                    return false;
                }
            }

            /// <summary>
            /// Статический метод проверки соответствия числа цикличной последовательности
            /// </summary>
            /// <param name="VerifyingNumber">Проверяемое число</param>
            /// <param name="SequenceStep">Шаг последовательности (~~сколько чисел надо пройти~~ (на сколько надо прибавить), чтобы шаг в цикле считался пройденным)</param>
            /// <param name="IncrementOfLastNumberInStep">Инкремент последнего, замыкающего числа цикла последовательности ~~(на сколько оно отличается от шага последовательности)~~ (на сколько оно больше шага последовательности)</param>
            /// <param name="SequenceCycleLength">Количество шагов, составляющих цикл последовательности</param>
            /// <param name="CyclesPassed">Количество пройденных циклов последовательности</param>
            /// <param name="CyclicSequenceList">Список чисел, удовлетворяющих заданной цикличной последовательности</param>
            /// <param name="InitializingIndex">Число начала отсчёта последовательности</param>
            /// <returns>Состояние соответствия указанного числа последовательности, количество пройденных циклов последовательности, список чисел, удовлетворяющих последовательности</returns>
            public static bool IsNumberMatchesCyclicSequence(int VerifyingNumber, int SequenceStep, int IncrementOfLastNumberInStep, int SequenceCycleLength, out int CyclesPassed, ref List<int> CyclicSequenceList, int InitializingIndex = 0)
            {
                // Вычисляем полную длину цикла, учитывая шаг последовательности и инкремент последнего числа в цикле
                int FullCycleLength = SequenceStep * (SequenceCycleLength - 1) + IncrementOfLastNumberInStep;

                // Вычисляем, сколько полных циклов прошло
                CyclesPassed = (VerifyingNumber - InitializingIndex) / FullCycleLength;

                // Вычисляем остаток после прохождения полных циклов
                int Remainder = (VerifyingNumber - InitializingIndex) % FullCycleLength;

                // Проверяем, на каком шаге цикла находится число
                int CycleStep = Remainder / SequenceStep;

                if (CyclicSequenceList.Contains(VerifyingNumber))
                {
                    return true;
                }

                else if (VerifyingNumber < InitializingIndex)
                {
                    return false;
                }

                else if (VerifyingNumber == InitializingIndex)
                {
                    // Добавляем число в список при первом проходе, если его там еще нет
                    if (!CyclicSequenceList.Contains(VerifyingNumber))
                    {
                        CyclicSequenceList.Add(VerifyingNumber);
                    }

                    return true;
                }

                /*
                   Когда мы делим одно число на другое, “remainder” - это то, что остаётся от первого числа после вычитания наибольшего возможного количества полных копий второго числа. Например, при делении 17 на 5, наибольшее количество полных копий 5, которые можно вычесть из 17, равно 3 (потому что 3*5=15), и после вычитания остается 2. Таким образом, 2 - это “remainder” (остаток) от деления 17 на 5.

                   В контексте вашей последовательности и кода, который я предложил, “remainder” вычисляется как остаток от деления разности между проверяемым числом и начальным числом на общий шаг цикла.

                   Давайте рассмотрим пример с вашей последовательностью для первого цикла:

                   Первый цикл: 2, 4, 6, 8, 10, 13
                   Если проверяемое число - 4, то remainder = (4 - 2) % (2 * 5 + 1) = 2 % 11 = 2. Это меньше, чем 2 * (5 - 1) = 8, поэтому 4 соответствует последовательности.
                   Если проверяемое число - 10, то remainder = (10 - 2) % 11 = 8. Это также меньше, чем 8, поэтому 10 соответствует последовательности.
                   Если проверяемое число - 13, то remainder = (13 - 2) % 11 = 1. Это равно 2 * 5 = 10, поэтому 13 соответствует последовательности.
                */

                // Если текущий шаг цикла меньше общего количества шагов в цикле (то есть мы еще не достигли последнего числа в цикле)
                else if (CycleStep < SequenceCycleLength - 1)
                {
                    // Возвращаем true, если остаток от деления остатка на шаг последовательности равен нулю.
                    // Это означает, что проверяемое число соответствует шагу последовательности (кроме последнего числа в цикле).
                    if (Remainder % SequenceStep == 0)
                    {
                        if (!CyclicSequenceList.Contains(VerifyingNumber))
                        {
                            CyclicSequenceList.Add(VerifyingNumber);
                        }

                        return true;
                    }

                    else
                    {
                        return false;
                    }
                }

                // Если текущий шаг цикла равен общему количеству шагов в цикле (то есть мы на последнем числе в цикле)

                // Возвращаем true, если остаток равен произведению шага последовательности и количества шагов в цикле, увеличенному на IncrementOfLastNumberInStep.
                // Это означает, что проверяемое число соответствует последнему числу в цикле.
                else if (Remainder == SequenceStep * (SequenceCycleLength - 1) + IncrementOfLastNumberInStep)
                {
                    if (!CyclicSequenceList.Contains(VerifyingNumber))
                    {
                        CyclicSequenceList.Add(VerifyingNumber);
                    }

                    return true;
                }

                else
                {
                    return false;
                }
            }
        }
    }
}