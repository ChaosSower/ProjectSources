﻿// V. 1.5.2.

using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows;

namespace Digital_Schedule_Editor.Classes
{
    /// <summary>
    /// Класс логики интерактивной подсветки и динамического изменения размера для элемента <see cref="Button"/>
    /// </summary>
    internal class FocusableButtonClass
    {
        /// <summary>
        /// Конструктор класса <see cref="FocusableButtonClass"/>, принимающий обрабатываемый <see cref="Button"/> <paramref name="FocusableButton"/>
        /// </summary>
        /// <param name="FocusableButton"><see cref="Button"/>, к которому необходимо применить анимации и эффекты</param>
        /// <param name="IsButtonGrows"><see cref="bool"/> значение, указывающее на то, будет ли кнопка увеличиваться или уменьшаться</param>
        internal FocusableButtonClass(Button FocusableButton, bool IsButtonGrows = true)
        {
            FocusableButton.RenderTransform = new ScaleTransform();
            //FocusableButton.RenderTransformOrigin = new Point(0.5, 0.5); // для изменения размера по центру, а не с верхнего левого угла
            //RenderOptions.SetBitmapScalingMode(FocusableButton, BitmapScalingMode.NearestNeighbor); // убирает размытие при изменении размера, но появляются артефакты

            if (IsButtonGrows)
            {
                FocusableButton.MouseEnter += (sender, e) =>
                {
                    FocusableButton.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1.05, TimeSpan.FromSeconds(0.1)));
                    FocusableButton.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1.05, TimeSpan.FromSeconds(0.1)));

                    if (!FocusableButton.IsFocused)
                    {
                        FocusableButton.BorderBrush = Brushes.Yellow;
                    }
                };

                FocusableButton.MouseLeave += (sender, e) =>
                {
                    FocusableButton.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1, TimeSpan.FromSeconds(0.1)));
                    FocusableButton.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1, TimeSpan.FromSeconds(0.1)));

                    if (!FocusableButton.IsFocused)
                    {
                        FocusableButton.BorderBrush = Brushes.Gray;
                    }
                };
            }

            else
            {
                FocusableButton.RenderTransformOrigin = new Point(0.5, 0.5); // для изменения размера по центру, а не с верхнего левого угла
                RenderOptions.SetBitmapScalingMode(FocusableButton, BitmapScalingMode.NearestNeighbor); // убирает размытие при изменении размера, но появляются артефакты

                FocusableButton.MouseEnter += (sender, e) =>
                {
                    FocusableButton.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(0.95, TimeSpan.FromSeconds(0.1)));
                    FocusableButton.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(0.95, TimeSpan.FromSeconds(0.1)));

                    if (!FocusableButton.IsFocused)
                    {
                        FocusableButton.BorderBrush = Brushes.Yellow;
                    }
                };

                FocusableButton.MouseLeave += (sender, e) =>
                {
                    FocusableButton.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty, new DoubleAnimation(1, TimeSpan.FromSeconds(0.1)));
                    FocusableButton.RenderTransform.BeginAnimation(ScaleTransform.ScaleYProperty, new DoubleAnimation(1, TimeSpan.FromSeconds(0.1)));

                    if (!FocusableButton.IsFocused)
                    {
                        FocusableButton.BorderBrush = Brushes.Gray;
                    }
                };
            }

            FocusableButton.GotFocus += (sender, e) => FocusableButton.BorderBrush = Brushes.Red;
            FocusableButton.LostFocus += (sender, e) => FocusableButton.BorderBrush = Brushes.Gray;
        }
    }
}