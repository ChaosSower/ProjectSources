﻿using static Digital_Schedule_Editor.Classes.LessonClass;

namespace Digital_Schedule_Editor.Classes
{
    internal class Group
    {
        public string GroupName { get; }
        public List<(Lesson FirstLesson, Lesson SecondLesson)> Lessons { get; }

        public Group(string GroupName, List<(Lesson FirstLesson, Lesson SecondLesson)> Lessons)
        {
            this.GroupName = GroupName;
            this.Lessons = Lessons;
        }
    }
}