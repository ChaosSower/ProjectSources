﻿// V.0.8.6.2 - на удаление!

using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

using Digital_Schedule_Editor.Modules.Windows.College;

namespace Digital_Schedule_Editor.Classes
{
    public class LessonClass
    {
        public class Lesson
        {
            private string _DayOfWeek = string.Empty;

            public string DayOfWeek
            {
                get => _DayOfWeek;

                private set
                {
                    if (value == string.Empty)
                    {
                        throw new("Не может быть отсутствующего дня недели!");
                    }

                    else
                    {
                        _DayOfWeek = value;
                    }
                }
            }

            private int _NumberOfLesson;

            public int NumberOfLesson
            {
                get => _NumberOfLesson;

                private set
                {
                    if (value < 0)
                    {
                        throw new("Не может быть пары с индексом -1!");
                    }

                    else
                    {
                        _NumberOfLesson = value;
                    }
                }
            }

            private ComboBox SubjectComboBox;

            public event Action? OnSubjectChanged;

            private string _Subject = string.Empty;
            public string Subject
            {
                get => _Subject;

                set
                {
                    if (value == "Дисциплина" && SubjectComboBox.Foreground == Brushes.Gray)
                    {
                        return;
                    }

                    else
                    {
                        _Subject = value;
                        OnSubjectChanged?.Invoke();
                    }
                }
            }

            private ComboBox TeacherComboBox;

            private string _Teacher = string.Empty;
            public string Teacher
            {
                get => _Teacher;

                set
                {
                    if (value == "Преподаватель" && TeacherComboBox.Foreground == Brushes.Gray)
                    {
                        return;
                    }

                    else
                    {
                        _Teacher = value;
                    }
                }
            }

            private ComboBox ClassroomComboBox;

            private string _Classroom = string.Empty;
            public string Classroom
            {
                get => _Classroom;

                set
                {
                    if (value == "Каб." && ClassroomComboBox.Foreground == Brushes.Gray)
                    {
                        return;
                    }

                    else
                    {
                        _Classroom = value;
                    }
                }
            }

            private Dictionary<string, (List<(string OddWeekSubject, int OddWeekSubjectHours)> OddWeekSubjectsInfoList, List<(string EvenWeekSubject, int EvenWeekSubjectHours)>? EvenWeekSubjectsInfoList)> GroupSubjectsDictionary;
            public readonly Run SubjectsPerDayTextLine;

            public Lesson(string DayOfWeek, int NumberOfLesson, ComboBox SubjectComboBox, ComboBox TeacherComboBox, ComboBox ClassroomComboBox, Dictionary<string, (List<(string OddWeekSubject, int OddWeekSubjectHours)> OddWeekSubjectsInfoList, List<(string EvenWeekSubject, int EvenWeekSubjectHours)>? EvenWeekSubjectsInfoList)> GroupSubjectsDictionary, Run SubjectsPerDayTextLine)
            {
                this.DayOfWeek = DayOfWeek;
                this.NumberOfLesson = NumberOfLesson;
                this.SubjectComboBox = SubjectComboBox;
                this.TeacherComboBox = TeacherComboBox;
                this.ClassroomComboBox = ClassroomComboBox;

                this.GroupSubjectsDictionary = GroupSubjectsDictionary;
                this.SubjectsPerDayTextLine = SubjectsPerDayTextLine;

                if (!string.IsNullOrWhiteSpace(SubjectComboBox.Text))
                {
                    Subject = SubjectComboBox.Text;
                }

                SubjectComboBox.Loaded += (sender, e) =>
                {
                    bool SubjectComboBoxTextChanged = false;

                    if (SubjectComboBox.Template.FindName("PART_EditableTextBox", SubjectComboBox) is TextBox SubjectComboBoxEditableTextBox)
                    {
                        SubjectComboBoxEditableTextBox.TextChanged += (sender, e) => SubjectComboBoxTextChanged = true;

                        SubjectComboBox.LostFocus += (sender, e) =>
                        {
                            if (SubjectComboBoxTextChanged)
                            {
                                Subject = SubjectComboBoxEditableTextBox.Text;
                                SubjectComboBoxTextChanged = false;
                                EditGroupScheduleWindow.ChangesHasBeenMadeAction.Invoke();
                            }
                        };
                    }
                };

                if (!string.IsNullOrWhiteSpace(TeacherComboBox.Text))
                {
                    Teacher = TeacherComboBox.Text;
                }

                TeacherComboBox.Loaded += (sender, e) =>
                {
                    bool TeacherComboBoxTextChanged = false;

                    if (TeacherComboBox.Template.FindName("PART_EditableTextBox", TeacherComboBox) is TextBox TeacherComboBoxEditableTextBox)
                    {
                        TeacherComboBoxEditableTextBox.TextChanged += (sender, e) => TeacherComboBoxTextChanged = true;

                        TeacherComboBox.LostFocus += (sender, e) =>
                        {
                            if (TeacherComboBoxTextChanged)
                            {
                                Teacher = TeacherComboBoxEditableTextBox.Text;
                                TeacherComboBoxTextChanged = false;
                                EditGroupScheduleWindow.ChangesHasBeenMadeAction.Invoke();
                            }
                        };
                    }
                };

                if (!string.IsNullOrWhiteSpace(ClassroomComboBox.Text))
                {
                    Classroom = ClassroomComboBox.Text;
                }

                ClassroomComboBox.Loaded += (sender, e) =>
                {
                    bool ClassroomComboBoxTextChanged = false;

                    if (ClassroomComboBox.Template.FindName("PART_EditableTextBox", ClassroomComboBox) is TextBox ClassroomComboBoxEditableTextBox)
                    {
                        ClassroomComboBoxEditableTextBox.TextChanged += (sender, e) => ClassroomComboBoxTextChanged = true;

                        ClassroomComboBox.LostFocus += (sender, e) =>
                        {
                            if (ClassroomComboBoxTextChanged)
                            {
                                Classroom = ClassroomComboBoxEditableTextBox.Text;
                                ClassroomComboBoxTextChanged = false;
                                EditGroupScheduleWindow.ChangesHasBeenMadeAction.Invoke();
                            }
                        };
                    }
                };
            }
        }

        public class LessonModule
        {
            public Lesson? Lesson;
            public (Lesson OddWeekLesson, Lesson EvenWeekLesson)? Lessons;
            public required bool IsTeacherReplacementModeActivated;
            public required bool IsLectureModeActivated;

            private Dictionary<string, (List<(string OddWeekSubject, int OddWeekSubjectHours)> OddWeekSubjectsInfoList, List<(string EvenWeekSubject, int EvenWeekSubjectHours)>? EvenWeekSubjectsInfoList)> GroupSubjectsDictionary;
            private List<(string Subject, int SubjectHours)>? WeekSubjectsAndHoursList;
            private List<(string OddWeekSubject, int OddWeekSubjectHours)>? OddWeekSubjectsAndHoursList;
            private List<(string EvenWeekSubject, int EvenWeekSubjectHours)>? EvenWeekSubjectsAndHoursList;

            private Run SubjectsPerDayTextLine;

            public LessonModule(Lesson Lesson, Dictionary<string, (List<(string OddWeekSubject, int OddWeekSubjectHours)> OddWeekSubjectsInfoList, List<(string EvenWeekSubject, int EvenWeekSubjectHours)>? EvenWeekSubjectsInfoList)> GroupSubjectsDictionary, Run SubjectsPerDayTextLine)
            {
                this.Lesson = Lesson;

                this.GroupSubjectsDictionary = GroupSubjectsDictionary;
                this.SubjectsPerDayTextLine = SubjectsPerDayTextLine;

                if (!string.IsNullOrEmpty(Lesson.Subject))
                {
                    WeekSubjectsAndHoursList = new()
                    {
                        (Lesson.Subject, 2)
                    };
                }

                Lesson.OnSubjectChanged += () =>
                {

                };
            }

            public LessonModule((Lesson OddWeekLesson, Lesson EvenWeekLesson) Lessons, Dictionary<string, (List<(string OddWeekSubject, int OddWeekSubjectHours)> OddWeekSubjectsInfoList, List<(string EvenWeekSubject, int EvenWeekSubjectHours)>? EvenWeekSubjectsInfoList)> GroupSubjectsDictionary, Run SubjectsPerDayTextLine)
            {
                this.Lessons = Lessons;

                this.GroupSubjectsDictionary = GroupSubjectsDictionary;
                this.SubjectsPerDayTextLine = SubjectsPerDayTextLine;

                if (!string.IsNullOrEmpty(Lessons.OddWeekLesson.Subject))
                {
                    OddWeekSubjectsAndHoursList = new()
                    {
                        (Lessons.OddWeekLesson.Subject, 2)
                    };
                }

                if (!string.IsNullOrEmpty(Lessons.EvenWeekLesson.Subject))
                {
                    EvenWeekSubjectsAndHoursList = new()
                    {
                        (Lessons.EvenWeekLesson.Subject, 2)
                    };
                }

                Lessons.OddWeekLesson.OnSubjectChanged += () =>
                {

                };

                Lessons.EvenWeekLesson.OnSubjectChanged += () =>
                {

                };
            }
        }
    }
}