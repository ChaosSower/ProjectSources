﻿using System.Xml;
using System.Xml.Serialization;

using Digital_Schedule_Editor.Classes.AbstractClasses;

// TODO: предусмотреть открытие файла и запуск программы с открытым файлом
// TODO: посмотреть содержимое ссылки, реализовать
//https://stackoverflow.com/questions/2169970/how-to-serialize-a-class-that-contains-objects-of-other-classes-recursive-seria

namespace Digital_Schedule_Editor.Classes.SerializingClasses
{
    [Serializable]
    public class GroupDataClass : XMLSerializingDataClass
    {
        public override string FileName
        {
            get => $"GroupData [{GroupName}].xml";
        }

        public override string? ErrorMessage { get; set; }

        //[XmlIgnore]
        [XmlElement("Название группы")]
        public string? GroupName { get; set; }

        [XmlElement("Список по дням недели часов предметов")]
        public List<(string DayOfWeek, List<(string Subject, float Hours)>)>? SubjectsPerWeekDayList { get; set; }

        [XmlElement("Список позиций и текста каждой ячейки в расписании группы")]
        public List<(int Column, int Row, string DayOfWeek, string Week, string Text)>? ComboBoxesInfoList { get; set; }

        [XmlElement("Список позиций и текста каждой ячейки группы на главной форме")]
        public List<(int Column, int Row, string DayOfWeek, string Week, string Text)>? MainWindowComboBoxesInfoList { get; set; }

        public override bool CreateXmlComments<T>(T DataClass, out XmlDocument XmlDocument)
        {
            try
            {
                base.CreateXmlComments(DataClass, out XmlDocument);

                XmlComment XmlComment = XmlDocument.CreateComment("Список дисциплин группы - " + (SubjectsPerWeekDayList?.Count ?? 0).ToString() + $", Список позиции и текста каждой ячейки в расписании группы {GroupName} - " + (ComboBoxesInfoList?.Count ?? 0).ToString());
                XmlDocument.DocumentElement?.AppendChild(XmlComment);
                XmlDocument.Save(FileName);

                return true;
            }

            catch
            {
                XmlDocument = new();

                return false;
            }
        }
    }
}

/*
 using System.Xml;
using System.Xml.Serialization;

using Digital_Schedule_Editor.Classes.AbstractClasses;

// TODO: посмотреть содержимое ссылки, реализовать
//https://stackoverflow.com/questions/2169970/how-to-serialize-a-class-that-contains-objects-of-other-classes-recursive-seria

namespace Digital_Schedule_Editor.Classes.SerializingClasses
{
    [Serializable]
    public class GroupDataClass : SerializingDataClass
    {
        public override string FileName
        {
            get => $"GroupData [{GroupName}].xml";
        }

        public override string? ErrorMessage { get; set; }

        //[XmlIgnore]
        [XmlElement("Название группы")]
        public string? GroupName { get; set; }

        [XmlIgnore]
        public List<(string Group, List<(int Column, int Row, string Day, string Week, string Text)>)>? GroupsDockableComboBoxesPositionAndTheirTextList { get; set; }

        [XmlElement("Данные каждой ячейки в расписании группы")]
        public List<(string Group, List<DockableComboBoxInfoClass>)>? GroupsDockableComboBoxesInfoList { get; set; }

        // TODO: изменить на - public List<(int, int, string)>? GroupsDockableComboBoxPositionAndTheirTextList { get; set; }

        [XmlElement("Список группы и их пар")]
        public List<(string, List<(string, List<(string, float)>)>)>? GroupsSubjectsPerWeekDayList { get; set; }
        // TODO: изменить на - public List<(string, List<(string, float)>)>? GroupSubjectsPerWeekDayList { get; set; }

        public override void CreateXmlComments<T>(T DataClass, out XmlDocument XmlDocument)
        {
            base.CreateXmlComments(DataClass, out XmlDocument);

            XmlComment XmlComment = XmlDocument.CreateComment("Список дисциплин группы - " + (GroupsSubjectsPerWeekDayList?.Count ?? 0).ToString() + $", Список позиции и текста каждой ячейки в расписании группы {GroupName} - " + (GroupsDockableComboBoxesPositionAndTheirTextList?.Count ?? 0).ToString());
            XmlDocument.DocumentElement?.AppendChild(XmlComment);
            XmlDocument.Save(FileName);
        }
    }

    public class DockableComboBoxInfoClass
    {
        public DockableComboBoxInfoClass(int Column, int Row, string Day, string Week, string Text)
        {
            this.Column = Column;
            this.Row = Row;
            this.Day = Day;
            this.Week = Week;
            this.Text = Text;
        }

        [XmlElement("Колонка")]
        public int Column { get; set; }

        [XmlElement("Строка")]
        public int Row { get; set; }

        [XmlElement("День недели")]
        public string? Day { get; set; }

        [XmlElement("Чётность недели")]
        public string? Week { get; set; }

        [XmlElement("Содержимое (текст)")]
        public string? Text { get; set; }
    }
}*/

// TODO: Продумать отдельный режим, сохраняющий все данные расписания группы в одном xml-файле
/*
     [Serializable]
    public class GroupDataClass : SerializingDataClass
    {
        public override string FileName
        {
            get => $"GroupData [{GroupName}].xml";
        }

        public override string? ErrorMessage { get; set; }

        [XmlIgnore]
        //[XmlElement("Название группы")]
        public string? GroupName { get; set; }

        [XmlElement("Список группы и её пар")]
        public List<(string, List<(string, List<(string, float)>)>)>? GroupSubjectsPerWeekDayList { get; set; }
        // TODO: изменить на - public List<(string, List<(string, float)>)>? GroupSubjectsPerWeekDayList { get; set; }

        [XmlElement("Список группы, а также позиции и текста каждой ячейки в её расписании")]
        public List<(string Group, List<(int Column, int Row, string Day, string Week, string Text)>)>? GroupDockableComboBoxesPositionAndTheirTextList { get; set; }
        // TODO: изменить на - public List<(int, int, string)>? GroupsDockableComboBoxPositionAndTheirTextList { get; set; }

        public override void CreateXmlComments<T>(T DataClass, out XmlDocument XmlDocument)
        {
            base.CreateXmlComments(DataClass, out XmlDocument);

            XmlComment XmlComment = XmlDocument.CreateComment("Список дисциплин группы - " + (GroupSubjectsPerWeekDayList?.Count ?? 0).ToString() + $", Список позиции и текста каждой ячейки в расписании группы {GroupName} - " + (GroupDockableComboBoxesPositionAndTheirTextList?.Count ?? 0).ToString());
            XmlDocument.DocumentElement?.AppendChild(XmlComment);
            XmlDocument.Save(FileName);
        }
    }*/