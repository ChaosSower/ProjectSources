﻿using System.Xml;
using System.Xml.Serialization;

using Digital_Schedule_Editor.Classes.AbstractClasses;

namespace Digital_Schedule_Editor.Classes.SerializingClasses
{
    [Serializable]
    public class MainDataClass : XMLSerializingDataClass
    {
        public override string FileName { get; } = "MainData.xml"; // название файла сохранения данных

        public override string? ErrorMessage { get; set; }

        [XmlElement("Список дисциплин")]
        public List<string>? SubjectList { get; set; }

        [XmlElement("Список преподавателей")]
        public List<string>? TeacherList { get; set; }

        [XmlElement("Список групп")]
        public List<string>? GroupList { get; set; }

        [XmlElement("Список аудиторий")]
        public List<string>? ClassroomList { get; set; }

        [XmlElement("Список дисциплин и их преподавателей")]
        public List<(string, string)>? SubjectAndTeacherList { get; set; }

        [XmlElement("Список дисциплин и их аудиторий")]
        public List<(string, string)>? SubjectAndClassroomList { get; set; }

        [XmlElement("Список преподавателей и их аудиторий")]
        public List<(string, string)>? TeacherAndClassroomList { get; set; }

        [XmlElement("Список пар и их времени")]
        public List<(string, string)>? NumberOfLessonAndTimeList { get; set; }

        public override bool CreateXmlComments<T>(T DataClass, out XmlDocument XmlDocument)
        {
            try
            {
                base.CreateXmlComments(DataClass, out XmlDocument);

                XmlComment XmlComment = XmlDocument.CreateComment("Список дисциплин - " + (SubjectList?.Count ?? 0).ToString() + ", Список преподавателей - " + (TeacherList?.Count ?? 0).ToString() + ", Список групп - " + (GroupList?.Count ?? 0).ToString() + ", Список аудиторий - " + (ClassroomList?.Count ?? 0).ToString());
                XmlDocument.DocumentElement?.AppendChild(XmlComment);
                XmlDocument.Save(FileName);

                return true;
            }

            catch
            {
                XmlDocument = new();

                return false;
            }
        }
    }
}