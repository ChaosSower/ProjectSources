﻿using Digital_Schedule_Editor.Interfaces;

namespace Digital_Schedule_Editor.Classes.AbstractClasses
{
    internal abstract class SequenceMatcher : ISequenceMatcher
    {
        protected int FirstSequenceStep;
        protected int SecondSequenceStep;

        public SequenceMatcher(int FirstSequenceStep, int SecondSequenceStep)
        {
            this.FirstSequenceStep = FirstSequenceStep;
            this.SecondSequenceStep = SecondSequenceStep;
        }

        public abstract bool IsNumberMatchesSequence(int VerifyingNumber, out int CyclesPassed, ref List<int> SequenceList, int InitializingIndex = 0);
    }
}