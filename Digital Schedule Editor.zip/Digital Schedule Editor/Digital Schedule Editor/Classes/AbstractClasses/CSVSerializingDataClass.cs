﻿using System.IO;
using System.Windows;

using Digital_Schedule_Editor.Interfaces;
using Digital_Schedule_Editor.Classes.SerializingClasses;
using Digital_Schedule_Editor.Extensions.CommonComponents;

namespace Digital_Schedule_Editor.Classes.AbstractClasses
{
    //[XmlInclude(typeof(GroupDataClass))]
    //[XmlInclude(typeof(MainDataClass))]
    public abstract class CSVSerializingDataClass /*: ISerializable*/
    {
        public abstract string FileName { get; }

        //[XmlIgnore]
        //public string? FileCreationDate { get; set; }

        public readonly static List<(string, FileStream)> OpenedFileStreams = new(); // словарь хранимых открытых потоков файлов

        // TODO: добавить нормальный XML-комментарий ниже
        // свойство ниже не будет записано в файл, поскольку оно присваивается только при LoadData
        public abstract string? ErrorMessage { get; set; }

        // Метод сохранения данных в XML-файл (сериализация)
        public virtual bool SaveData<T>(List<T> Data) where T : new()
        {
            try
            {
                //FileCreationDate = null;
                FileStream? FileStream = null;

                if (File.Exists(FileName))
                {
                    FileStream = FileStream.CheckFileStreamInOpenedFileStreamsList(FileName);

                    //XmlDocument PreviousXmlDocument = new();

                    if (FileStream != null)
                    {
                        try
                        {
                            using (var writer = new StreamWriter(FileName))
                            {
                                var properties = typeof(T).GetProperties();
                                foreach (var item in Data)
                                {
                                    var values = properties.Select(p => p.GetValue(item));
                                    writer.WriteLine(string.Join(",", values));
                                }
                            }
                            //PreviousXmlDocument.Load(FileName);

                            //if (PreviousXmlDocument.SelectSingleNode("//comment()[contains(.,'Дата создания')]") is XmlComment XmlPreviousComment)
                            //{
                            //    FileCreationDate = XmlPreviousComment.Value?.Split(new[] { ": " }, StringSplitOptions.None)[1].Split(',')[0].Trim();
                            //}

                            FileStream.KeepFileStream(FileName, false);
                        }

                        catch //(XmlException)
                        {
                            MessageBoxResult MessageBoxResult = MessageBox.Show("Файл назначения для сохранения данных повреждён.\nУдалить файл, содержащий ошибки и создать новый?\n\n[Предупреждение: повреждённый файл может содержать данные]", "Ошибка сохранения данных в существующий файл", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.No);

                            FileStream.KeepFileStream(FileName, false);

                            if (MessageBoxResult == MessageBoxResult.Yes)
                            {
                                File.Delete(FileName);
                            }

                            else
                            {
                                string NewFileName = FileName[..^4] + " (Повреждённый).csv";
                                File.Move(FileName, NewFileName); // переименование существующего файла
                            }
                        }
                    }
                }

                using (FileStream = new(FileName, FileMode.Create))
                {
                    //XmlSerializer XmlSerializer = new(typeof(T), new XmlRootAttribute(typeof(T).Name));
                    //XmlSerializer.Serialize(FileStream, this);
                }

                //CreateXmlComments(this, out _); // добавление комментария с датой создания и изменения файла

                FileStream = new(FileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                FileStream.KeepFileStream(FileName);
            }

            catch
            {
                return false;
            }

            return true;
        }

        //// Метод добавления комментариев в XML-файл
        //public virtual bool CreateXmlComments<T>(T DataClass, out XmlDocument XmlDocument) where T : XMLSerializingDataClass
        //{
        //    try
        //    {
        //        XmlDocument = new();
        //        XmlDocument.Load(FileName);

        //        XmlComment XmlComment;

        //        if (FileCreationDate != null)
        //        {
        //            XmlComment = XmlDocument.CreateComment("Дата создания: " + FileCreationDate + ", Дата изменения: " + DateTime.Now.ToString());
        //        }

        //        else
        //        {
        //            XmlComment = XmlDocument.CreateComment("Дата создания: " + DateTime.Now.ToString());
        //        }

        //        XmlDocument.InsertBefore(XmlComment, XmlDocument.DocumentElement);

        //        return true;
        //    }

        //    catch
        //    {
        //        XmlDocument = new();

        //        return false;
        //    }
        //}

        // Метод выгрузки данных из XML-файла (десериализация)
        //public virtual List<T> LoadData<T>() where T : new()
        //{
        //    try
        //    {
        //        var Data = new List<T>();
        //        var properties = typeof(T).GetProperties();
        //        if (File.Exists(FileName))
        //        {
        //            FileStream? FileStream = null;
        //            FileStream = FileStream.CheckFileStreamInOpenedFileStreamsList(FileName);

        //            if (FileStream != null)
        //            {
        //                try
        //                {
        //                    using (var reader = new StreamReader(FileName))
        //                    {
        //                        string line;
        //                        while ((line = reader.ReadLine()) != null)
        //                        {
        //                            var values = line.Split(',');
        //                            var item = new T();

        //                            for (int i = 0; i < values.Length; i++)
        //                            {
        //                                properties[i].SetValue(item, Convert.ChangeType(values[i], properties[i].PropertyType));
        //                            }

        //                            Data.Add(item);
        //                        }
        //                    }

        //                    //XmlSerializer XmlSerializer = new(typeof(T));
        //                    //object? DeserializedData = XmlSerializer.Deserialize(FileStream);

        //                    //if (DeserializedData is T DataClass)
        //                    {
        //                        //Data = DataClass;
        //                    }
        //                }

        //                catch (InvalidOperationException)
        //                {
        //                    ErrorMessage = "Документ хранения данных был повреждён!";
        //                }
        //            }
        //        }

                    //T? Data = default;



            //    if (Data == null) // создание нового экземпляра класса хранения данных
            //    {
            //        Data = new T();

            //        return (Data, false);
            //    }

            //    else
            //    {
            //        return (Data, true);
            //    }
            //}

            //catch
            //{
            //    T? Data = new();

            //    return (Data, false);
            //}
        //}
    }
}