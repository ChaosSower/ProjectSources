﻿// V. 1.5.6.

using System.Windows.Controls;
using System.Collections.ObjectModel;

using Digital_Schedule_Editor.Classes.SerializingClasses;

namespace Digital_Schedule_Editor.Interfaces
{
    /// <summary>
    /// Интерфейс пользовательского элемента с коллекцией, управляемой с помощью двух <see cref="Button"/>
    /// </summary>
    internal interface IEditMainDataWindowControl
    {
        /// <summary>
        /// Свойство всех основных данных
        /// </summary>
        internal protected MainDataClass? MainData { get; }

        /// <summary>
        /// Свойство коллекции необходимых данных из <paramref name="MainData"/>
        /// </summary>
        internal protected ObservableCollection<string>? EntityList { get; }

        /// <summary>
        /// Изначальное число элементов в коллекции <paramref name="EntityList"/>
        /// </summary>
        internal protected int OriginalEntityListItemsCount { get; }
    }
}