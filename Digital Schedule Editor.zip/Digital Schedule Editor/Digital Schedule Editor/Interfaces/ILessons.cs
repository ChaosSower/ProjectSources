﻿// V. 1.2.

namespace Digital_Schedule_Editor.Interfaces
{
    internal interface ILessons : ILesson
    {
        internal protected string? EvenWeekSubject { get; set; }
        internal protected string? EvenWeekTeacher { get; set; }
        internal protected string? EvenWeekClassroom { get; set; }
        internal protected bool? IsEvenWeekTeacherReplacementModeActivated { get; set; }
        internal protected bool? IsEvenWeekLectureModeActivated { get; set; }
    }
}