﻿namespace Digital_Schedule_Editor.Interfaces
{
    internal interface ISequenceMatcher
    {
        bool IsNumberMatchesSequence(int VerifyingNumber, out int CyclesPassed, ref List<int> SequenceList, int InitializingIndex = 0);
    }
}