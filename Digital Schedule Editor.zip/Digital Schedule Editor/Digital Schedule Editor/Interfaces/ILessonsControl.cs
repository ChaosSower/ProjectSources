﻿// V. 1.2.

namespace Digital_Schedule_Editor.Interfaces
{
    internal interface ILessonsControl : ILessons
    {
        internal protected string? DayOfWeek { get; set; }
        internal protected int? NumberOfLesson { get; set; }
        internal protected bool? DivideLessonIntoOddAndEvenWeek { get; set; }
    }
}