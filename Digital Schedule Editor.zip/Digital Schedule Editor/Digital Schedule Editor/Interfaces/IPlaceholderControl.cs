﻿namespace Digital_Schedule_Editor.Interfaces
{
    internal interface IPlaceholderControl
    {
        /// <summary>
        /// Шаблон текста-подсказки
        /// </summary>
        internal protected string? PlaceholderText { get; set; }
    }
}