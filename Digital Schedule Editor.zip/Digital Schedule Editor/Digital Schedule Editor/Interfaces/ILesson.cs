﻿// V. 1.2.

namespace Digital_Schedule_Editor.Interfaces
{
    internal interface ILesson
    {
        internal protected string? Subject { get; set; }
        internal protected string? Teacher { get; set; }
        internal protected string? Classroom { get; set; }
        internal protected bool? IsTeacherReplacementModeActivated { get; set; }
        internal protected bool? IsLectureModeActivated { get; set; }
    }
}