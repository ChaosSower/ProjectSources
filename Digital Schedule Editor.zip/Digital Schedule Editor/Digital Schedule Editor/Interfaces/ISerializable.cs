﻿// TODO: public -> protected
namespace Digital_Schedule_Editor.Interfaces
{
    public interface ISerializable
    {
        public string FileName { get; }

        public bool SaveData<T>() where T : new();

        public (T, bool) LoadData<T>() where T : new();
    }
}