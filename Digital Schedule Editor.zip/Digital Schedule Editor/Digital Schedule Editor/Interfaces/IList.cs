﻿// TODO: public -> protected
namespace Digital_Schedule_Editor.Interfaces
{
    public interface IList
    {
        public int Count { get; }

        public string this[int Index] { get; }

        public void Add(string Item);

        public void Clear();
    }
}