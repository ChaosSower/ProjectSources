﻿using System.Windows.Controls;
using System.Collections.ObjectModel;

using Digital_Schedule_Editor.Classes.SerializingClasses;

namespace Digital_Schedule_Editor.Interfaces
{
    /// <summary>
    /// Интерфейс блока трёх элементов <see cref="ComboBox"/>, с коллекциями данных:
    /// <list type="bullet">
    /// <item>
    /// <description><paramref name="SubjectList"/> — коллекция дисциплин</description>
    /// </item>
    /// <item>
    /// <description><paramref name="TeacherList"/> — коллекция преподавателей</description>
    /// </item>
    /// <item>
    /// <description><paramref name="ClassroomList"/> — коллекция кабинетов</description>
    /// </item>
    /// </list>
    /// </summary>
    internal interface IEditGroupScheduleWindowControl
    {
        /// <summary>
        /// Свойство всех основных данных
        /// </summary>
        internal protected MainDataClass MainData { get; }

        /// <summary>
        /// Свойство коллекции данных о дисциплинах из <paramref name="MainData"/>
        /// </summary>
        internal protected abstract ObservableCollection<string> SubjectList { get; }

        /// <summary>
        /// Свойство коллекции данных о преподавателях из <paramref name="MainData"/>
        /// </summary>
        internal protected abstract ObservableCollection<string> TeacherList { get; }

        /// <summary>
        /// Свойство коллекции данных о кабинетах из <paramref name="MainData"/>
        /// </summary>
        internal protected abstract ObservableCollection<string> ClassroomList { get; }
    }
}